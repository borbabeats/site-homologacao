console.info("load Scripts-estrutura_Etapas V1.0");

function loadInAllSteps(){	
	$("#invi_resposta").val() != "" && $("#invi_nr_chamado").val() != "" ? finalizacao() : ""
	
	function finalizacao(){
		var descricao = "<blockquote> Informações </blockquote>"

		parseInt($("#invi_nr_chamado").val()) == 0 ?	
			descricao += `<strong><p> Erro na criação do chamado.<br> Para mais informações, favor contatar a TI! Erro: ${$("#invi_erro_chamado").val()}</p></strong>`: 
			descricao += `<strong><p> Nº chamado: ${$("#invi_nr_chamado").val()}</p> </strong>`;
		
		$("#invi_resposta").val() == "false" ? 
			descricao += `<strong><p>Erro na inserção da observação do colaborador.<br> Para mais informações, favor contatar a TI! Erro: ${$("#invi_erro").val()} </p> </strong>` : 
			descricao += `<strong><p> ${$("#invi_erro").val()} </p></strong>`;
		
		$("#div_erro_etapa").append(descricao).show()
	}
}

function loadStep1(){
	FLUIGC.calendar('#txt_dt_inicio');
    	FLUIGC.calendar('#txt_dt_fim');

	if($('#txt_matricula').val() != ""){
		try{
			var matricula = $("#txt_matricula").val()
			var dataset = DatasetFactory.getDataset("ds_infoFuncionarioMatricula", null, [ DatasetFactory.createConstraint("Matrícula", matricula, matricula, ConstraintType.MUST)], null);

			for(var x = 0; x <dataset.values.length; x++){
				var row = dataset.values[x];
				buscaGestor(row[dataset.columns[3]])
				buscaObservacao(row[dataset.columns[0]])
				
				var html = $("#div_termo").html()
				$("#div_termo").html(html.replace('$(nome)', row[dataset.columns[1]]).replace('$(matricula)', row[dataset.columns[0]]))

				$("#txt_nomeSolicitante").val(row[dataset.columns[1]]);
				$("#txt_centroCusto").val(`${row[dataset.columns[4]]} (${row[dataset.columns[3]]})`);
				$("#txt_cargo").val(`${row[dataset.columns[6]]} (${row[dataset.columns[5]]})`);
			}
		}catch(e){
			alert(e)
		}	
	}

	$("#sl_tempo").on("change",  function(e) {
		if(this.value == 'tempolimitado'){
			$("#invi_tempo").val(1)
			$(".data_obs").attr("readonly", false).val("")

		}else{
			$(".data_obs").attr("readonly", true)

			$("#invi_tempo").val(0)
	
			var data = new Date();
			var dia = String(data.getDate()).padStart(2, '0');
			var mes = String(data.getMonth() + 1).padStart(2, '0');
			var ano = data.getFullYear();

			$("#invi_dt_in").val(ano + '-' + mes + '-' + dia);
			$("#txt_dt_inicio").val(dia + '/' + mes + '/' + ano);

			$("#invi_dt_fim").val('9999-12-31');
			$("#txt_dt_fim").val('31/12/9999');

			if(validaDtInicio($("#txt_matricula").val(), $("#txt_dt_inicio").val(), "txt_dt_inicio") == 1){
				$("#sl_tempo").val("")
				$(".data_obs").attr("readonly", false).val("")
				FLUIGC.toast({title: 'Erro!:', message: 'Data de Inicio (Hoje) deve ser diferente das datas anteriores da obervação', type: 'info'})
			}
		}
	})

	$("#txt_dt_inicio").on("blur", function (){
		validaDtInicio($("#txt_matricula").val(), this.value, this.id)
		
		data_fim_menor('#'+this.id, "#txt_dt_fim")
		var data = data_menor_hoje(this.value, this.id)

		$("#invi_dt_in").val(data[0])

	})
	
	$("#txt_dt_fim").on("blur", function (){
		if($("#txt_dt_inicio").val() != ""){
			data_fim_menor('#txt_dt_inicio', '#'+this.id)
			var data = data_menor_hoje(this.value, this.id)

			$("#invi_dt_fim").val(data[0]);

		}else
			$("#txt_dt_fim").val("")
	})

	function data_fim_menor(data_in, data_fim){
		var data_inicio = $(data_in).val()
		var partes_data_in = data_inicio.split("/");
		var data_completa_in = new Date(partes_data_in[2], partes_data_in[1] - 1, partes_data_in[0]);
		
		var data = $(data_fim).val();
		var partes_data_fim = data.split("/");
		var data_completa_fim = new Date(partes_data_fim[2], partes_data_fim[1] - 1, partes_data_fim[0]);
	  
		if (data_completa_in.getTime() > data_completa_fim.getTime()) {
		    $(data_fim).val("")
		    FLUIGC.toast({title: 'error:', message: 'Data final deve ser após a data inicial', type: 'info'});
		}
	  }

	  function data_menor_hoje(data, id){
		// alert(data + ': ' + id)
		var data_today = new Date()
		var data_hj = new Date(data_today.getFullYear(), data_today.getMonth(), data_today.getDate())
    
		var partes_data = data.split("/");
		var data_completa = new Date(partes_data[2], partes_data[1] - 1, partes_data[0]);
    
		if (data_completa.getTime() < data_hj.getTime()) {
		    $('#'+id).val("")
		    FLUIGC.toast({title: 'error:', message: 'Data deve ser após a data atual', type: 'info'});
		}else{
			return [partes_data[2] +'-'+ partes_data[1] +'-'+ partes_data[0]]
		}
	  }
}

function loadStep2(){

	 
}

function loadStep3(){
	 
}

function loadStep4(){ 
	$("#ck_termo_assinar").on("click", function(){
		$("#ck_termo_assinado").prop("checked", false);
	})
	$("#ck_termo_assinado").on("click", function(){
		$("#ck_termo_assinar").prop("checked", false);
	})
}

function loadStep5(){
	 
}

function loadStep33(){
	// div_tipHorario

	

	 $("#ck_temp_comercial").on("click", function(){

		$("#ck_temp_liberado").prop("checked", false);
		$("#invi_tipo_horario").val($("#ck_temp_comercial").val());
	})
	$("#ck_temp_liberado").on("click", function(){
		$("#ck_temp_comercial").prop("checked", false);

		$("#invi_tipo_horario").val($("#ck_temp_liberado").val());
	})
}

function buscaGestor(val){
	var dataset = DatasetFactory.getDataset("ds_listagemGestorPelaMatriculaInfoFunc", [val.toString()], null, null);

	if(dataset.values[0].Gestor == $("#invi_colaborador").val()){
	    $("#invi_gestorResponsavel").val(dataset.values[0].Diretor);    
	}else{
	    $("#invi_gestorResponsavel").val(dataset.values[0].Gestor);
	}
}

function buscaObservacao(val){
	try {
		var dataset = DatasetFactory.getDataset("ds_ListagemObservacaoFuncionario", [val.toString()], null, null);
		var count = 0;
		var append= '';
		var mensagem = '<h5 class="media-heading">'
		+'<span class="wrap-element-popover">'
		+'	<a class="link-default"> '
		+'		<strong> '+$("#txt_nomeSolicitante").val()+' </strong> '
		+'	</a>'
		+'</span>'

		for(var x = 0; x <dataset.values.length; x++){
			var row = dataset.values[x];
			if (parseInt(row[dataset.columns[3]]) == 6) {
				count ++;
				append += '<br> <span> De: <a class="link-default"> '+row[dataset.columns[1]].replace(" 12:00:00:0000", "");
				append += '</a> - Até: <a class="link-default"> '+row[dataset.columns[2]].replace(" 12:00:00:0000", "") + '</a></span>';
				append += '</a> - Obs: <a class="link-default"> '+row[dataset.columns[3]] +' - '+row[dataset.columns[4]] + '</a></span>';
			}
		}

		mensagem += count < 1 ? '<br> <span> Sem Observações de liberação de home office do usuário </span>' :
		 '<span class="timeline-header-no-link"> Você têm '+count+' habilitação(ões) para home office, no(s) período(s): </span>';

		 
		$("#content").append(mensagem + append)
	} catch (error) {
		alert(error)
	}
}

function validaDtInicio(val, data, idCampo){
	try {
		var dataset = DatasetFactory.getDataset("ds_ListagemObservacaoFuncionario", [val.toString()], null, null);
		var data_confer = 0;
		
		for(var x = 0; x <dataset.values.length; x++){
			var row = dataset.values[x];
			if (parseInt(row[dataset.columns[3]]) == 6) {

				var data_inicio = row[dataset.columns[1]].replace(" 12:00:00:0000", "") 
				data_inicio = data_inicio.split('/')
				var data_completa_in = new Date(data_inicio[2], data_inicio[1] - 1, data_inicio[0]);

				data_ = data.split('/')
				var data_completa = new Date(data_[2], data_[1] - 1, data_[0]);
				
				if(data_completa.getTime() == data_completa_in.getTime()){
					document.getElementById(idCampo).value = ''
					data_confer = 1
				}
			}
		}

		data_confer == 1 ? FLUIGC.toast({title: 'Erro!:', message: 'Data de Inicio deve ser diferente das datas anteriores da obervação', type: 'info'}) : ''

		return data_confer;
	} catch (error) {
		alert(error)
	}
}

function usuario_solicitante(){
	var matUsuario   	 = $("#invi_idUsuario").val();
	var solicitante 	 = $("#colab_1").val();


	try{
	    var datasetColleague = DatasetFactory.getDataset("colleague", null, [
		  DatasetFactory.createConstraint("colleaguePK.colleagueId", matUsuario, matUsuario, ConstraintType.MUST),
		  DatasetFactory.createConstraint("colleagueName", solicitante, solicitante, ConstraintType.MUST)
	    ], null);
	    var row = datasetColleague.values[0];
	    
	    $("#invi_usu_resp").val(row[datasetColleague.columns[3]]+"|"+row[datasetColleague.columns[2]])
	}catch(e){
	    FLUIGC.toast({title: 'error:', message: e + matUsuario + solicitante, type: 'info'});
	}
}

function criar_descricoes() {
	var descricao = `Solicitação de liberação de acesso à VPN para o funcionário: @@`
	descricao += `Nome: ${$("#txt_nomeSolicitante").val()} (${$("#txt_matricula").val()})@@`
	descricao += `Cargo: ${$("#txt_cargo").val()} @@`
	descricao += `Centro de Custo: ${$("#txt_centroCusto").val()}@@`
	descricao += `De: ${$("#txt_dt_inicio").val()} Até: ${$("#txt_dt_fim").val()} @@ @@`
	descricao += `Tipo de Horário: ${$("#invi_tipo_horario").val()} @@ @@`
	descricao += `Aprovações @@`
	descricao +=`Gestor TI: ${$("#colab_33").val()} @@`
	descricao +=`Gestor da Área: ${$("#colab_2").val()} @@`
	descricao +=`Gestor do RH: ${$("#colab_3").val()} @@`

	$("#invi_descricao").val(descricao)
}




// Solicitação de liberação de acesso à VPN para o funcionário: 
// Nome: Jonathas Luiz Guterres Medeiros (10654)
// Cargo: Administrador Redes Pl (366)
// Centro de Custo: Tecnologia da Informacao (10111001)
// De: 15/03/2022 Até: 31/12/9999
// 
// Tipo de Horário: Sem restrição de horário
// 
// Aprovações 
// 
// Gestor TI: Barbara Isabel Grando Veit
// Gestor da Área: Barbara Isabel Grando Veit
// Gestor do RH: Lauro Teixeira Pires