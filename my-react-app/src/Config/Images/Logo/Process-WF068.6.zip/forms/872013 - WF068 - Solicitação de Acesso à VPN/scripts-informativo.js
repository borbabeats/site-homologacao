console.info("load Informativo V1.3");

function montaInformativo(){
    var arrayFields = [];

    arrayFields.push(new Array("title", "Dados do Solicitante"));
    arrayFields.push(new Array("field", "txt_matricula"));
    arrayFields.push(new Array("field", "txt_nomeSolicitante"));
    arrayFields.push(new Array("field", "txt_cargo"));
    arrayFields.push(new Array("field", "txt_centroCusto"));
    
    arrayFields.push(new Array("field", "sl_tempo"));
    arrayFields.push(new Array("field", "txt_dt_inicio"));
    arrayFields.push(new Array("field", "txt_dt_fim"));
    
    arrayFields.push(new Array("field", "ck_termo"));
    arrayFields.push(new Array("field", "txtArea_narrativa"));

    if(parseInt($("#main_stepWF").val()) > 3){
        arrayFields.push(new Array("title", "Aprovação do Gestor da TI"));
        arrayFields.push(new Array("field", "invi_tipo_horario|Tipo de Horário"));
    }
    

    $(".informativo").html(montaHTML(arrayFields));
}

function montaHTML(array){
    var arrayAux;
    var html        =   "";

    for(var i = 0; i < array.length; i++){
        arrayAux    =   array[i];
        html        +=  tipoCampo(arrayAux[0], arrayAux[1]);
    }
    return html;
}

function tipoCampo(tipo, valor){
    switch(tipo){
        case "title":
                return informativo_TITLE(valor);
            break;
        case "field":
                return informativo_FIELD(valor);
            break;
        case "grupo":
                return informativo_GRUPO(valor);
            break; 
        case "addItem":
                return informativo_ADDITEM(valor);
            break;
        case "row":
                return informativo_ROW();
            break; 
        case "closediv":
                return informativo_CLOSEDIV();
            break; 
    }
}

function informativo_TITLE(valor){
    var html    =   '';
    html        +=  '<div class="form-group col-xs-12 col-sm-12 col-md-12 col-lg-12">';
    html        +=  '<blockquote>';
    html        +=  '<p>' + valor + '</p>';
    html        +=  '</blockquote>';
    html        +=  '</div>';

    return html;
}

function informativo_ROW(){            
    return '<div class="row rowInsideWell">';
}

function informativo_CLOSEDIV(){            
    return '</div>';
}


function informativo_FIELD(valor){
    var typeField = valor.split("_")[0];
    if(typeField == "colab"){
        typeField = "txt";
    }

    switch(typeField){
        case "txt":
                return campo_TXT(valor);
            break;
        case "zoom":
                return campo_ZOOM(valor);
            break;
        case "txtArea":
                return campo_TXTAREA(valor);
            break;
        case "txtArea2":
                return campo_TXTAREA2(valor);
            break;
        case "ck":
                return campo_CK(valor);
            break;
        case "rd":
                return campo_RD(valor);
            break;
        case "sl":
                return campo_SL(valor);
            break;
        default:
                return campo_INVI(valor);
            break;
    }
}

function informativo_GRUPO(valor){
    // não impledementado
}

function informativo_ADDITEM(valor){
    
}

function campo_TXT(valor){
    var html    =   '';
    var elemento=   $("input[name='" + valor + "']");
    var label = elemento.parent().siblings("label").text() || elemento.siblings("label").text();
    var valor   =   elemento.val();
    
    html        += '<div class="form-group col-xs-12 col-sm-4 col-md-4 col-lg-3">';
    html        += '<label class="control-label">' + label + '</label>';
    html        += '<p class="form-control-static">' + valor + '</p>';
    html        += '</div>';
            
    return html;
}

function campo_ZOOM(valor){
    var html    =   '';
    var elemento=   $("input[name='" + valor + "']");
    var label   =   elemento.siblings("label").text();
    var valor   =   elemento.val(); 

    html        += '<div class="form-group col-xs-12 col-sm-4 col-md-4 col-lg-3">';
    html        += '<label class="control-label">' + label + '</label>';
    html        += '<p class="form-control-static">' + valor + '</p>';
    html        += '</div>';
            
    return html;
}

function campo_TXTAREA(valor){
    var html    =   '';
    var label   =   $("textarea[name='" + valor + "']").parent().siblings(".panel-heading:first").text();
    var valor   =   $('textarea[name="' + valor + '"]').val();

    html        += '<div class="form-group col-xs-12 col-sm-12 col-md-12 col-lg-12">';
    html        += '<label class="control-label">' + label + '</label>';
    html        += '<p class="form-control-static">' + valor + '</p>';
    html        += '</div>';
            
    return html;
}

function campo_TXTAREA2(valor){
    var html    =   '';
    var label   =   $("textarea[name='" + valor + "']").siblings("label").text();
    var valor   =   $('textarea[name="' + valor + '"]').val();

    html        += '<div class="form-group col-xs-12 col-sm-12 col-md-12 col-lg-12">';
    html        += '<label class="control-label">' + label + '</label>';
    html        += '<p class="form-control-static">' + valor + '</p>';
    html        += '</div>';
            
    return html;
}

function campo_CK(valor){
    var html = '';
    var label = $('input[name="'+ valor +'"]').parent().next('label').text();

        if(label != '' && $('input[name="' + valor + '"]').is(':checked')){
        var valor   =   $('input[name="' + valor + '"]').val();
    
        html        += '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">';
        html        += '<label class="control-label">' + label + '</label>';
        html        += '<p class="form-control-static">' + valor + '</p>';
        html        += '</div>';
        
        return html;
    }
}

function campo_RD(valor){
    var html    =   '';
    var label   =   $('input[name="' + valor + '"]:checked').parents(".panel-body").siblings(".panel-heading:first").text();
    var valor   =   $('input[name="' + valor + '"]:checked').parent().next('label').text();


    html        += '<div class="form-group col-xs-12 col-sm-4 col-md-4 col-lg-3">';
    html        += '<label class="control-label">' + label + '</label>';
    html        += '<p class="form-control-static">' + valor + '</p>';
    html        += '</div>';
            
    return html;
}

function campo_SL(valor){
    var html    =   '';
    var label   =   $("select[name='" + valor + "']").siblings("label").text();
    var valor   =   $("select[name='" + valor + "'] option:selected").text();


    html        += '<div class="form-group col-xs-12 col-sm-4 col-md-4 col-lg-3">';
    html        += '<label class="control-label">' + label + '</label>';
    html        += '<p class="form-control-static">' + valor + '</p>';
    html        += '</div>';
            
    return html;
}

function campo_INVI(valor){
    var html    =   '';

	if(valor == "invi_tableOrd"){
		var elemento=   $("#" + valor);
		
		html    += '<div class="form-group col-xs-12 col-sm-4 col-md-4 col-lg-12 tableFixHead">';
		html    +=         elemento.val();
		html    += '</div>';
        
    }else{
		valor       =   valor.split("|");
		
		var inpuName=   valor[0];
		var elemento=   $("input[name='" + inpuName + "']");
		var label   =   valor[1];
		
		var valor   =   elemento.val();
		
		html        += '<div class="form-group col-xs-12 col-sm-4 col-md-4 col-lg-3">';
		html        += '<label class="control-label">' + label + ':</label>';
		html        += '<p class="form-control-static">' + valor + '</p>';
		html        += '</div>';
    }        
    return html;
}