function displayFields(form,customHTML){
	/* --------------------------------------- Estrutura ----------------------------------------- */
      var numUser 		= 	getValue("WKUser");
      var numAtividade 	= 	getValue("WKNumState");

      form.setValue("main_viewMode", "false");
      form.setShowDisabledFields(true);		// 	Mostra os valores dos campos desabilitados.
      form.setHidePrintLink(true);			//	Retira os botões imprimir do formulário.

      if(form.getFormMode() == "VIEW"){
            form.setValue("main_viewMode", "true");
      }else{
            //Busca Usuario Corrente
            var colleagueMap 	= 	DatasetFactory.getDataset("colleague", null, [DatasetFactory.createConstraint("colleaguePK.colleagueId", numUser, numUser, ConstraintType.MUST)], null);
            var nomeColaborador	=	colleagueMap.getValue(0,"colleagueName");

            var result = pegaUser(numUser, colleagueMap.getValue(0, "login"));
            if(numAtividade == 0){
                  numAtividade = 1;

                  try{
                        if(result == 1){ 
                              form.setValue("invi_id_usuario", numUser);
                              form.setValue("invi_idUsuario", numUser);
                              form.setValue("txt_matricula", parseInt(buscaUserInseridonototvs(numUser)));
                        }
                        else
                              form.setValue("txt_matricula", "Matrícula do Funcinário não encontrada, favor contatar a TI.");
                        
                  }catch (e) {
                        form.setValue("main_descRevisar", e);
                  }
            }else{
                  try{
                        if(result == 1)
                              parseInt(buscaUserInseridonototvs(numUser));
                        else
                              form.setValue("main_descRevisar", "Matrícula do Funcinário não encontrada, favor contatar a TI.");
                        
                  }catch (e) {
                        form.setValue("main_descRevisar", e);
                  }
            }
      /* --------------------------------------- Funções -------------------------------------------- */
            
            //Busca data Atual
            var fullDate 	= 	new Date();
            var date 		= 	fullDate.getDate().toString();
            if(date.length == 1) { date = 0+date; }
            var mes 		= 	(fullDate.getMonth()+1).toString();
            if(mes.length == 1) { mes = 0+mes; }
            var data 		= 	date+"/"+mes+"/"+fullDate.getFullYear();
            //Busca hora Atual
            var h 			= 	addZero(fullDate.getHours());
            var m 			= 	addZero(fullDate.getMinutes());
            var hora 		= 	h + ":" + m;

            var input_colaborador 	= "colab_"	+numAtividade;
            var input_data 			= "data_"	+numAtividade;
            var input_hora		 	= "hora_"	+numAtividade;

            form.setValue(input_colaborador, nomeColaborador);
            form.setEnabled(input_colaborador, false);

            form.setValue(input_data, data);
            form.setEnabled(input_data, false);

            form.setValue(input_hora, hora);
            form.setEnabled(input_hora, false);

            form.setValue("main_stepWF", numAtividade);

            customHTML.append("<script>");
            customHTML.append('\r $("#div_tipHorario").show()')
            customHTML.append('\r $("#div_tipTermo").show()')
            customHTML.append("</script>");
      }	
}

/* Função que adiciona um zero na hora e minuto se necessario */
function addZero(i) {
	
    if (i < 10) {
        i = "0" + i;
    }
    return i;
}

function pegaUser(numUser, login){
	try{
            login = login.replace(".maxiforja.com.br.1", "")
		var result = 0;
		var UsuariosTOTVS = DatasetFactory.getDataset("ds_UsuarioTOTVS",  [login], null, null);

		if(UsuariosTOTVS.getValue(0, "UsuarioFluig") == ""){
                  var colleagueMap = DatasetFactory.getDataset("ds_AtualizaUsuarioFluig", [login, numUser], null, null);
			result = (colleagueMap.getValue(0, "erro") === "") ? 1 : 0;
		}else
                  result = 1;
		
		return result;
	}catch (e){
		return e;
	}
}

function buscaUserInseridonototvs(numUser){
	try{
            var result;
		var UsuariosTOTVS = DatasetFactory.getDataset("ds_UsuarioTOTVS", [numUser], null, null);	

		var erro = UsuariosTOTVS.getValue(0, "Erro") 
		if(erro != null && erro != undefined && erro != "" )
                  result = erro
            else
                  result = UsuariosTOTVS.getValue(0, "cdnUsuario");

            return result;
	}catch (e) {
		return e;
	}		
}