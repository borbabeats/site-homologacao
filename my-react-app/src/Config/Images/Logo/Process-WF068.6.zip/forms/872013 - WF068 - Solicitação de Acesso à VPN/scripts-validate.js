console.info("load Validate V1.9");

function validateForms(ev){
	var validate 	=	"validateStep"+stepWF+"();";
	
	if(eval(validate)){
		blockPage();	// O formulário recebe uma máscara escura
		
		// Se não validou, impede o evento padrão do botão:
		ev.stopImmediatePropagation();
		ev.stopPropagation();
		ev.preventDefault();
		return false;
	}else{
		instrucoesRevisar();
	}
}

function validateForms_mobile(){
	var validate 	=	eval("validateStep"+stepWF+"();");
	var msg			=	"Os campos destacados precisam ser preenchidos.";

	if(validate){
		blockPage();
		throw msg;
	}
}

function blockPage(){
	console.log("Runinng blockPage... ");
	$("#overlay").fadeIn(300);
}

function validateStep1(){
	console.info("validateForm 1 running ... ");

	usuario_solicitante()

	var arrayFields = [];
	
	arrayFields.push("txt_matricula");
	arrayFields.push("txt_nomeSolicitante");
	arrayFields.push("txt_cargo");
	arrayFields.push("txt_centroCusto");
	arrayFields.push("sl_tempo");
	arrayFields.push("txt_dt_inicio");
	arrayFields.push("txt_dt_fim");
	arrayFields.push("minLength_txtArea_narrativa|30");
	arrayFields.push("ck_termo");
	arrayFields.push("invi_usu_resp");

	if($('#invi_usu_resp').val() == ""){
		FLUIGC.toast({title: 'error:', message: 'Favor contatar a TI antes de continuar com a solicitação', type: 'error'});
	}
	
	return readArray(arrayFields);
}

function validateStep2(){
	console.info("validateForm 2 running ... ");
	var arrayFields = [];
	arrayFields.push("reg_etapa2");

	return readArray(arrayFields);
}

function validateStep3(){
	console.info("validateForm 3 running ... ");
	var arrayFields = [];
	arrayFields.push("reg_etapa3");

	return readArray(arrayFields);
}

function validateStep4(){
	console.info("validateForm 4 running ... ");
	var arrayFields = [];

	criar_descricoes()

	arrayFields.push("reg_etapa4");

	if($("input[name='reg_etapa4']").val() == 'Aprovado'){
		if(!$("#ck_termo_assinado").is(":checked") && !$("#ck_termo_assinar").is(":checked")){
			arrayFields.push("ck_termo_assinado");
			arrayFields.push("ck_termo_assinar");
		}
	}

	return readArray(arrayFields);
}

function validateStep33(){
	console.info("validateForm 33 running ... ");
	var arrayFields = [];
	arrayFields.push("reg_etapa33");

	if($("input[name='reg_etapa33']").val() == 'Aprovado'){
		
		if(!$("#ck_temp_liberado").is(":checked") && !$("#ck_temp_comercial").is(":checked")){
			arrayFields.push("ck_temp_liberado");
			arrayFields.push("ck_temp_comercial");
		}
	}

	return readArray(arrayFields);
}

function validateStep6() {
	console.info("validateForm 6 running ... ");
	var arrayFields = [];
	arrayFields.push("invi_validacao|central_content");
	return readArray(arrayFields);
}

function readArray(array){
	var result = false;

	for(i = 0; i < array.length; i++){
		if(validadeType(array[i])){
			result = array;
		}else{
			array.splice(i, 0);
		}
	}

	return result;
}

function validadeType(nameField){
	var typeField = nameField.split("_")[0];
	switch(typeField){
		case "txt":
				return validate_TXT(nameField);
			break;
		case "txtArea":
				return validate_TXTAREA(nameField);
			break;
		case "invi":
				return validate_INVI(nameField);
			break;
		case "zoom":
				return validate_ZOOM(nameField);
			break;
		case "ck":
				return validate_CK(nameField);
			break;
		case "rd":
				return validate_RD(nameField);
			break;
		case "sl":
				return validate_SL(nameField);
			break;
		case "reg":
				return validate_REG(nameField);
			break;
		case "minLength":
				return validate_MINLENGTH(nameField);
			break;
		case "group":
				return validate_GROUPELEMENTS(nameField);
			break;
		case "add":
				return validate_ADDELEMENTS(nameField);
			break;
		case "data":
				return validate_DATA(nameField);
			break;
	}
}

function validate_TXT(nameField){
	var result = false;
	if($("input[name='" + nameField + "']").val() == ""){
		$("input[name='" + nameField + "']").parents(".form-group").addClass("focus");
			result = true;
	}
	return result;
}

function validate_TXTAREA(nameField){
	var result = false;
	if($("textarea[name='" + nameField + "']").val() == ""){
		$("textarea[name='" + nameField + "']").parents(".panel:first").addClass("focus");
			result = true;
	}
	return result;
}

function validate_ZOOM(nameField){
	var result = false;

	if($("select[name='" + nameField + "']").val() == ""){
		$("select[name='" + nameField + "']").parents(".form-group").addClass("focus");
		result = true;
	}
	
	return result;
}

function validate_CK(nameField){
	var result = false;
	if(!($("input[name='" + nameField + "']").is(":checked"))){
		$("input[name='" + nameField + "']").parents("div.input-group").addClass("focus");
		result = true;
	}
	return result;
}

function validate_RD(nameField){
	var result = false;

	if(!($("input[name='" + nameField + "']").is(":checked"))){
		$("input[name='" + nameField + "']").parents(".input-group").addClass("focus");
			result = true;
	}
	return result;
}

function validate_SL(nameField){
	var result = false;

	if($("select[name='" + nameField + "']").val() == ""){
		$("select[name='" + nameField + "']").parents(".form-group").addClass("focus");
			result = true;
	}
	return result;
}

function validate_REG(nameField){
	var result = false;

	if($("input[name='" + nameField + "']").val() == ""){
		$("[data-aprovacao]").addClass("focus");
		result	=	true;
	}

	var justificativa = $("input[name='" + nameField + "']").parent().next().find("textarea");
	if($("input[name='" + nameField + "']").val() != "Aprovado" && justificativa.val() == ""){
		justificativa.parents(".panel").addClass("focus");
		result	=	true;
	}

	return result;
}

function validate_DATA(nameField){
	var result = false;
	nameField  = nameField.replace("_", "-");
	$("["+nameField+"]").each(function(){
		if($(this).val() == "" || $(this).val() == 0){
			$(this).parents(".form-group").addClass("focus");
			result = true;
		}
	});
	return result;
}

function validate_MINLENGTH(nameField){
	try{
		var result = false;
		nameField = nameField.replace("minLength_", "");
		nameField = nameField.split("|");
		var textarea = $("textarea[name='"+nameField[0]+"']").val();
		if(textarea.length < nameField[1]){
			$("textarea[name='" + nameField[0] + "']").parents(".panel:first").addClass("focus");
			mostraAjuda($("textarea[name='" + nameField[0] + "']").closest(".panel").find("span").attr("id"));
			result = true;
		}else{
			$("textarea[name='" + nameField[0] + "']").val(textarea)
		}
		var txt = textarea.split(" ")
		if(!(txt.length > 3)){
			$("textarea[name='" + nameField[0] + "']").parents(".panel:first").addClass("focus");
			mostraAjuda($("textarea[name='" + nameField[0] + "']").closest(".panel").find("span").attr("id"));
			// mostraAlerta(nameField[0])
			result = true;
		}
	}catch (e){alert(e)}
	return result;
}

function validate_GROUPELEMENTS(nameField){
	var result = true;
	nameField = nameField.replace("group_", "");
	
	$("[data-"+nameField+"]").each(function(){
		if(!$(this).is(":checked")){
			$("[data-"+nameField+"]").parents("div.input-group").addClass("focus");
		}else{
			result = false;
		}
	});

	if(!result){
		$("[data-"+nameField+"]").each(function(){
			$(this).parents("div.input-group").removeClass('focus');
		});
	}

	return result;
}

function validate_ADDELEMENTS(nameField){
	var result 	= 	false;
	nameField	=	nameField.replace("add_", "");
	$("[data-"+nameField+"]").each(function(){
		if($(this).val() != "" && $(this).val() != 0){
			$(this).parents(".form-group").addClass("focus");
			result = true;
		}
	});

	return result;
}

function validate_INVI(nameField){
	var result = false;
	nameField 	=	nameField.split("\|");

	if($("input[name='" + nameField[0] + "']").val() == ""){
		$("#" + nameField[1]).addClass("focus");
		result = true;
	}
	return result;
}

function mostraAjuda(element){
	$("#"+element).trigger('mouseover');
}
