
console.info("load Scripts-geral V3.3");
/* ---------------------------------- Variaveis Globais -----------------------------------*/
var viewMode;
var stepWF;

/* ------------------------------ Formulário Carregado / Ativo ---------------------------*/
$(document).on('ready', function () {
    viewMode = $("#main_viewMode").val();
    stepWF = $("#main_stepWF").val();
    documentInfos();  // Metodo que alimenta o cabeçalho
    ativaPainel();
    montaInstrucoesRevisar();
    // build_grid_information()

    $('#myTab').find('a').on('click', function () {
        if (viewMode == "false") {
            const etapa = $(this).attr("href").replace("#etapa", "")
            refresh_mainStep(etapa);
            $('#myTab').find('a').each(function (index, element) {
                $($(element).attr("href")).hide();
                if (stepWF == $(element).attr("href").replace("#etapa", ""))
                    $($(element).attr("href")).show();
            })
        }
    });

    try {
        loadInAllSteps();
    } catch (e) {
        console.error("O Script loadInAllSteps não pode ser executado. " + e)
    }

    carregaScriptsAPIFLUIG();
    carregaScriptsMascaraDinheiro();
    montaInformativo();

    if (viewMode == "true") {
        escondeTodosCamposVaziosTodasEtapasDoMural();
        viewModeOn();
    } else if (viewMode == "false") {
        escondeCamposVaziosDestaEtapaDoMural();
        if (verificaEtapaExiste()) {
            var command = "loadStep" + stepWF + "();";
            try {
                eval(command);
            } catch (e) {
                console.error("O Script loadStep" + stepWF + " não pode ser executado. " + e)
            }
        }

        // Funções que executam os scripts dos botões de aprovação.
        $('[data-aprovacao]').on('click', function () {
            // Grava no campo invisivel qual a escolha feita
            $(this).parents(".row").find("input").val($(this).data('aprovacao'));
            rodaScriptBotoesAprovacao(this);
        });

        // Função que desabilita o overlay preto
        $(document).on('click', function () {
            $("#overlay").fadeOut(300, function () {
                $('.focus').removeClass('focus');
                $(".fluigicon").trigger('mouseout');
            });
        });
    }

    modoTeste();
});

//  Metodo que alimenta o cabeçalho <p> (utilizando inputs invisiveis)
function documentInfos() {
    $("#cb_numSolic").html($("#main_numSolic").val());
    $("#cb_etapaSolic").html($("#main_etapa").val());
    $("#cb_statusSolic").html($("#main_status").val());
    $("#cb_dataSolic").html($("#main_dataAbertura").val());
    $("#cb_horaSolic").html($("#main_horaAbertura").val());
}

//  Metodo que executa as animações dos botões de aprovação
function rodaScriptBotoesAprovacao(botao) {
    var div_invisivel = $(botao).parents(".row").next();

    $(botao).addClass("selected");
    $(botao).parent().siblings().children().removeClass("selected");
    var estadoAprovacao = $(botao).data("aprovacao");

    alteraEstadoJustificativa(estadoAprovacao, div_invisivel, $(botao).text());
}

function alteraEstadoJustificativa(estadoAprovacao, div_invisivel, nomeBotao) {
    if (estadoAprovacao == "Aprovado" || estadoAprovacao == "") {
        div_invisivel.hide("slow").find('textarea.form-control').val('');
    } else if (estadoAprovacao == "Reprovado") {
        div_invisivel.removeClass("panel-warning");
        div_invisivel.addClass("panel-danger");
        div_invisivel.find(".panel-heading").text("Justificativa:");
        div_invisivel.show("slow");
    } else if (estadoAprovacao == "Revisar") {
        div_invisivel.removeClass("panel-danger");
        div_invisivel.addClass("panel-warning");
        div_invisivel.find(".panel-heading").text("Justificativa:");
        div_invisivel.show("slow");
    }
}

//  Metodo que "limpa / des-seleciona" todos os campos pertinentes
function resetaTodosOsCampos(element) {
    if (element.indexOf("etapa") >= 0) {
        $(element).find("input:radio").removeAttr('checked')
        $(element).find(".div-Invisivel").find("input[type=text]").val("");
        $(element).find(".div-Invisivel").find("select").val("");
        $(element).find(".div-Invisivel").find("textarea").val("");
        $(element).find(".div-Invisivel").find("input:checkbox").prop('checked', false);
        $(element).find(".div-Invisivel").find("input:radio").removeAttr('checked');
        $(element).find(".div-Invisivel").find("input[type=zoom]").val("");
        $(element).find("input[type=hidden]").val("");
    } else {
        $(element).find("input[type=text]").val("");
        $(element).find("textarea").val("");
        $(element).find("input:checkbox").prop('checked', false);
        $(element).find("input:radio").removeAttr('checked');
        $(element).find("input[type=zoom]").val("");
    }
}

//  Script responsável por mostrar tanto a aba quanto o conteudo da etapa
function ativaPainel() {
    // Percorre a lista (aba do Cabeçalho) para ativar a aba referente a etapa
    $("#myTab").find("li").each(function () {
        var getHref = $(this).find("a").attr("href");
        getHref = getHref.replace("#etapa", "");;
        if (getHref == stepWF) {
            $(this).show();
            $(this).addClass("active");
        }
    });

    $("#etapa" + stepWF).show();
    $("#etapa" + stepWF).addClass("active");
}

function verificaEtapaExiste() { // Retorna True ou false
    var result = false;

    var etapaExistente;
    $("#myTab").find("a").each(function () {
        etapaExistente = $(this).attr("href");
        etapaExistente = etapaExistente.replace("#etapa", "");

        if (stepWF == etapaExistente) {
            result = true;
        }
    });
    return result;
}

function instrucoesRevisar() {
    var etapa = $("#main_stepWF").val();

    if ($("#etapa" + etapa).find("input[name='reg_etapa" + etapa + "']").val() == "Revisar") {
        var instrucoes = $("#etapa" + etapa).find("textarea").val();
        var colaborador = $("#colab_" + etapa).val();
        var nomeEtapa = $("#main_etapa").val();
        $("#main_descRevisar").val(colaborador + "-;-" + nomeEtapa + "-;-" + instrucoes);
    } else {
        $("#main_descRevisar").val("");
    }
}

function montaInstrucoesRevisar() {
    var revisar = $("#main_descRevisar").val();

    if (revisar != "") {
        var html = "";
        revisar = revisar.split("-;-");

        html += '<div class="bs-callout bs-callout-warning" id="callout-navbar-overflow">'
        html += '<h4>A etapa <b>' + revisar[1] + '</b> solicitou uma revisão:</h4>'
        html += '<p><i>' + revisar[2] + '</i></p>'
        html += '<p>Responsável: ' + revisar[0] + '</p>'
        html += '</div>'

        $("#painel-revisar").html(html);
    }
}

function escondeCamposVaziosDestaEtapaDoMural() {
    $('#etapa' + $("#main_stepWF").val()).find('.informativo').find('p').filter(function () {
        if (($(this).text().trim()).length == 0) {
            $(this).parents(".form-group").remove();
        }
    });
}

function escondeTodosCamposVaziosTodasEtapasDoMural() {
    $('.informativo').find('p').filter(function () {
        if (($(this).text().trim()).length == 0) {
            $(this).parents(".form-group").remove();
        }
    });
}

function carregaScriptsAPIFLUIG() {
    FLUIGC.popover('.fluigicon', { trigger: 'hover', placement: 'bottom', html: 'true' });
    FLUIGC.calendar('.data');
    $(".data").mask("99/99/9999");
    $(".hora").mask("99:99");
}

function carregaScriptsMascaraDinheiro() {
    $(".money").maskMoney({ allowNegative: false, thousands: '.', decimal: ',', affixesStay: false });
}

function isMobile() {
    var userAgent = navigator.userAgent.toLowerCase();
    if (userAgent.search(/(android|avantgo|blackberry|bolt|boost|cricket|docomo|fone|hiptop|mini|mobi|palm|phone|pie|tablet|up\.browser|up\.link|webos|wos)/i) != -1) {
        return true;
    }
}

function modoTeste() {
    if ($("#main_testeMode").val() == "true") {
        $("#botaoTeste").show();
        $('[data-send]').attr("disabled", false);
    }

    // Função que desabilita o overlay preto
    $(document).on('click', function () {
        $("#overlay").fadeOut(300, function () {
            $('.focus').removeClass('focus');
            $(".fluigicon").trigger('mouseout');
        });
    });
}

function build_grid_information() {
    try {
        var thead = '<thead> <th class="th th-center"> Campos </th>';
        var tbody = '<tbody>', etapa_info = 0;
        var array_thead = []
        var array_type = ['label.control-label', 'label.form-control', 'div.panel-heading', 'button']

        var array_not = ['Hora', 'Responsável', 'Solicitante', 'Data', 'Justificativa', 'Revisar', 'Reprovado', 'Sim', 'Não', ' ', 'Cancelado']

        $('#myTab').find('a').each(function (index, element) {
            if ($(element).closest('li').attr('style') != 'display:flex') {
                thead += `<th class="th th-center"> ${element.innerHTML} </th>`
                array_thead.push($(element).attr('href'))
                etapa_info = index + 2
            }
        });
        thead += '</thead>'

        array_thead.forEach(function (element, index) {
            array_type.forEach(function (label, index) {
                tbody += build_label_or_div(element, label, array_thead, element.replace('#etapa', ''))
            })
        });

        function build_label_or_div(element, label, array, cont) {
            var html = '';
            $(element).find(label).each(function (index, element) {
                var text = element.innerText.replace(':', ''), result = false;
                if (text.trim() === '') { return }
                array_not.forEach(function (value, index) {
                    text == value ? result = true : 'Revisar' == text.substring(0, 7) ? result = true : ''
                })
                if (!result)
                    html += `<tr> <td class="th th-center ${cont}"> ${text.replace('Aprovado', 'Aprovação (' + name_etapa_aprovacao(cont) + ')')} </td> ${build_information_EorV(array, '', cont)} <td class="th contagem"> ${cont} </td> </tr>`
            })
            return html
            function name_etapa_aprovacao(cont) {
                var nome
                $('a').each(function (index, element) {
                    (index + 1) == cont ? nome = element.innerText.trim() : ''
                });
                return nome;
            }
        }

        function build_information_EorV(array_, html_, cont) {
            array_.forEach(function (value, index) {
                if (parseInt(value.replace('#etapa', '')) == parseInt(cont))
                    html_ += '<td class="th th-center"> E </td>'
                else if (parseInt(value.replace('#etapa', '')) < parseInt(cont))
                    html_ += '<td  style="background-color:#abb0b5">  </td>'
                else if (parseInt(value.replace('#etapa', '')) > parseInt(cont))
                    html_ += '<td class="th th-center"> V </td>'
            })
            return html_
        }

        $('#tb_info').append(thead + tbody + '</tbody>');

        var myTable = document.getElementById('tb_info');
        sortTable(myTable, 'asc', 4);

        let valid = document.getElementById('invi_validacao')


        $('.contagem').remove()
        if (document.getElementById('tb_info') == null) {
            console.log($('#tb_info').html())
        }

        if (document.getElementById('etapa' + etapa_info) == null) {
            console.log(create_html(etapa_info))
        }

        if (valid == null) {
            console.warn('Campo "invi_validacao" não existe');
            console.warn('<input name="invi_validacao" id="invi_validacao" type="hidden">');
        }

        console.warn(`<li style="display:flex"><a href="#etapa${etapa_info}" role="tab" data-toggle="tab"> Informações Adicionais </a></li>`);

        console.warn(`function validateStep${etapa_info}() {\r
                        console.info("validateForm ${etapa_info} running ... ");\r
                        var arrayFields = [];\r
                        arrayFields.push("invi_validacao|central_content");\r
                        return readArray(arrayFields);\r
        }`);

    } catch (error) {
        FLUIGC.toast({ title: 'Warning!', message: error, type: 'warning' });
    }

    function sortTable(table, dir, n) {
        try {
            let rows, switching, i, x, y, shouldSwitch, switchcount = 0;
            switching = true;
            /*Faça um loop que continuará até nenhuma troca foi feita:*/
            while (switching) {
                //comece dizendo: nenhuma troca é feita:
                switching = false;
                rows = table.rows;
                /*Faça um loop por todas as linhas da tabela (exceto o primeiro, que contém cabeçalhos da tabela):*/
                for (i = 1; i < (rows.length - 1); i++) {
                    //comece dizendo que não deve haver alternância:
                    shouldSwitch = false;
                    /*Obtenha os dois elementos que você deseja comparar,um da linha atual e o outro da próxima:*/
                    x = rows[i].getElementsByTagName("TD")[n];
                    y = rows[i + 1].getElementsByTagName("TD")[n];
                    /*verifique se as duas linhas devem mudar de lugar, com base na direção, asc ou desc:*/
                    if (dir == "asc") {
                        if (Number(x.innerHTML) > Number(y.innerHTML)) {
                            //Nesse caso, marque como uma opção e interrompa o loop:
                            shouldSwitch = true;
                            break;
                        }
                    }
                }
                if (shouldSwitch) {
                    /*Se um interruptor foi marcado, faça-o e marque que uma troca foi feita:*/
                    rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
                    switching = true;
                    //Cada vez que uma troca for concluída, aumente essa contagem em 1:
                    switchcount++;
                } else {
                    /*Se nenhuma mudança foi feita E a direção for "asc", defina a direção para "desc" e execute o loop while novamente.*/
                    if (switchcount == 0 && dir == "asc") {
                        dir = "desc";
                        switching = true;
                    }
                }
            }
        } catch (error) {
            // FLUIGC.toast({ title: 'Warning!', message: error, type: 'warning' });
        }
    }
}

function create_html(count) {
    return `<div class="tab-pane" id="etapa${count}">
        <div class="row">
            <div class="form-group col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <div class="panel panel-primary">
                    <div class="panel-heading "> Processos Relacionados: <span
                            id="help_11"
                            class="fluigicon fluigicon-question-sign fluigicon-xs bs-docs-popover-hover"
                            data-toggle="popover" title=""
                            data-content="Lista de Processos que esse workflow consulta."
                            data-original-title="Popover title">
                        </span> </div>
                    <div class="panel-body ">
                        <table class="table table  table- table-hover">
                            <thead>
                                <th width="10%"> </th>
                                <th class="th th-center" colspan="">
                                    Processo </th>
                            </thead>
                            <tbody>
                                <tr>
                                    <td class="th th-center"> <img
                                            src="./Resources/fluigicon-process.png"
                                            height="25"> </td>
                                    <td class="th th-center"> <a
                                            href="http://fluig.maxiforja.local/portal/p/1/pageworkflowview?processID=WF024"
                                            target="_blank"> WF024 -
                                            Termo de Aditivo da
                                            Política de Viagens
                                        </a> </td>
                                </tr>
                            </tbody>
                        </table>
                        <table class="control-label"></table>
                    </div>
                </div>
            </div>
            <div class="form-group col-xs-12 col-sm-12 col-md-6 col-lg-6">
                <div class="panel panel-primary">
                    <div class="panel-heading "> Documentos Relacionados:</div>
                    <div class="panel-body ">
                        <table class="table table  table- table-hover">
                            <thead>
                                <th width="10%"> </th>
                                <th class="th th-center" colspan="">
                                    Documento
                                </th>
                            </thead>
                            <tbody>
                                <tr>
                                    <td class="th th-center"> <img
                                            src="./Resources/fluigicon-file-doc.png"
                                            height="25"> </td>
                                    <td class="th th-center"> <a
                                            href="http://fluig.maxiforja.local/portal/p/1/ecmnavigation?app_ecm_navigation_doc=866805"
                                            target="_blank">
                                            REG504 - Registro de
                                            Quilometragem e
                                            Relatório de Viagem
                                        </a>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="th th-center"> <img
                                            src="./Resources/fluigicon-file-doc.png"
                                            height="25"> </td>
                                    <td class="th th-center"> <a
                                            href="http://fluig.maxiforja.local/portal/p/1/ecmnavigation?app_ecm_navigation_doc=785003"
                                            target="_blank">
                                            IFN004 - Politica de
                                            Viagens
                                        </a>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <table class="control-label"></table>

                    </div>
                </div>
            </div>
            <div class="form-group col-xs-12 col-sm-12 col-md-12 col-lg-12">
                <div class="panel panel-primary">
                    <div class="panel-heading "> Nível de Acesso de Informações:
                    </div>
                    <div class="panel-body bodyHeight">
                        <table class="table table  table-bordered table-hover"
                            id="tb_info">
                        </table>
                        <div
                            class="form-group col-xs-12 col-sm-12 col-md-6 col-lg-1">
                            <label class="control-label"> E -
                                Executa</label>
                        </div>
                        <div
                            class="form-group col-xs-12 col-sm-12 col-md-6 col-lg-1">
                            <label class="control-label"> O - Oculta</label>
                        </div>
                        <div
                            class="form-group col-xs-12 col-sm-12 col-md-6 col-lg-1">
                            <label class="control-label"> V -
                                Visualiza</label>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>`
}

