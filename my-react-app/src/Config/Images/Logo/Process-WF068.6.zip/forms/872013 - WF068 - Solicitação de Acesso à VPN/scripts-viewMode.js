console.info("load viewMode V1.9");
var stepWF;

function viewModeOn(){
    console.info("<=== START VIEW MODE ===>");
    var etapa   =   $("#main_stepWF").val();
    mostraAbaTodasEtapas();
    disableAllElements();
    showAllHidenSubDivsInStep();
    mostraBotaoAtivado(etapa);
    runThisStep(etapa);

    $("a").on("click", function(){
        etapa   = $(this).attr("href");
        etapa   = etapa.replace("#etapa", "");
        refresh_mainStep(etapa);
        showThisStep(etapa);
        runThisStep(etapa);
        showAllHidenSubDivsInStep();
        mostraBotaoAtivado(etapa);
    });
}

function refresh_mainStep(etapa){
    $("#main_stepWF").val(etapa);
    stepWF =  $("#main_stepWF").val();
}
//  Metodo que funciona apenas em view mode, mostra qual botão foi selecionado
function mostraBotaoAtivado(etapa){
    var estadoBotao     = $("input[name=reg_etapa"+etapa+"]").val();
    var div_invisivel   = $("input[name=reg_etapa"+etapa+"]").parent().next();
    var nomeBotao;

    $("#etapa"+etapa).find("[data-aprovacao='"+estadoBotao+"']").addClass("selected");
    nomeBotao           = $("#etapa"+stepWF).find(".selected").text();

    $("#etapa"+etapa).find("[data-aprovacao='"+estadoBotao+"']").parent().siblings().children().removeClass("selected");

    alteraEstadoJustificativa(estadoBotao, div_invisivel, nomeBotao);
}

function showThisStep(numStep){
    $("#etapa"+numStep).show();
}

//  Mostra TODAS as DIVs ocultas da etapa selecionada
function showAllHidenSubDivsInStep(){
    $("#myTab").find("li").each(function (){
        var hrefEtapa   = $(this).find("a").attr("href");
        hrefEtapa       = hrefEtapa.replace("#etapa", "");

        if(stepWF == hrefEtapa){
            $("#etapa"+hrefEtapa).find("div").show();
        }else{
            $("#etapa"+hrefEtapa).find("div").hide();
        }
    });
}

//  Executa os metodos das etapas
function runThisStep(etapa){
    var run = "loadStep"+etapa+"();";
    eval(run);
}

//  Desabilita todos os campos e botões
function disableAllElements(){
    $("input, textarea, select").attr("disabled", true);
    $("span").css("pointer-events", "none");
    $('button').attr("disabled", true);
}

function mostraAbaTodasEtapas(){
    $("li").each(function(){
        $(this).show();

        var step    =   $(this).children().attr("href");
        step        =   step.replace("#etapa", "");

        if(step == stepWF){
            $(this).addClass("active");
            showThisStep(step);
        }
    });
}