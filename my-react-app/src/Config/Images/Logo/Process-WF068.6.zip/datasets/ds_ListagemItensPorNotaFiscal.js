function createDataset(fields, constraints, sortFields){
	var newDataset = DatasetBuilder.newDataset();
	newDataset.addColumn("Sequencia");
	newDataset.addColumn("itCodigo");
	newDataset.addColumn("unidadeMedida");
	newDataset.addColumn("descItem");
	newDataset.addColumn("natOperacao");
	newDataset.addColumn("quantidade");
	newDataset.addColumn("precoUnit");
	newDataset.addColumn("precoTotal");
	newDataset.addColumn("lote");
	newDataset.addColumn("numPedido");
	newDataset.addColumn("numeroOrdem");
	newDataset.addColumn("parcela");
	// newDataset.addColumn("CódEDescrição");


	//  var Serie    =  "9"
	//  var NrDoc   =  "0429426"
	//  var CodEmitente  =  "3639"
	//  var NatOper =  "1101"
	var Serie  =  ""+fields[0]
	var NrDoc  =  ""+fields[1]
	var CodEmitente  =  ""+fields[2]
	var NatOper  =  ""+fields[3]

	try {
		// Utiliza o ServiceManager para obter uma referencia ao servico.
		var serviceProvider = ServiceManager.getService('TOTVS');
		var serviceLocator  = serviceProvider.instantiate('com.totvs.framework.ws.execbo.service.WebServiceExecBO');
		var service         = serviceLocator.getWebServiceExecBOPort();

		// Faz login e recebe o token de autenticacao
		var token = service.userLogin("fluig");

		var json  = montaJson(Serie ,NrDoc ,CodEmitente ,NatOper);

		// Chama a procedure passando os parametros e o token de autenticacao.
		var resp = service.callProcedureWithToken(token, "dzp/dzwf001.p", "ws-busca-itens-nota-entrada", json);

		var respObj = JSON.parse(resp);

		var callProcedureWithTokenResponse = JSON.parse(respObj[0].value);

		for (var i in callProcedureWithTokenResponse.records){
            	newDataset.addRow(new Array(
					callProcedureWithTokenResponse.records[i]["sequencia"],
					callProcedureWithTokenResponse.records[i]["it-codigo"],
					callProcedureWithTokenResponse.records[i]["un"], // unidade medida item
					callProcedureWithTokenResponse.records[i]["desc-item"],
					callProcedureWithTokenResponse.records[i]["nat-operacao"],
					callProcedureWithTokenResponse.records[i]["quantidade"],
					callProcedureWithTokenResponse.records[i]["preco-unit"],
					callProcedureWithTokenResponse.records[i]["preco-total"],
					callProcedureWithTokenResponse.records[i]["lote"],
					callProcedureWithTokenResponse.records[i]["num-pedido"],
					callProcedureWithTokenResponse.records[i]["numero-ordem"],
					callProcedureWithTokenResponse.records[i]["parcela"]
				)
            );
	    }
	} catch (e) {
		log.info("ERRO: "+e);
	}

	return newDataset;
}

function montaJson(Serie ,NrDoc ,CodEmitente ,NatOper){
	log.info("montaJson");

    var sequencia   = new Object();
	sequencia.type  = "integer";
	sequencia.name  = "sequencia";
	sequencia.label = "sequencia";
    
    var itCodigo   = new Object();
	itCodigo.type  = "character";
	itCodigo.name  = "it-codigo";
	itCodigo.label = "itCodigo";

    var unidadeMedida   = new Object();
	unidadeMedida.type  = "character";
	unidadeMedida.name  = "un";
	unidadeMedida.label = "unidadeMedida";

    var descItem   = new Object();
	descItem.type  = "character";
	descItem.name  = "desc-item";
	descItem.label = "descItem";

    var natOperacao   = new Object();
	natOperacao.type  = "character";
	natOperacao.name  = "nat-operacao";
	natOperacao.label = "natOperacao";

    var quantidade   = new Object();
	quantidade.type  = "decimal";
	quantidade.name  = "quantidade";
	quantidade.label = "quantidade";

    var precoUnit   = new Object();
	precoUnit.type  = "decimal";
	precoUnit.name  = "preco-unit";
	precoUnit.label = "precoUnit";

    var precoTotal   = new Object();
	precoTotal.type  = "decimal";
	precoTotal.name  = "preco-total";
	precoTotal.label = "precoTotal";

    var lote   = new Object();
	lote.type  = "character";
	lote.name  = "lote";
	lote.label = "lote";

    var numPedido   = new Object();
	numPedido.type  = "integer";
	numPedido.name  = "num-pedido";
	numPedido.label = "numPedido";

    var numeroOrdem   = new Object();
	numeroOrdem.type  = "integer";
	numeroOrdem.name  = "numero-ordem";
	numeroOrdem.label = "numeroOrdem";

    var parcela   = new Object();
	parcela.type  = "integer";
	parcela.name  = "parcela";
	parcela.label = "parcela";

    //formador do parametro value para temp-table
	var tTable		= new Object();
    tTable.name     = "tt-itens-nota-entrada";
    tTable.records  = new Array();
    tTable.fields	= [sequencia, itCodigo, unidadeMedida, descItem, natOperacao, quantidade, precoUnit, precoTotal, lote, numPedido, numeroOrdem, parcela];

    //array para receber os parametros input da chamada da função
	//Série ,NrDoc ,CodEmitente ,NatOper
    var input1		 = new Object();
    input1.dataType  = "character";
    input1.name  	 = "p-serie-docto";//procedure input
    input1.label 	 = "p-serie-docto";
    input1.type 	 = "input";
    input1.value 	 = Serie;

    var input2 		 = new Object();
    input2.dataType  = "character";
    input2.name  	 = "p-nro-docto";//procedure input
    input2.label 	 = "p-nro-docto";
    input2.type 	 = "input";
    input2.value 	 = NrDoc;

    var input3		 = new Object();
    input3.dataType  = "integer";
    input3.name  	 = "p-cod-emitente";//procedure input
    input3.label 	 = "p-cod-emitente";
    input3.type 	 = "input";
    input3.value 	 = CodEmitente;

    var input4 		 = new Object();
    input4.dataType  = "character";
    input4.name  	 = "p-nat-operacao";//procedure input
    input4.label 	 = "p-nat-operacao";
    input4.type 	 = "input";
    input4.value 	 = NatOper;


	var output 	  	= new Object();
	output.dataType	= "temptable";
	output.name   	= "tt-itens-nota-entrada"; //nome da temp-table
	output.type   	= "output";
	output.value  	= tTable;

	var params = [input1, input2, input3, input4, output];

	log.info(JSON.stringify(params));
	//conversor dos parametros de input para Json
	return JSON.stringify(params);
}
