function createDataset(fields, constraints, sortFields){
	var newDataset = DatasetBuilder.newDataset();
	newDataset.addColumn("Resposta");
	newDataset.addColumn("CodPessoa");
	newDataset.addColumn("Nome");
	newDataset.addColumn("Empresa");
	
	var documento	= ""+fields[1];
	//var documento	= "";
        
	try {
		// Utiliza o ServiceManager para obter uma referencia ao servico.
		var serviceProvider = ServiceManager.getService('TOTVS');
		var serviceLocator  = serviceProvider.instantiate('com.totvs.framework.ws.execbo.service.WebServiceExecBO');
		var service         = serviceLocator.getWebServiceExecBOPort();

		// Faz login e recebe o token de autenticacao
		var token = service.userLogin("fluig");

		var json  = montaJson(documento);

		// Chama a procedure passando os parametros e o token de autenticacao.
		var resp = service.callProcedureWithToken(token, "dzp/dzwf002.p", "ws-verifica-doc-pessoa-fisica", json);
		
		var respObj = JSON.parse(resp);
		
		newDataset.addRow([respObj[3].value, respObj[0].value, respObj[1].value, respObj[2].value ]);

		return newDataset;
	} catch (e) {
		log.info("ERRO: "+e);
		return e;

	}

	
}

function montaJson(documento){
	log.info("montaJson");
	
	var resposta 	= {}
	resposta.type 	= "logical";
	resposta.name 	= "p-resposta";
	resposta.label 	= "p-resposta";
	
	var codigo 		= {}
	codigo.type 	= "integer";
	codigo.name 	= "p-cod-pessoa";
	codigo.label 	= "p-cod-pessoa";
	
	var nome 		= {}
	nome.type 		= "character";
	nome.name 		= "p-nome-pessoa";
	nome.label 		= "p-nome-pessoa";

	var emp 		= {}
	emp.type 		= "character";
	emp.name 		= "p-empresa";
	emp.label 		= "p-empresa";
    
    //array para receber os parametros input da chamada da função
   	
	var input 		= {}
	input.dataType	= "character";
	input.name 		= "p-documento";
	input.label 	= "p-documento";
	input.type 		= "input";
	input.value 	= documento;
    
	var output2 		= {}
	output2.dataType	= "integer";
	output2.name 		= "p-cod-pessoa";
	output2.type 		= "output";
	output2.value 		= codigo;

	var output1 		= {}
	output1.dataType	= "logical";
	output1.name 		= "p-resposta";
	output1.type 		= "output";
	output1.value 		= resposta;
	
	
	var output3 		= {}
	output3.dataType	= "character";
	output3.name 		= "p-nome-pessoa";
	output3.type 		= "output";
	output3.value 		= nome;

	var output4 		= {}
	output4.dataType	= "character";
	output4.name 		= "p-empresa";
	output4.type 		= "output";
	output4.value 		= emp;
	
	var params = [input, output2, output3, output4, output1];
	
	log.info(JSON.stringify(params));
	//conversor dos parametros de input para Json
	return JSON.stringify(params);
}