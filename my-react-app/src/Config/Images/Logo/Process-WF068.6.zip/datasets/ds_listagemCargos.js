function createDataset(fields, constraints, sortFields){
	var newDataset = DatasetBuilder.newDataset();
	newDataset.addColumn("Código");
	newDataset.addColumn("Nome");
	newDataset.addColumn("Atividades");

	var filtro = '';

		if (constraints[0].initialValue != null && constraints[0].initialValue != 300) 
			filtro = "" + constraints[0].initialValue;
		else
			filtro = "" + constraints[1].initialValue;
	//var filtro = "Analista";

	try {
		// Utiliza o ServiceManager para obter uma referencia ao servico.
		var serviceProvider = ServiceManager.getService('TOTVS');
		var serviceLocator  = serviceProvider.instantiate('com.totvs.framework.ws.execbo.service.WebServiceExecBO');
		var service         = serviceLocator.getWebServiceExecBOPort();

		// Faz login e recebe o token de autenticacao
		var token = service.userLogin("fluig");

		var json  = montaJson(filtro);

		// Chama a procedure passando os parametros e o token de autenticacao.
		var resp = service.callProcedureWithToken(token, "dzp/dzwf001.r", "ws-busca-cargo", json);

		var respObj = JSON.parse(resp);

		var callProcedureWithTokenResponse = JSON.parse(respObj[0].value);
		
		for (var i in callProcedureWithTokenResponse.records){
	    	newDataset.addRow(new Array(
			callProcedureWithTokenResponse.records[i]["cod-cargo"], 
			callProcedureWithTokenResponse.records[i]["desc-cargo"], 
			callProcedureWithTokenResponse.records[i]["desc-atividades"])
			);
	    }
	} catch (e) {
		log.info("ERRO: "+e);
	}

	return newDataset;
}

function montaJson(filtro){
	log.info("montaJson");

	var codigo 		= new Object();
	codigo.type 	= "integer";
	codigo.name 	= "cod-cargo";
	codigo.label 	= "codigo";

	var nome 		= new Object();
	nome.type 		= "character";
	nome.name 		= "desc-cargo"; 
	nome.label 		= "nome"; 

	var atividades		= new Object();
	atividades.type 	= "character";
	atividades.name 	= "desc-atividades";  
	atividades.label 	= "atividades";
	    
    //formador do paremetro value para temp-table
    var tt_cargo 		= new Object();
    tt_cargo.name 		= "tt-cargo";
    tt_cargo.records 	= new Array();
    tt_cargo.fields 	= [codigo, nome, atividades];
    
    //array para receber os parametros input da chamada da função
   
    var tt_cargo_filt 		= new Object();
    tt_cargo_filt.dataType	= "character";
    tt_cargo_filt.name 		= "p-nome-cargo";
    tt_cargo_filt.label 	= "p-nome-cargo";
    tt_cargo_filt.type 		= "input";
    tt_cargo_filt.value 	= filtro;
    
	var tt_cargo_var 		= new Object();
	tt_cargo_var.dataType	= "temptable";
	tt_cargo_var.name 		= "tt-cargo";
	tt_cargo_var.type 		= "output";
	tt_cargo_var.value 		= tt_cargo;
	
	var params = [tt_cargo_filt, tt_cargo_var];
	
	log.info(JSON.stringify(params));
	//conversor dos parametros de input para Json
	return JSON.stringify(params);
}
