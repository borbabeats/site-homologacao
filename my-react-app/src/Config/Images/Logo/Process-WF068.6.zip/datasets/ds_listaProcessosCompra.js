function createDataset(fields, constraints, sortFields){
	log.info("começou teste filtro")
	var newDataset = DatasetBuilder.newDataset();
	newDataset.addColumn("Processo");
	newDataset.addColumn("Descrição");
	newDataset.addColumn("Data Inicial");
	newDataset.addColumn("Data Final");
	newDataset.addColumn("Situação");

	var filtro = '';

		if (constraints[0].initialValue != null && constraints[0].initialValue != 300) 
			filtro = "" + constraints[0].initialValue;
		else
			filtro = "" + constraints[1].initialValue;
	//var filtro  = "3014"; // coloca uma num valido 992018 992017 3024 3023 3021 3010 3007
	//situacoes  = 1 - em estudo; 2 - em aprovacao; 3 - ativo; 4 - bloqueado; 5 - encerrado p/requis e compra; 
	//6 - encerrado p/todos os motivs; 7 - cancelado 
	try {
		// Utiliza o ServiceManager para obter uma referencia ao servico.
		var serviceProvider = ServiceManager.getService('TOTVS');
		var serviceLocator  = serviceProvider.instantiate('com.totvs.framework.ws.execbo.service.WebServiceExecBO');
		var service         = serviceLocator.getWebServiceExecBOPort();

		// Faz login e recebe o token de autenticacao
		var token = service.userLogin("fluig");

		var json  = montaJson(filtro);

		// Chama a procedure passando os parametros e o token de autenticacao.
		var resp = service.callProcedureWithToken(token, "dzp/dzwf001.p", "ws-busca-proc-compra-numero", json);

		var respObj = JSON.parse(resp);

		var callProcedureWithTokenResponse = JSON.parse(respObj[0].value);
		
		for (var i in callProcedureWithTokenResponse.records){
	    	newDataset.addRow(new Array(
			callProcedureWithTokenResponse.records[i]["nr-processo"], 
			callProcedureWithTokenResponse.records[i]["descricao"], 
			callProcedureWithTokenResponse.records[i]["dt-ini-proc"],
			callProcedureWithTokenResponse.records[i]["dt-prev-fim"],
			callProcedureWithTokenResponse.records[i]["ind-situacao"])
			);
	    }
	} catch (e) {
		log.info("ERRO: "+e);
	}

	return newDataset;
}

function montaJson(filtro){
	log.info("montaJson");

	var nrProcesso     	= new Object();
	nrProcesso.type 	= "integer";
	nrProcesso.name 	= "nr-processo";
	nrProcesso.label    = "nrProcesso";

	var descricao 		= new Object();
	descricao.type 		= "character";
	descricao.name 		= "descricao"; 
	descricao.label 	= "descricao";

	var dtIniProc 		= new Object();
	dtIniProc.type 		= "date";
	dtIniProc.name 		= "dt-ini-proc"; 
	dtIniProc.label 	= "dtIniProc";
	
	var dtPrevFim 		= new Object();
	dtPrevFim.type     	= "date";
	dtPrevFim.name 	    = "dt-prev-fim"; 
	dtPrevFim.label 	= "dtPrevFim";
	
	var situacao 		= new Object();
	situacao.type     	= "integer";
	situacao.name 	    = "ind-situacao"; 
	situacao.label 		= "situacao";
	
    //formador do parametro value para temp-table
	var tTable			= new Object();
    tTable.name 		= "tt-proc-compra";
    tTable.records 		= new Array();
    tTable.fields		= [nrProcesso, descricao, dtIniProc, dtPrevFim, situacao];
    
    //array para receber os parametros input da chamada da função
   
    var input 		= new Object();
    input.dataType	= "integer";
    input.name  	= "p-nr-processo";
    input.label 	= "p-nr-processo";
    input.type 	    = "input";
    input.value 	= filtro;
    
	var output 		= new Object();
	output.dataType	= "temptable";
	output.name 	= "tt-proc-compra";
	output.type 	= "output";
	output.value 	= tTable;
	
	var params = [input, output];
	
	log.info(JSON.stringify(params));
	//conversor dos parametros de input para Json
	return JSON.stringify(params);
}