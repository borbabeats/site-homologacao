function createDataset(fields, constraints, sortFields) {
	try {
		var newDataset = DatasetBuilder.newDataset();
		newDataset.addColumn("mo-codigo");
		newDataset.addColumn("descricao");
		newDataset.addColumn("sigla");
		newDataset.addColumn("cod-siscomex");
		newDataset.addColumn("cod-iso-4217");
		newDataset.addColumn("desc_sigla");
		newDataset.addColumn("cod_sigla");

		var serviceProvider = ServiceManager.getService('TOTVS');
		var serviceLocator = serviceProvider.instantiate('com.totvs.framework.ws.execbo.service.WebServiceExecBO');
		var service = serviceLocator.getWebServiceExecBOPort();

		var resp = service.callProcedureWithToken(
			service.userLogin("fluig"),
			"dzp/dzwf001.p",
			"ws-busca-moeda",
			montaJson('')
		);

		var respObj = JSON.parse(resp);

		var callProcedureWithTokenResponse = JSON.parse(respObj[0].value);

		for (var i in callProcedureWithTokenResponse.records) {
			if (callProcedureWithTokenResponse.records[i]["cod-siscomex"] != '0') {
				newDataset.addRow(new Array(
					callProcedureWithTokenResponse.records[i]["mo-codigo"],
					callProcedureWithTokenResponse.records[i]["descricao"],
					callProcedureWithTokenResponse.records[i]["sigla"],
					callProcedureWithTokenResponse.records[i]["cod-siscomex"],
					callProcedureWithTokenResponse.records[i]["cod-iso-4217"],
					callProcedureWithTokenResponse.records[i]["descricao"].replace(' ', '_') + '-' + callProcedureWithTokenResponse.records[i]['sigla'],
					callProcedureWithTokenResponse.records[i]["mo-codigo"] + '-' + callProcedureWithTokenResponse.records[i]['sigla'])
				);
			}
		}
	} catch (e) {
		log.info("ERRO: " + e);
	}finally {
		return newDataset;
	}
}

function montaJson(filtro) {
	var codigomoeda = {};
	codigomoeda.type = "integer";
	codigomoeda.name = "mo-codigo";
	codigomoeda.label = "mo-codigo";

	var descricao = {};
	descricao.type = "character";
	descricao.name = "descricao";
	descricao.label = "descricao";

	var sigla = {};
	sigla.type = "character";
	sigla.name = "sigla";
	sigla.label = "sigla";

	var codsiscomex = {};
	codsiscomex.type = "integer";
	codsiscomex.name = "cod-siscomex";
	codsiscomex.label = "cod-siscomex";

	var codiso4217 = {};
	codiso4217.type = "character";
	codiso4217.name = "cod-iso-4217";
	codiso4217.label = "cod-iso-4217";

	//formador do parametro value para temp-table
	var tTable = {};
	tTable.name = "tt-moeda";
	tTable.records = [];
	tTable.fields = [codigomoeda, descricao, sigla, codsiscomex, codiso4217];

	//OutPut 

	var output = {};
	output.dataType = "temptable";
	output.name = "ws-busca-moeda"; //nome da temp-table
	output.type = "output";
	output.value = tTable;

	var params = [output];

	log.info(JSON.stringify(params));
	//conversor dos parametros de input para Json
	return JSON.stringify(params);
}