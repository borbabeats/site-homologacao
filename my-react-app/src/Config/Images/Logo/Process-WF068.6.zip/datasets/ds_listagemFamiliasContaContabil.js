function createDataset(fields, constraints, sortFields){
	var newDataset = DatasetBuilder.newDataset();
	newDataset.addColumn("FMCodigo");
	newDataset.addColumn("Descricao");
	newDataset.addColumn("NatDespesa");
	newDataset.addColumn("CTCodigo");

	var filtro = '';

		if (constraints[0].initialValue != null && constraints[0].initialValue != 300) 
			filtro = "" + constraints[0].initialValue;
		else
			filtro = "" + constraints[1].initialValue;
	//var filtro  = ""; // coloca uma num valido


	try {
		// Utiliza o ServiceManager para obter uma referencia ao servico.
		var serviceProvider = ServiceManager.getService('TOTVS');
		var serviceLocator  = serviceProvider.instantiate('com.totvs.framework.ws.execbo.service.WebServiceExecBO');
		var service         = serviceLocator.getWebServiceExecBOPort();

		// Faz login e recebe o token de autenticacao
		var token = service.userLogin("fluig");

		var json  = montaJson(filtro);

		// Chama a procedure passando os parametros e o token de autenticacao.
		var resp = service.callProcedureWithToken(token, "dzp/dzwf001.p", "ws-busca-conta-familia", json);

		var respObj = JSON.parse(resp);

		var callProcedureWithTokenResponse = JSON.parse(respObj[0].value);

		for (var i in callProcedureWithTokenResponse.records){
	    	newDataset.addRow(new Array(
			callProcedureWithTokenResponse.records[i]["fm-codigo"],
			callProcedureWithTokenResponse.records[i]["descricao"],
			callProcedureWithTokenResponse.records[i]["nat-despesa"],
			callProcedureWithTokenResponse.records[i]["ct-codigo"])
			);
	    }
	} catch (e) {
		log.info("### ERRO: "+e);
	}

	return newDataset;
}

function montaJson(filtro){
	log.info("montaJson");

	var FMCodigo    	= new Object();
	FMCodigo.type	= "character";
	FMCodigo.name   	= "fm-codigo";
	FMCodigo.label  	= "FMCodigo";

	var Descricao   	= new Object();
	Descricao.type  	= "character";
	Descricao.name	= "descricao";
	Descricao.label	= "Descricao";

	var NATDespesa  	= new Object();
	NATDespesa.type 	= "integer";
	NATDespesa.name	= "nat-despesa";
	NATDespesa.label	= "NATDespesa";

	var CTCodigo  	= new Object();
	CTCodigo.type  	= "character";
	CTCodigo.name	= "ct-codigo";
	CTCodigo.label	= "CTCodigo";

    //formador do parametro value para temp-table
	var tTable		= new Object();
    tTable.name     	= "tt-conta-familia";
    tTable.records  	= new Array();
    tTable.fields		= [FMCodigo, Descricao, NATDespesa, CTCodigo];

    //array para receber os parametros input da chamada da função

    var input 		= new Object();
    input.dataType 	= "character";
    input.name  	 	= "p-fm-codigo";//procedure input
    input.label 	 	= "FMCodigo";
    input.type 	 	= "input";
    input.value 		= filtro;

	var output 	  	= new Object();
	output.dataType	= "temptable";
	output.name   	= "tt-conta-familia";//nome da temp-table
	output.type   	= "output";
	output.value  	= tTable;

	var params = [input, output];

	log.info(JSON.stringify(params));
	//conversor dos parametros de input para Json
	return JSON.stringify(params);
}