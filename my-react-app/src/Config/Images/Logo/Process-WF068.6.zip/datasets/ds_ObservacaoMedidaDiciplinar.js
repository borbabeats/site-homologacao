function createDataset(fields, constraints, sortFields){
	var newDataset = DatasetBuilder.newDataset();
	newDataset.addColumn("Código");
	newDataset.addColumn("Descrição");
	newDataset.addColumn("Observação");
	// newDataset.addColumn("CódEDescrição");

	try {
		// Utiliza o ServiceManager para obter uma referencia ao servico.
		var serviceProvider = ServiceManager.getService('TOTVS');
		var serviceLocator  = serviceProvider.instantiate('com.totvs.framework.ws.execbo.service.WebServiceExecBO');
		var service         = serviceLocator.getWebServiceExecBOPort();

		// Faz login e recebe o token de autenticacao
		var token = service.userLogin("fluig");

		var json  = montaJson("");

		// Chama a procedure passando os parametros e o token de autenticacao.
		var resp = service.callProcedureWithToken(token, "dzp/dzwf001.p", "ws-busca-obs-discipl-fp", json);

		var respObj = JSON.parse(resp);

		var callProcedureWithTokenResponse = JSON.parse(respObj[0].value);

		for (var i in callProcedureWithTokenResponse.records){
			if(parseInt(callProcedureWithTokenResponse.records[i]["cdn-obs-func"]) <= 4)
            	newDataset.addRow(new Array(
					callProcedureWithTokenResponse.records[i]["cdn-obs-func"],
					callProcedureWithTokenResponse.records[i]["des-obs-func"],
					callProcedureWithTokenResponse.records[i]["log-obs-contrato-trab"]
				)
            );
	    }
	} catch (e) {
		log.info("ERRO: "+e);
	}

	return newDataset;
}

function montaJson(filtro){
	log.info("montaJson");

    var codigo   = new Object();
	codigo.type  = "integer";
	codigo.name  = "cdn-obs-func";
	codigo.label = "codigo";

	var descricao   = new Object();
	descricao.type  = "character";
	descricao.name  = "des-obs-func";
	descricao.label = "descricao";
	
    var obs   = new Object();
	obs.type  = "logical";
	obs.name  = "log-obs-contrato-trab";
	obs.label = "obs";

    //formador do parametro value para temp-table
	var tTable		= new Object();
    tTable.name     = "tt-obs-discipl-fp";
    tTable.records  = new Array();
    tTable.fields	= [codigo, descricao,obs];

    //array para receber os parametros input da chamada da função

	var output 	  	= new Object();
	output.dataType	= "temptable";
	output.name   	= "tt-obs-discipl-fp"; //nome da temp-table
	output.type   	= "output";
	output.value  	= tTable;

	var params = [output];

	log.info(JSON.stringify(params));
	//conversor dos parametros de input para Json
	return JSON.stringify(params);
}










