function createDataset(fields, constraints, sortFields) {
    var newDataset = DatasetBuilder.newDataset();

    var myQuery = " SELECT distinct(proc.NUM_PROCES) as NUM_PROCES, substring(proc.COD_DEF_PROCES,1,5) AS COD_DEF, DES_DEF_PROCES, FULL_NAME, DATE_FORMAT(proc.START_DATE, '%d/%m/%Y') as DATA"
    myQuery += "        FROM proces_workflow proc"
    myQuery += "            left outer join def_proces d"
    myQuery += "                 on  substring(d.COD_DEF_PROCES ,1,5) = substring(proc.COD_DEF_PROCES,1,5)"
    myQuery += "            left outer join fdn_usertenant usu "
    myQuery += "                on usu.USER_CODE = proc.COD_MATR_REQUISIT"
    myQuery += "            left outer join fdn_user u"
    myQuery += "                on u.USER_ID = usu.USER_ID"
    myQuery += "        where STATUS = 2 and usu.USER_STATE = 1 "
    myQuery += "            and substring(proc.COD_DEF_PROCES,1,5) in ('WF034', 'WF046', 'WF052', 'WF053', 'WF054', 'WF055', 'WF059', 'WF063', 'WF064', 'WF068',  'WF074') "
    myQuery += "            and FULL_NAME LIKE '%"+fields[0]+"%';"

    try {
        var dataSource = "/jdbc/AppDS";
        var ic = new javax.naming.InitialContext();
        var ds = ic.lookup(dataSource);
        var conn = ds.getConnection();
        var stmt = conn.createStatement();
        var created = false;
        var rs = stmt.executeQuery(myQuery);
        var columnCount = rs.getMetaData().getColumnCount();
        while (rs.next()) {
            if (!created) {
                for (var i = 1; i <= columnCount; i++) {
                    newDataset.addColumn(rs.getMetaData().getColumnName(i));
                }
                created = true;
            }
            var Arr = [];
            for (var j = 1; j <= columnCount; j++) {
                var obj = rs.getObject(rs.getMetaData().getColumnName(j));
                null !== obj ? Arr[j - 1] = rs.getObject(rs.getMetaData().getColumnName(j)).toString() : Arr[j - 1] = "null";
            }
            newDataset.addRow(Arr);
        }
    } catch (e) {
        log.error("ERRO==============> " + e.message);
    } finally {
        if (stmt !== null) stmt.close();
        if (conn !== null) conn.close();
    }
    return newDataset;
}