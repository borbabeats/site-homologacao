function createDataset(fields, constraints, sortFields) {
	try {

		var newDataset = DatasetBuilder.newDataset();
		newDataset.addColumn("Resposta");
		newDataset.addColumn("Erro");

		var nome = "" + fields[1];
		var tipoVisita = "" + fields[2];
		var empresa = "" + fields[3];
		var contatoMat = "" + fields[4];
		var tipoPessoa = "" + fields[5];
		var documento = "" + fields[6];
		var celular = "" + fields[7];

		var visita = parseInt(tipoVisita);
		var contato = parseInt(contatoMat);
		var pessoa = parseInt(tipoPessoa);

		var serviceProvider = ServiceManager.getService('TOTVS');
		var serviceLocator = serviceProvider.instantiate('com.totvs.framework.ws.execbo.service.WebServiceExecBO');
		var service = serviceLocator.getWebServiceExecBOPort();

		var resp = service.callProcedureWithToken(
			service.userLogin("fluig"), 
			"dzp/dzwf002.p", 
			"ws-cadastra-pessoa-fisica", 
			montaJson(nome, visita, empresa, contato, pessoa, documento, celular));

		var respObj = JSON.parse(resp);

		var resposta = respObj[0].value;
		var erro = respObj[1].value;
		newDataset.addRow([resposta, erro]);

	} catch (e) {
		log.info("ERRO: " + e);
	}
	return newDataset;
}

function montaJson(nome, visita, empresa, contato, pessoa, documento, celular) {
	log.info("montaJson");

	var resposta = {};
	resposta.type = "logical";
	resposta.name = "p-resposta";
	resposta.label = "p-resposta";

	var erro = {};
	erro.type = "character";
	erro.name = "p-erro";
	erro.label = "p-erro";

	var input1 = {};
	input1.dataType = "character";
	input1.name = "p-nome";
	input1.label = "p-nome";
	input1.type = "input";
	input1.value = nome;

	var input2 = {};
	input2.dataType = "integer";
	input2.name = "p-tipo-visita";
	input2.label = "p-tipo-visita";
	input2.type = "input";
	input2.value = visita;

	var input3 = {};
	input3.dataType = "character";
	input3.name = "p-empresa";
	input3.label = "p-empresa";
	input3.type = "input";
	input3.value = empresa;

	var input4 = {};
	input4.dataType = "integer";
	input4.name = "p-contato-mat";
	input4.label = "p-contato-mat";
	input4.type = "input";
	input4.value = contato;

	var input5 = {};
	input5.dataType = "integer";
	input5.name = "p-tipo-pessoa";
	input5.label = "p-tipo-pessoa";
	input5.type = "input";
	input5.value = pessoa;

	var input6 = {};
	input6.dataType = "character";
	input6.name = "p-documento";
	input6.label = "p-documento";
	input6.type = "input";
	input6.value = documento;

	var input7 = {};
	input7.dataType = "character";
	input7.name = "p-celular";
	input7.label = "p-celular";
	input7.type = "input";
	input7.value = celular;

	var output = {};
	output.dataType = "logical";
	output.name = "p-resposta";
	output.type = "output";
	output.value = resposta;

	var output1 = {};
	output1.dataType = "character";
	output1.name = "p-erro";
	output1.type = "output";
	output1.value = erro;

	var params = [input1, input2, input3, input4, input5, input6, input7, output, output1];

	log.info(JSON.stringify(params));
	//conversor dos parametros de input para Json
	return JSON.stringify(params);
}