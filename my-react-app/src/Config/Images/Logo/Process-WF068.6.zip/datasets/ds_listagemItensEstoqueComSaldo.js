function createDataset(fields, constraints, sortFields){
	log.info("começou teste filtro")
	var newDataset = DatasetBuilder.newDataset();
	newDataset.addColumn("Código");
	newDataset.addColumn("Nome");
	newDataset.addColumn("Saldo");

	var filtro = '';

		if (constraints[0].initialValue != null && constraints[0].initialValue != 300) 
			filtro = "" + constraints[0].initialValue;
		else
			filtro = "" + constraints[1].initialValue;
	// var filtro  =   "18011";

	try {
		// Utiliza o ServiceManager para obter uma referencia ao servico.
		var serviceProvider = ServiceManager.getService('TOTVS');
		var serviceLocator  = serviceProvider.instantiate('com.totvs.framework.ws.execbo.service.WebServiceExecBO');
		var service         = serviceLocator.getWebServiceExecBOPort();

		// Faz login e recebe o token de autenticacao
		var token = service.userLogin("fluig");

		var json  = montaJson(filtro);

		// Chama a procedure passando os parametros e o token de autenticacao.
		var resp = service.callProcedureWithToken(token, "dzp/dzwf001.p", "ws-busca-item-codigo", json);

		var respObj = JSON.parse(resp);

		var callProcedureWithTokenResponse = JSON.parse(respObj[0].value);
		
		for (var i in callProcedureWithTokenResponse.records){
	    	newDataset.addRow(new Array(
				callProcedureWithTokenResponse.records[i]["it-codigo"], 
				callProcedureWithTokenResponse.records[i]["desc-item"].replace(/\"/g, " POLEGADA "), 
				callProcedureWithTokenResponse.records[i]["vl-saldo"])
			);
	    }
	} catch (e) {
		log.info("ERRO: "+e);
	}

	return newDataset;
}

function montaJson(filtro){
	log.info("montaJson");

	var codigo 		= new Object();
	codigo.type 	= "character";
	codigo.name 	= "it-codigo";
	codigo.label 	= "codigo";

	var nome 		= new Object();
	nome.type 		= "character";
	nome.name 		= "desc-item"; 
	nome.label 		= "nome"; 

	var saldo 		= new Object();
	saldo.type 		= "decimal";
	saldo.name 		= "vl-saldo";  
	saldo.label 	= "Saldo";
	    
    //formador do paremetro value para temp-table
    var tt_item 		= new Object();
    tt_item.name 		= "tt-item";
    tt_item.records 	= new Array();
    tt_item.fields 		= [codigo, nome, saldo];
    
    //array para receber os parametros input da chamada da função
   
	var tt_item_filt 			= new Object();
	tt_item_filt.dataType		= "character";
	tt_item_filt.name 		= "p-it-codigo";
	tt_item_filt.label 		= "p-it-codigo";
	tt_item_filt.type 		= "input";
	tt_item_filt.value 		= filtro;

	var tt_item_faturavel 		= new Object();
	tt_item_faturavel.dataType	= "integer";
	tt_item_faturavel.name 		= "p-faturavel";
	tt_item_faturavel.label 	= "p-faturavel";
	tt_item_faturavel.type 		= "input";
	tt_item_faturavel.value 	= "3"; //  1 = Faturáveis | 2 = Não Faturáveis | 3 = Ambos 
    
	var tt_item_var 			= new Object();
	tt_item_var.dataType		= "temptable";
	tt_item_var.name 			= "tt_item";
	tt_item_var.type 			= "output";
	tt_item_var.value 		= tt_item;
	
	var params = [tt_item_filt, tt_item_faturavel, tt_item_var];
	
	log.info(JSON.stringify(params));
	//conversor dos parametros de input para Json
	return JSON.stringify(params);
}