function createDataset(fields, constraints, sortFields) {
    var newDataset = DatasetBuilder.newDataset();

    var myQuery = "select p.NUM_PROCES, tbteste.* from ( select main_numSolic, main_status, main_etapa, cardid, documentid from ml001004 "
        myQuery += "union select main_numSolic, main_status, main_etapa, cardid, documentid from ml001032 "
        myQuery += "union select main_numSolic, main_status, main_etapa, cardid, documentid  from ml001054 "
        myQuery += "union select main_numSolic, main_status, main_etapa, cardid, documentid  from ml001055 "
        myQuery += "union select main_numSolic, main_status, main_etapa, cardid, documentid  from ml001056 "
        myQuery += "union select  main_numSolic, main_status, main_etapa, cardid, documentid  from ml001057 "
        myQuery += "union select main_numSolic, main_status, main_etapa, cardid, documentid  from ml001063 "
        myQuery += "union select main_numSolic, main_status, main_etapa, cardid, documentid  from ml001067 "
        myQuery += "union select main_numSolic, main_status, main_etapa, cardid, documentid  from ml001068 "
        myQuery += "union select main_numSolic, main_status, main_etapa, cardid, documentid  from ml001073 "
        myQuery += "union select main_numSolic, main_status, main_etapa, cardid, documentid  from ml001077) "
        myQuery += "as tbteste inner join proces_workflow as p on p.NR_DOCUMENTO_CARD = tbteste.documentid AND p.NR_DOCUMENTO_CARD_INDEX = tbteste.cardid where NUM_PROCES in ("+fields[0]+") ";
        myQuery += "and (main_status like '%Cancelado%' or main_etapa in ('Reprovado', 'Cancelado', 'Não Aprovado'))";

    try {
        var dataSource = "/jdbc/AppDS";
        var ic = new javax.naming.InitialContext();
        var ds = ic.lookup(dataSource);
        var conn = ds.getConnection();
        var stmt = conn.createStatement();
        var created = false;
        var rs = stmt.executeQuery(myQuery);
        var columnCount = rs.getMetaData().getColumnCount();
        while (rs.next()) {
            if (!created) {
                for (var i = 1; i <= columnCount; i++) {
                    newDataset.addColumn(rs.getMetaData().getColumnName(i));
                }
                created = true;
            }
            var Arr = [];
            for (var j = 1; j <= columnCount; j++) {
                var obj = rs.getObject(rs.getMetaData().getColumnName(j));
                null !== obj ? Arr[j - 1] = rs.getObject(rs.getMetaData().getColumnName(j)).toString() : Arr[j - 1] = "null";
            }
            newDataset.addRow(Arr);
        }
    } catch (e) {
        log.error("ERRO==============> " + e.message);
    } finally {
        if (stmt !== null) stmt.close();
        if (conn !== null) conn.close();
    }
    return newDataset;
}