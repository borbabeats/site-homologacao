function createDataset(fields, constraints, sortFields){
	var newDataset = DatasetBuilder.newDataset();
	
	newDataset.addColumn("Código");
	newDataset.addColumn("Nome");
	newDataset.addColumn("CNPJ");

	var filtro = '';

		if (constraints[0].initialValue != null && constraints[0].initialValue != 300) 
			filtro = "" + constraints[0].initialValue;
		else
			filtro = "" + constraints[1].initialValue;

	try {
		// Utiliza o ServiceManager para obter uma referencia ao servico.
		var serviceProvider = ServiceManager.getService('TOTVS');
		var serviceLocator  = serviceProvider.instantiate('com.totvs.framework.ws.execbo.service.WebServiceExecBO');
		var service         = serviceLocator.getWebServiceExecBOPort();

		// Faz login e recebe o token de autenticacao
		var token = service.userLogin("fluig");

		// Chama a procedure passando os parametros e o token de autenticacao.
		var resp = service.callProcedureWithToken(token, "dzp/dzwf001.r", "ws-busca-transportadora", montaJson(filtro));

		var respObj = JSON.parse(resp);
		var callProcedureWithTokenResponse = JSON.parse(respObj[0].value);
		
		for (var i in callProcedureWithTokenResponse.records){
	    	newDataset.addRow(new Array(
			callProcedureWithTokenResponse.records[i]["cod-transp"], 
			callProcedureWithTokenResponse.records[i]["nome-abrev"], 
			callProcedureWithTokenResponse.records[i]["cnpj"]
			));
	    }
	} catch (e) {
		log.info("ERRO: "+e);       
	}

	return newDataset;
}

function montaJson(filtro){
	log.info("montaJson");

	var cod_transp 		= new Object();
	cod_transp.type 	= "integer";
	cod_transp.name 	= "cod-transp";
	cod_transp.label 	= "codigo";

	var nome 			= new Object();
	nome.type 			= "character";
	nome.name 			= "nome-abrev";
	nome.label 			= "descricao";

	var cnpj 			= new Object();
	cnpj.type 			= "character";
	cnpj.name 			= "cnpj";
	cnpj.label 			= "CNPJ";	    
	    
    //formador do paremetro value para temp-table
    var tt_transp 		= new Object();
    tt_transp.name 		= "tt-transportador";
    tt_transp.records 	= new Array();
    tt_transp.fields 	= [cod_transp, nome, cnpj];
    
    //array para receber os parametros input da chamada da função

    var tt_transp_filt 		= new Object();
	tt_transp_filt.dataType = "character";
	tt_transp_filt.name 	= "p-nome-abrev";
	tt_transp_filt.label 	= "p-nome-abrev";
	tt_transp_filt.type 	= "input";
	tt_transp_filt.value 	= filtro;
   
	var tt_transp_var 		= new Object();
	tt_transp_var.dataType 	= "temptable";
	tt_transp_var.name 		= "tt-transp";
	tt_transp_var.type 		= "output";
	tt_transp_var.value 	= tt_transp;
	
	var params = [tt_transp_filt, tt_transp_var];
	
	log.info(JSON.stringify(params));
	//conversor dos parametros de input para Json
	return JSON.stringify(params);
}

function mascaraCNPJ(cnpj){
    // cnpj = cnpj.slice(0, 2) + "." + cnpj.slice(2);
	return cnpj;
}