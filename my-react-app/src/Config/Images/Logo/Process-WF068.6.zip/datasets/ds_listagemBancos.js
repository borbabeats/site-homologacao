function createDataset(fields, constraints, sortFields){
	var newDataset = DatasetBuilder.newDataset();
	newDataset.addColumn("Codigo");
	newDataset.addColumn("Banco");

	var filtro = '';

		if (constraints[0].initialValue != null && constraints[0].initialValue != 300) 
			filtro = "" + constraints[0].initialValue;
		else
			filtro = "" + constraints[1].initialValue;
	//var filtro = "Analista";

	try {
		// Utiliza o ServiceManager para obter uma referencia ao servico.
		var serviceProvider = ServiceManager.getService('TOTVS');
		var serviceLocator  = serviceProvider.instantiate('com.totvs.framework.ws.execbo.service.WebServiceExecBO');
		var service         = serviceLocator.getWebServiceExecBOPort();

		// Faz login e recebe o token de autenticacao
		var token = service.userLogin("fluig");

		var json  = montaJson(filtro);

		// Chama a procedure passando os parametros e o token de autenticacao.
		var resp = service.callProcedureWithToken(token, "dzp/dzwf001.p", "ws-busca-banco", json);

		var respObj = JSON.parse(resp);

		var callProcedureWithTokenResponse = JSON.parse(respObj[0].value);
		
		for (var i in callProcedureWithTokenResponse.records){
	    		newDataset.addRow(new Array(
				callProcedureWithTokenResponse.records[i]["cod-banco"], 
				callProcedureWithTokenResponse.records[i]["nom-banco"])
			);
	    }
	} catch (e) {
		log.info("ERRO: "+e);
	}

	return newDataset;
}

function montaJson(filtro){
	log.info("montaJson");

	var Codigo 		= new Object();
	Codigo.type 	= "character";
	Codigo.name 	= "cod-banco";
	Codigo.label 	= "Codigo";

	var Banco 		= new Object();
	Banco.type 		= "character";
	Banco.name 		= "nom-banco"; 
	Banco.label 	= "Banco"; 
	    
    //formador do paremetro value para temp-table
    var tt_banco 	= new Object();
    tt_banco.name 	= "tt-banco";
    tt_banco.records= new Array();
    tt_banco.fields = [Codigo, Banco];
    
    //array para receber os parametros input da chamada da função
   
    var input 		= new Object();
    input.dataType	= "character";
    input.name 		= "p-nom-banco";
    input.label 	= "p-nom-banco";
    input.type 		= "input";
    input.value 	= filtro;
    
	var output 		= new Object();
	output.dataType	= "temptable";
	output.name 	= "tt-banco";
	output.type 	= "output";
	output.value 	= tt_banco;
	
	var params = [input, output];
	
	log.info(JSON.stringify(params));
	//conversor dos parametros de input para Json
	return JSON.stringify(params);
}