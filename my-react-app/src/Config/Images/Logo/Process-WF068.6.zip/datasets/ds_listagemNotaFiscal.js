function createDataset(fields, constraints, sortFields) {
	var newDataset = DatasetBuilder.newDataset();
	newDataset.addColumn("Fornecedor");
	newDataset.addColumn("Série");
	newDataset.addColumn("NF");
	newDataset.addColumn("Emissão");
	newDataset.addColumn("Valor");
	newDataset.addColumn("csitdoc");
	newDataset.addColumn("ctiponota");
	newDataset.addColumn("coridoc");
	newDataset.addColumn("csitnotadocum");
	newDataset.addColumn("ceatualizado");
	newDataset.addColumn("ofatualizado");
	newDataset.addColumn("apatualizado");
	newDataset.addColumn("cratualizado");

	// 		var filtro  = "0122121";
	var filtro = "";

	if (constraints[0].initialValue != null && constraints[0].initialValue != 300)
		filtro = "" + constraints[0].initialValue;
	else
		filtro = "" + constraints[1].initialValue;

	try {
		// Utiliza o ServiceManager para obter uma referencia ao servico.
		var serviceProvider = ServiceManager.getService('TOTVS');
		var serviceLocator = serviceProvider.instantiate('com.totvs.framework.ws.execbo.service.WebServiceExecBO');
		var service = serviceLocator.getWebServiceExecBOPort();

		// Faz login e recebe o token de autenticacao
		var token = service.userLogin("fluig");

		var json = montaJson(filtro);

		// Chama a procedure passando os parametros e o token de autenticacao.
		var resp = service.callProcedureWithToken(token, "dzp/dzwf001.p", "ws-busca-nota-fiscal", json);

		var respObj = JSON.parse(resp);

		var callProcedureWithTokenResponse = JSON.parse(respObj[0].value);

		for (var i in callProcedureWithTokenResponse.records) {
			newDataset.addRow(new Array(
				callProcedureWithTokenResponse.records[i]["nome-emit"],
				callProcedureWithTokenResponse.records[i]["serie"],
				callProcedureWithTokenResponse.records[i]["nr-nota-fis"],
				callProcedureWithTokenResponse.records[i]["dt-emis-nota"],
				callProcedureWithTokenResponse.records[i]["vl-tot-nota"],
				callProcedureWithTokenResponse.records[i]["c-sit-doc"],
				callProcedureWithTokenResponse.records[i]["c-tipo-nota"],
				callProcedureWithTokenResponse.records[i]["c-ori-doc"],
				callProcedureWithTokenResponse.records[i]["c-sit-nota-docum"],
				callProcedureWithTokenResponse.records[i]["ce-atualizado"],
				callProcedureWithTokenResponse.records[i]["of-atualizado"],
				callProcedureWithTokenResponse.records[i]["ap-atualizado"],
				callProcedureWithTokenResponse.records[i]["cr-atualizado"])
			);
		}
	} catch (e) {
		log.info("ERRO: " + e);
	}
	return newDataset;
}

function montaJson(filtro) {
	log.info("montaJson");

	var nomForn = {};
	nomForn.type = "character";
	nomForn.name = "nome-emit";
	nomForn.label = "nomeFornec";

	var nrSerie = {};
	nrSerie.type = "character";
	nrSerie.name = "serie";
	nrSerie.label = "serie";

	var nrNota = {};
	nrNota.type = "character";
	nrNota.name = "nr-nota-fis";
	nrNota.label = "nrNotaFiscal";

	var dtEmis = {};
	dtEmis.type = "character";
	dtEmis.name = "dt-emis-nota";
	dtEmis.label = "dtEmissao";

	var vlNota = {};
	vlNota.type = "decimal";
	vlNota.name = "vl-tot-nota";
	vlNota.label = "valorNota";

	var csitdoc = {};
	csitdoc.type = "character";
	csitdoc.name = "c-sit-doc";
	csitdoc.label = "csitdoc";

	var ctiponota = {};
	ctiponota.type = "character";
	ctiponota.name = "c-tipo-nota";
	ctiponota.label = "ctiponota";

	var coridoc = {};
	coridoc.type = "character";
	coridoc.name = "c-ori-doc";
	coridoc.label = "coridoc";

	var csitnotadocum = {};
	csitnotadocum.type = "character";
	csitnotadocum.name = "c-sit-nota-docum";
	csitnotadocum.label = "csitnotadocum";

	var ceatualizado = {};
	ceatualizado.type = "logical";
	ceatualizado.name = "ce-atualizado";
	ceatualizado.label = "ceatualizado";

	var ofatualizado = {};
	ofatualizado.type = "logical";
	ofatualizado.name = "of-atualizado";
	ofatualizado.label = "ofatualizado";

	var apatualizado = {};
	apatualizado.type = "logical";
	apatualizado.name = "ap-atualizado";
	apatualizado.label = "apatualizado";

	var cratualizado = {};
	cratualizado.type = "logical";
	cratualizado.name = "cr-atualizado";
	cratualizado.label = "cratualizado";

	//formador do paremetro value para temp-table
	var tTable = {};
	tTable.name = "tt-nota-fiscal";
	tTable.records = [];
	tTable.fields = [nomForn, nrSerie, nrNota, dtEmis, vlNota, csitdoc, ctiponota, coridoc, csitnotadocum, ceatualizado, ofatualizado, apatualizado, cratualizado];

	//array para receber os parametros input da chamada da função

	var input = {};
	input.dataType = "character";
	input.name = "p-nr-nota-fis";
	input.label = "p-nr-nota-fis";
	input.type = "input";
	input.value = filtro;

	var output = {};
	output.dataType = "temptable";
	output.name = "tt-nota-fiscal";
	output.type = "output";
	output.value = tTable;

	var params = [input, output];

	log.info(JSON.stringify(params));
	//conversor dos parametros de input para Json
	return JSON.stringify(params);
}

