function createDataset(fields, constraints, sortFields){
	var newDataset = DatasetBuilder.newDataset();
	newDataset.addColumn("CodUsuario");
	newDataset.addColumn("NomeUsuario");
	newDataset.addColumn("EmailUsuario");
	newDataset.addColumn("cdnUsuario");
	newDataset.addColumn("UsuarioSO");
	newDataset.addColumn("UsuarioFluig");
	newDataset.addColumn("Erro");

	var filtro  =  ""+fields[0];
	//var filtro  =  "kamilly.silva";

	try {
		// Utiliza o ServiceManager para obter uma referencia ao servico.
		var serviceProvider = ServiceManager.getService('TOTVS');
		var serviceLocator  = serviceProvider.instantiate('com.totvs.framework.ws.execbo.service.WebServiceExecBO');
		var service         = serviceLocator.getWebServiceExecBOPort();

		// Faz login e recebe o token de autenticacao
		var token = service.userLogin("fluig");

		var json  = montaJson(filtro);

		// Chama a procedure passando os parametros e o token de autenticacao.
		var resp = service.callProcedureWithToken(token, "dzp/dzwf001.p", "ws-busca-dados-usuario-totvs", json);

		var respObj = JSON.parse(resp);

		if(respObj[1].value !== ""){
			newDataset.addRow(new Array("","","","","","",respObj[1].value))
		}else{
			var callProcedureWithTokenResponse = JSON.parse(respObj[0].value);

			for (var i in callProcedureWithTokenResponse.records){
				newDataset.addRow(new Array(
						callProcedureWithTokenResponse.records[i]["cod-usuario"] || "",
						callProcedureWithTokenResponse.records[i]["nom-usuario"] || "",
						callProcedureWithTokenResponse.records[i]["cod-e-mail-local"] || "",
						callProcedureWithTokenResponse.records[i]["cdn-funcionario"] || "",
						callProcedureWithTokenResponse.records[i]["cod-usuar-so"] || "",
						callProcedureWithTokenResponse.records[i]["cod-usuar-fluig"] || "",
						"" || respObj[1].value
					)
				);
			}
		}

		// newDataset.addRow(new Array())

	} catch (e) {
		log.info("ERRO: "+e);
	}

	return newDataset;
}

function montaJson(filtro){
	log.info("montaJson");

	var codusuario    = {};
	codusuario.type  = "character";
	codusuario.name  = "cod-usuario";
	codusuario.label = "codUsuario";

	var nomeusuario   = {};
	nomeusuario.type  = "character";
	nomeusuario.name  = "nom-usuario";
	nomeusuario.label = "nomeUsuario";

	var codigo   = {};
	codigo.type  = "integer";
	codigo.name  = "cdn-funcionario";
	codigo.label = "Usuario";

	var email   = {};
	email.type  = "character";
	email.name  = "cod-e-mail-local";
	email.label = "Email";

	var usuarioSO   = {};
	usuarioSO.type  = "character";
	usuarioSO.name  = "cod-usuar-so";
	usuarioSO.label = "UsuarioSO";
	
	var usuFluig   = {};
	usuFluig.type  = "character";
	usuFluig.name  = "cod-usuar-fluig";
	usuFluig.label = "UsuFluig";

    //formador do parametro value para temp-table
	var tTable		= {};
	tTable.name     	= "tt-dados-usuario-totvs";
	tTable.records  	= new Array();
	tTable.fields	= [codusuario, nomeusuario, email,codigo, usuarioSO, usuFluig];

	var erro 	    	= {};
	erro.type 	    	= "character";
	erro.name 	    	= "p-erro";
	erro.label 	    	= "p-erro";

    //array para receber os parametros input da chamada da função

	var input 		= {};
	input.dataType   	= "character";
	input.name  	= "p-cod-usuario";//procedure input
	input.label 	= "p-cod-usuario";
	input.type 	  	= "input";
	input.value 	= filtro;

	var output 	  	= {};
	output.dataType	= "temptable";
	output.name   	= "tt-dados-usuario-totvs"; //nome da temp-table
	output.type   	= "output";
	output.value  	= tTable;
	
	var output1 		= {};
	output1.dataType	= "character";
	output1.name 		= "p-erro";
	output1.type 		= "output";
	output1.value 		= erro;

	var params = [input, output, output1];

	log.info(JSON.stringify(params));
	//conversor dos parametros de input para Json
	return JSON.stringify(params);
}










