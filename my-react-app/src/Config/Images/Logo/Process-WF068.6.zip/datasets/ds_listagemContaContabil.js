function createDataset(fields, constraints, sortFields){
	log.info("começou teste filtro")
	var newDataset = DatasetBuilder.newDataset();
	newDataset.addColumn("Código");
	newDataset.addColumn("Nome");

	var filtro = '';

		if (constraints[0].initialValue != null && constraints[0].initialValue != 300) 
			filtro = "" + constraints[0].initialValue;
		else
			filtro = "" + constraints[1].initialValue;
//	var filtro  =   "1";
	
	try {
		// Utiliza o ServiceManager para obter uma referencia ao servico.
		var serviceProvider = ServiceManager.getService('TOTVS');
		var serviceLocator  = serviceProvider.instantiate('com.totvs.framework.ws.execbo.service.WebServiceExecBO');
		var service         = serviceLocator.getWebServiceExecBOPort();

		// Faz login e recebe o token de autenticacao
		var token = service.userLogin("fluig");

		var json  = montaJson();

		// Chama a procedure passando os parametros e o token de autenticacao.
		var resp = service.callProcedureWithToken(token, "dzp/dzwf001.p", "ws-busca-conta-ctbl", json);

		var respObj = JSON.parse(resp);

		var callProcedureWithTokenResponse = JSON.parse(respObj[0].value);
		
		for (var i in callProcedureWithTokenResponse.records){
	    	newDataset.addRow(new Array(
			callProcedureWithTokenResponse.records[i]["cod-conta"], 
			callProcedureWithTokenResponse.records[i]["descricao"])
			);
	    }
	} catch (e) {
		log.info("ERRO: "+e);
	}

	return newDataset;
}

function montaJson(){
	log.info("montaJson");

	var codigo 		= new Object();
	codigo.type 	= "character";
	codigo.name 	= "cod-conta";
	codigo.label 	= "codigo";

	var nome 		= new Object();
	nome.type 		= "character";
	nome.name 		= "descricao"; 
	nome.label 		= "nome"; 
	    
    //formador do paremetro value para temp-table
    var tt_conta 		= new Object();
    tt_conta.name 		= "tt-conta";
    tt_conta.records 	= new Array();
    tt_conta.fields 	= [codigo, nome];
    
    //array para receber os parametros input da chamada da função
    
   
/*    var tt_conta_filt 		= new Object();
	tt_conta_filt.dataType	= "character";
	tt_conta_filt.name 		= "cod-conta";
	tt_conta_filt.label 	= "cod-conta";
	tt_conta_filt.type 		= "input";
	tt_conta_filt.value		= filtro;
*/
	var tt_conta_var 		= new Object();
	tt_conta_var.dataType	= "temptable";
	tt_conta_var.name 		= "tt_conta";
	tt_conta_var.type 		= "output";
	tt_conta_var.value 		= tt_conta;
	
	var params = [tt_conta_var];
	
	log.info(JSON.stringify(params));
	//conversor dos parametros de input para Json
	return JSON.stringify(params);
}