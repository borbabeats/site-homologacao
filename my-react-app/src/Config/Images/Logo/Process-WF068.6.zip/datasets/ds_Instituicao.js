function createDataset(fields, constraints, sortFields) {
        var newDataset = DatasetBuilder.newDataset();

        newDataset.addColumn("cdn_instit_trein");
        newDataset.addColumn("des_instit_trein");
        newDataset.addColumn("des_tip_instit_trein");

        var filtro = '';

		if (constraints[0].initialValue != null && constraints[0].initialValue != 300) 
			filtro = "" + constraints[0].initialValue;
		else
			filtro = "" + constraints[1].initialValue;

        try {
                var serviceProvider = ServiceManager.getService('TOTVS');
                var serviceLocator = serviceProvider.instantiate('com.totvs.framework.ws.execbo.service.WebServiceExecBO');
                var service = serviceLocator.getWebServiceExecBOPort();

                var token = service.userLogin("fluig");
                var json = montaJson(filtro);

                var resp = service.callProcedureWithToken(token, "dzp/dzwf001.p", "ws-busca-instit-trein", json);

                var respObj = JSON.parse(resp);

                var callProcedureWithTokenResponse = JSON.parse(respObj[0].value);

                for (var i in callProcedureWithTokenResponse.records) {
                        newDataset.addRow([
                                callProcedureWithTokenResponse.records[i]["cdn-instit-trein"],
                                callProcedureWithTokenResponse.records[i]["des-instit-trein"],
                                callProcedureWithTokenResponse.records[i]["des-tip-instit-trein"]
                        ]
                        );
                }
        } catch (e) {
                log.info("ERRO: " + e);
        }

        return newDataset;
}

function montaJson(filtro) {
        log.info("montaJson");

        var cdn_instit_trein = {}
        cdn_instit_trein.type = "integer";
        cdn_instit_trein.name = "cdn-instit-trein";
        cdn_instit_trein.label = "cdn_instit_trein";

        var des_instit_trein = {}
        des_instit_trein.type = "character";
        des_instit_trein.name = "des-instit-trein";
        des_instit_trein.label = "des_instit_trein";

        var des_tip_instit_trein = {}
        des_tip_instit_trein.type = "character";
        des_tip_instit_trein.name = "des-tip-instit-trein";
        des_tip_instit_trein.label = "des_tip_instit_trein";



        var tTable = {};
        tTable.name = 'tt-instit-trein';
        tTable.records = [];
        tTable.fields = [cdn_instit_trein, des_instit_trein, des_tip_instit_trein];


        var input = {};
        input.dataType = "character";
        input.name = "p-des-instit-trein";
        input.label = "p-des-instit-trein";
        input.type = "input";
        input.value = filtro;


        var output = {};
        output.dataType = "temptable";
        output.name = "tt-instit-trein";
        output.type = "output";
        output.value = tTable;


        var params = [input, output];

        log.info(JSON.stringify(params));
        //conversor dos parametros de input para Json
        return JSON.stringify(params);
}
