function createDataset(fields, constraints, sortFields) {

    // Cria as colunas
    var newDataset = DatasetBuilder.newDataset();
    newDataset.addColumn("Codigo_banco");
    newDataset.addColumn("Nome_banco");
    
    var array   = new Array();
    var auxArray;
    var filtro  =   constraints[1];

    array.push(new Array("001", "Banco do Brasil"));
    array.push(new Array("033", "Santander"));
    array.push(new Array("041", "Banrisul"));
    array.push(new Array("104", "Caixa Econômica Federal"));
    array.push(new Array("237", "Bradesco"));
    array.push(new Array("241", "Itaú"));

    if(filtro != undefined && filtro != null){
        filtro = filtro.initialValue;
        for(var i = 0; i < array.length; i++){
            auxArray    =   array[i];
            for(var j = 0; j < auxArray.length; j++){
                if(auxArray[j].toLowerCase().indexOf(filtro.toString().toLowerCase()) != -1){
                    newDataset.addRow(auxArray);
                    j = auxArray.length;
                }
            }
        }
    }else{
        for(var i = 0; i < array.length; i++){
            newDataset.addRow(array[i]);
        }
    }
   

    return newDataset;
}