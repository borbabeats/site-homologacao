function createDataset(fields, constraints, sortFields){
	var newDataset = DatasetBuilder.newDataset();
	newDataset.addColumn("erro");
	
	// Inputs para procedure
	var usuarioRede 		= ""+fields[0];
	var usuarioFluig		= ""+fields[1];
	
	
	// Converte para inteiro campos characteres 

	try {
		// Utiliza o ServiceManager para obter uma referencia ao servico.
		var serviceProvider = ServiceManager.getService('TOTVS');
		var serviceLocator  = serviceProvider.instantiate('com.totvs.framework.ws.execbo.service.WebServiceExecBO');
		var service         = serviceLocator.getWebServiceExecBOPort();

		// Faz login e recebe o token de autenticacao
		var token = service.userLogin("fluig");

		var json  = montaJson(usuarioRede, usuarioFluig);

		// Chama a procedure passando os parametros e o token de autenticacao.
		var resp = service.callProcedureWithToken(token, "dzp/dzwf002.p", "ws-atualiza-usuario-fluig-totvs", json);
		
		var respObj = JSON.parse(resp);

        var Resposta = [respObj[0].value]
		newDataset.addRow(Resposta);
		
	} catch (e) {
		log.info("ERRO: "+e);
	}	
	return newDataset;
}
function montaJson(usuarioRede, usuarioFluig){
	log.info("montaJson");

	var erro 	        = new Object();
	erro.type 	    = "character";
	erro.name 	    = "p-erro";
	erro.label 	    = "p-erro";
    
    //array para receber os parametros input da chamada da função
   	
	var input1 			= new Object();
	input1.dataType		= "character";
	input1.name 		= "p-usuario-rede";
	input1.label 		= "p-usuario-rede";
	input1.type 		= "input";
	input1.value 		= usuarioRede;
	
	var input2 			= new Object();
	input2.dataType		= "character";
	input2.name 		= "p-usuario-fluig";
	input2.label 		= "p-usuario-fluig";
	input2.type 		= "input";
	input2.value 		= usuarioFluig;	
    
	var output1 		= new Object();
	output1.dataType		= "character";
	output1.name 		= "p-erro";
	output1.type 		= "output";
	output1.value 		= erro;
	
	var params = [input1, input2, output1];
	
	log.info(JSON.stringify(params));
	//conversor dos parametros de input para Json
	return JSON.stringify(params);
}
