function createDataset(fields, constraints, sortFields){
	log.info("começou teste filtro")
	var newDataset = DatasetBuilder.newDataset();
	newDataset.addColumn("Matrícula");
	newDataset.addColumn("Nome");
	newDataset.addColumn("CPF");
	newDataset.addColumn("CentroCusto");
	newDataset.addColumn("Descrição CC");
	newDataset.addColumn("CodCargo");
	newDataset.addColumn("Cargo");
	newDataset.addColumn("Nascimento");
	newDataset.addColumn("PCD");
	newDataset.addColumn("Cipa");
	newDataset.addColumn("DataCipa");
	newDataset.addColumn("Sindicato");
	newDataset.addColumn("DtSindicato");
	newDataset.addColumn("AcidenteTrabalho");
	newDataset.addColumn("DtEstAcidenteTrabalho");
	newDataset.addColumn("Doenca");
	newDataset.addColumn("DtEstDoenca");
	newDataset.addColumn("UltimaAso");
	newDataset.addColumn("Admissao");
	newDataset.addColumn("Demissao");
	newDataset.addColumn("Homogeneo");
	newDataset.addColumn("DescHomogeneo");
	newDataset.addColumn("TipoFuncionario");
	newDataset.addColumn("DescTipoFuncionario");
	newDataset.addColumn("QuantidadeDiasTrab");
	newDataset.addColumn("QuantidadeDiasSusp");
	newDataset.addColumn("DtTerminoContrato");
	newDataset.addColumn("TerminoContrato");
	newDataset.addColumn("VencProrrog");
	newDataset.addColumn("DtVencProrrog");
	newDataset.addColumn("RG");
	newDataset.addColumn("NomeAbreviado");

	var filtro  =   ""+constraints[0].initialValue;
	//var  filtro  =   11989; // Ativada
	//var  filtro  =   "20552"; // Ativada23421001
	// var  filtro  =   "11903"; // Ativada23421001

	
	try {
		// Utiliza o ServiceManager para obter uma referencia ao servico.
		var serviceProvider = ServiceManager.getService('TOTVS');
		var serviceLocator  = serviceProvider.instantiate('com.totvs.framework.ws.execbo.service.WebServiceExecBO');
		var service         = serviceLocator.getWebServiceExecBOPort();

		// Faz login e recebe o token de autenticacao
		var token = service.userLogin("fluig");

		var json  = montaJson(filtro);

		// Chama a procedure passando os parametros e o token de autenticacao.
		var resp = service.callProcedureWithToken(token, "dzp/dzwf001.p", "ws-busca-funcionario", json);

		var respObj = JSON.parse(resp);

		var callProcedureWithTokenResponse = JSON.parse(respObj[0].value);
			for (var i in callProcedureWithTokenResponse.records){
				// if(callProcedureWithTokenResponse.records[i]["dat-desligto-func"] == null){

					newDataset.addRow([
					callProcedureWithTokenResponse.records[i]["cdn-funcionario"], 
					callProcedureWithTokenResponse.records[i]["nome-func"], 
					callProcedureWithTokenResponse.records[i]["cpf"],
					callProcedureWithTokenResponse.records[i]["cod-ccusto"],
					callProcedureWithTokenResponse.records[i]["desc-cc"], 
					callProcedureWithTokenResponse.records[i]["cod-cargo"],
					callProcedureWithTokenResponse.records[i]["desc-cargo"],
					callProcedureWithTokenResponse.records[i]["dat-nascimento"].replace("12:00:00:0000", ""), 
					callProcedureWithTokenResponse.records[i]["port-nece-esp"],
					callProcedureWithTokenResponse.records[i]["estab-cipa"],
					callProcedureWithTokenResponse.records[i]["dt-fim-estab-cipa"],
					callProcedureWithTokenResponse.records[i]["estab-sindic"],
					callProcedureWithTokenResponse.records[i]["dt-fim-estab-sindic"],
					callProcedureWithTokenResponse.records[i]["estab-acidente"],
					callProcedureWithTokenResponse.records[i]["dt-fim-estab-acidente"],
					callProcedureWithTokenResponse.records[i]["estab-doenca"],
					callProcedureWithTokenResponse.records[i]["dt-fim-estab-doenca"],
					callProcedureWithTokenResponse.records[i]["dt-ultima-aso"],
					callProcedureWithTokenResponse.records[i]["dat-admis-func"].replace("12:00:00:0000", ""),
					callProcedureWithTokenResponse.records[i]["dat-desligto-func"],
					callProcedureWithTokenResponse.records[i]["num-ambien-risco"],
					callProcedureWithTokenResponse.records[i]["nom-ambien-risco"],
					callProcedureWithTokenResponse.records[i]["idi-tip-func"],
					callProcedureWithTokenResponse.records[i]["desc-tipo-funcionario"],
					callProcedureWithTokenResponse.records[i]["qti-dias-contrat-trab"],
					callProcedureWithTokenResponse.records[i]["qti-dias-suspensao"],
					callProcedureWithTokenResponse.records[i]["dat-term-contrat-trab"],
					callProcedureWithTokenResponse.records[i]["qti-dias-prorrog-contrat-trab"],
					callProcedureWithTokenResponse.records[i]["qti-dias-prorrog-suspensao"],
					callProcedureWithTokenResponse.records[i]["dat-term-prorrog-contrat-trab"],
					callProcedureWithTokenResponse.records[i]["cod-id-estad-fisic"],
					callProcedureWithTokenResponse.records[i]["nom-abrev-pessoa-fisic"]
					])
	    		// }
	    	}
	} catch (e) {
		log.info("ERRO: "+e);
	}

	return newDataset;
}

function montaJson(filtro){
	log.info("montaJson");

	var matricula 	= {};
	matricula.type 	= "integer";
	matricula.name 	= "cdn-funcionario";
	matricula.label = "matricula";

	var nome 		= {};
	nome.type 		= "character";
	nome.name 		= "nome-func"; 
	nome.label 		= "nome";

	var cpf 		= {};
	cpf.type 		= "character";
	cpf.name 		= "cpf"; 
	cpf.label 		= "cpf";

	var ccusto 		= {};
	ccusto.type 	= "character";
	ccusto.name 	= "cod-ccusto"; 
	ccusto.label 	= "ccusto";

	var descCc 		= {};
	descCc.type 	= "character";
	descCc.name 	= "desc-cc"; 
	descCc.label 	= "descCc";

	var codcargo 	= {};
	codcargo.type 	= "integer";
	codcargo.name 	= "cod-cargo"; 
	codcargo.label 	= "cod-cargo";

	var cargo 		= {};
	cargo.type 		= "character";
	cargo.name 		= "desc-cargo"; 
	cargo.label 	= "cargo";
	
	var datNasc 	= {};
	datNasc.type 	= "date";
	datNasc.name 	= "dat-nascimento"; 
	datNasc.label 	= "datNasc";
	
	var pcd 		= {};
	pcd.type 	    = "logical";
	pcd.name 	    = "port-nece-esp"; 
	pcd.label    	= "pcd";
	
	var cipa 		= {};
	cipa.type 		= "logical";
	cipa.name 		= "estab-cipa"; 
	cipa.label 		= "cipa";
	
	var dtCipa 		= {};
	dtCipa.type 	= "date";
	dtCipa.name 	= "dt-fim-estab-cipa"; 
	dtCipa.label 	= "dtCipa";
	    
	var sindicato 	= {};
	sindicato.type 	= "logical";
	sindicato.name 	= "estab-sindic"; 
	sindicato.label = "sindicato";
	
	var dtSindicato  = {};
	dtSindicato.type = "date";
	dtSindicato.name = "dt-fim-estab-sindic"; 
	dtSindicato.label= "dtSindicato";

	var acidente 	= {};
	acidente.type 	= "logical";
	acidente.name 	= "estab-acidente"; 
	acidente.label 	= "acidente";

	var dtAcidente 	= {};
	dtAcidente.type = "date";
	dtAcidente.name = "dt-fim-estab-acidente"; 
	dtAcidente.label= "dtAcidente";

	var doenca 		= {};
	doenca.type 	= "logical";
	doenca.name 	= "estab-doenca"; 
	doenca.label 	= "doença";

	var dtDoenca 		= {};
	dtDoenca.type 	= "date";
	dtDoenca.name 	= "dt-fim-estab-doenca"; 
	dtDoenca.label 	= "dtDoenca";

	var dtAso 		= {};
	dtAso.type 	   	= "date";
	dtAso.name 		= "dt-ultima-aso"; 
	dtAso.label 	= "dtAso";
	
	var admissao	= {};
	admissao.type 	= "date";
	admissao.name 	= "dat-admis-func"; 
	admissao.label	= "admissao";

	var demissao	= {};
	demissao.type 	= "date";
	demissao.name 	= "dat-desligto-func";
	demissao.label	= "demissao";

	var homogeneo	= {};
	homogeneo.type 	= "integer";
	homogeneo.name 	= "num-ambien-risco";
	homogeneo.label	= "homogeneo";

	var deschomogeneo	= {};
	deschomogeneo.type 	= "character";
	deschomogeneo.name 	= "nom-ambien-risco"; 
	deschomogeneo.label	= "deschomogeneo";
	
	var tipFun	= {};
	tipFun.type 	= "integer";
	tipFun.name 	= "idi-tip-func";
	tipFun.label	= "tipFun";

	var descTipoFun	= {};
	descTipoFun.type 	= "character";
	descTipoFun.name 	= "desc-tipo-funcionario"; 
	descTipoFun.label	= "descTipoFun";

	var QuantidadeDiasTrab		= {};
	QuantidadeDiasTrab.type 	= "integer";
	QuantidadeDiasTrab.name 	= "qti-dias-contrat-trab";
	QuantidadeDiasTrab.label	= "QuantidadeDiasTrab";

	var QuantidadeDiasSusp		= {};
	QuantidadeDiasSusp.type 	= "integer";
	QuantidadeDiasSusp.name 	= "qti-dias-suspensao"; 
	QuantidadeDiasSusp.label	= "QuantidadeDiasSusp";

	var DtTerminoContrato	= {};
	DtTerminoContrato.type 	= "date";
	DtTerminoContrato.name 	= "dat-term-contrat-trab";
	DtTerminoContrato.label	= "DtTerminoContrato";

	var TerminoContrato		= {};
	TerminoContrato.type 	= "integer";
	TerminoContrato.name 	= "qti-dias-prorrog-contrat-trab"; 
	TerminoContrato.label	= "TerminoContrato";
	
	var VencProrrog		= {};
	VencProrrog.type 	= "integer";
	VencProrrog.name 	= "qti-dias-prorrog-suspensao";
	VencProrrog.label	= "VencProrrog";

	var DtVencProrrog	= {};
	DtVencProrrog.type 	= "date";
	DtVencProrrog.name 	= "dat-term-prorrog-contrat-trab"; 
	DtVencProrrog.label	= "DtVencProrrog";

	var RG		= {};
	RG.type 	= "character";
	RG.name 	= "cod-id-estad-fisic"; 
	RG.label	= "RG";

	var NomeAbreviado	= {};
	NomeAbreviado.type 	= "character";
	NomeAbreviado.name 	= "nom-abrev-pessoa-fisic"; 
	NomeAbreviado.label	= "NomeAbreviado";
	
    //formador do parametro value para temp-table
	var tt_funcionario				= {};
    tt_funcionario.name 			= "tt-funcionario";
    tt_funcionario.records 			= [];
    tt_funcionario.fields 			= [matricula, nome, cpf, ccusto, descCc, codcargo, cargo, datNasc, pcd, cipa, dtCipa, sindicato, dtSindicato, acidente, dtAcidente, doenca, dtDoenca, dtAso, admissao, demissao, homogeneo, deschomogeneo, tipFun, descTipoFun, QuantidadeDiasTrab, QuantidadeDiasSusp, DtTerminoContrato, TerminoContrato, VencProrrog, DtVencProrrog, RG, NomeAbreviado];
    
    //array para receber os parametros input da chamada da função
   
    var tt_funcionario_filt 		= {}; 
    tt_funcionario_filt.dataType	= "integer";
    tt_funcionario_filt.name 		= "p-cdn-funcionario";
    tt_funcionario_filt.label 		= "p-cdn-funcionario";
    tt_funcionario_filt.type 		= "input";
    tt_funcionario_filt.value 		= filtro;
    
	var tt_funcionario_var 			= {};
	tt_funcionario_var.dataType		= "temptable";
	tt_funcionario_var.name 		= "tt-funcionario";
	tt_funcionario_var.type 		= "output";
	tt_funcionario_var.value 		= tt_funcionario;
	
	var params = [tt_funcionario_filt, tt_funcionario_var];
	
	log.info(JSON.stringify(params));
	//conversor dos parametros de input para Json
	return JSON.stringify(params);
}