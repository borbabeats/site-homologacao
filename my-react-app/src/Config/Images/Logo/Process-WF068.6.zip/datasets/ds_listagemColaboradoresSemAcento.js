function createDataset(fields, constraints, sortFields) {
	var newDataset = DatasetBuilder.newDataset();
	
	newDataset.addColumn("ID_Fluig");
	newDataset.addColumn("Nome_Completo");
	newDataset.addColumn("Nome_SemAcento");

	var array   = new Array();
    var auxArray;
	
	var c5          	= DatasetFactory.createConstraint("active", true, true, ConstraintType.MUST);
	var c6          	= DatasetFactory.createConstraint("colleaguePK.colleagueId", "admin", "admin", ConstraintType.MUST_NOT);
	var c7          	= DatasetFactory.createConstraint("colleaguePK.colleagueId", "wcmpublico", "wcmpublico", ConstraintType.MUST_NOT);
	var c8          	= DatasetFactory.createConstraint("colleaguePK.colleagueId", "consumerkeyteste", "consumerkeyteste", ConstraintType.MUST_NOT);
	var c9          	= DatasetFactory.createConstraint("colleaguePK.colleagueId", "administrador", "administrador", ConstraintType.MUST_NOT);
    var constraints2 	= new Array(c5, c6, c7, c8, c9);
    var a2          	= "colleagueName";
    var a3          	= "colleaguePK.colleagueId";
    var fields2			= new Array(a2, a3);
    var sortingFields 	= new Array("colleagueName");
	var colleague 		= DatasetFactory.getDataset("colleague", fields2, constraints2, sortingFields);	
	
	for (var i = 0; i < colleague.rowsCount; i++) {
		var nome = colleague.getValue(i, "colleagueName");
		var nomeSemAcento = removerAcentos(nome);
		newDataset.addRow(new Array(
        		colleague.getValue(i,"colleaguePK.colleagueId"),
        		colleague.getValue(i, "colleagueName"), 
        		nomeSemAcento));
	}
	

	return newDataset;
}

function removerAcentos(newStringComAcento) {
    var nome = newStringComAcento.toString();
	var mapaAcentosHex 	= {
			a : /[\xE0-\xE6]/g,
			A : /[\xC0-\xC6]/g,
			e : /[\xE8-\xEB]/g,
			E : /[\xC8-\xCB]/g,
			i : /[\xEC-\xEF]/g,
			I : /[\xCC-\xCF]/g,
			o : /[\xF2-\xF6]/g,
			O : /[\xD2-\xD6]/g,
			u : /[\xF9-\xFC]/g,
			U : /[\xD9-\xDC]/g,
			c : /\xE7/g,
			C : /\xC7/g,
			n : /\xF1/g,
			N : /\xD1/g,
	};

	
	for (var letra in mapaAcentosHex) {
		var expressaoRegular = mapaAcentosHex[letra];
		nome = (nome + "").replace( expressaoRegular, letra);
	}
	
	return nome;
}