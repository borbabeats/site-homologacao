function createDataset(fields, constraints, sortFields){
	
	var newDataset = DatasetBuilder.newDataset();
	newDataset.addColumn("CodEmpresa");
	newDataset.addColumn("CodEstab");
	newDataset.addColumn("CodEspecDoc");
	newDataset.addColumn("CodSerDoc");
	newDataset.addColumn("CodTitACR");
	newDataset.addColumn("CdnCliente");
	newDataset.addColumn("NomAbrev");
	newDataset.addColumn("DataEmiss");
	newDataset.addColumn("DataVenc");
	newDataset.addColumn("ValorOri");
	newDataset.addColumn("ValSaldo");

	var filtro = '';

		if (constraints[0].initialValue != null && constraints[0].initialValue != 300) 
			filtro = "" + constraints[0].initialValue;
		else
			filtro = "" + constraints[1].initialValue;
	//var filtro  = "013";
	
	try {
		// Utiliza o ServiceManager para obter uma referencia ao servico.
		var serviceProvider = ServiceManager.getService('TOTVS');
		var serviceLocator  = serviceProvider.instantiate('com.totvs.framework.ws.execbo.service.WebServiceExecBO');
		var service         = serviceLocator.getWebServiceExecBOPort();

		// Faz login e recebe o token de autenticacao
		var token = service.userLogin("fluig");

		var json  = montaJson(filtro);

		// Chama a procedure passando os parametros e o token de autenticacao.
		var resp = service.callProcedureWithToken(token, "dzp/dzwf001.p", "ws-busca-tit-acr", json);

		var respObj = JSON.parse(resp);

		var callProcedureWithTokenResponse = JSON.parse(respObj[0].value);
		
		for (var i in callProcedureWithTokenResponse.records){
	    	newDataset.addRow(new Array(
			callProcedureWithTokenResponse.records[i]["cod-empresa"], 
			callProcedureWithTokenResponse.records[i]["cod-estab"], 
			callProcedureWithTokenResponse.records[i]["cod-espec-docto"],
			callProcedureWithTokenResponse.records[i]["cod-ser-docto"],
			callProcedureWithTokenResponse.records[i]["cod-tit-acr"],
			callProcedureWithTokenResponse.records[i]["cdn-cliente"],
			callProcedureWithTokenResponse.records[i]["nom-abrev"],
			callProcedureWithTokenResponse.records[i]["dat-emis-docto"],
			callProcedureWithTokenResponse.records[i]["dat-vencto-tit-acr"],
			callProcedureWithTokenResponse.records[i]["val-origin-tit-acr"],
			callProcedureWithTokenResponse.records[i]["val-sdo-tit-acr"])
			);
	    }
	} catch (e) {
		log.info("ERRO: "+e);
	}

	return newDataset;
}

function montaJson(filtro){
	log.info("montaJson");

	var codEmpresa     	 = new Object();
	codEmpresa.type 	 = "character";
	codEmpresa.name 	 = "cod-empresa";
	codEmpresa.label   	 = "codEmpresa";

	var codEstab 		 = new Object();
	codEstab.type 	 	 = "character";
	codEstab.name 	 	 = "cod-estab"; 
	codEstab.label 	 	 = "codEstab";

	var codEspecDocto    = new Object();
	codEspecDocto.type   = "character";
	codEspecDocto.name   = "cod-espec-docto"; 
	codEspecDocto.label  = "codEspecDocto";
	
	var codSerDocto 	 = new Object();
	codSerDocto.type     = "character";
	codSerDocto.name 	 = "cod-ser-docto"; 
	codSerDocto.label    = "codSerDocto";
	
	var codTitAcr 	   	 = new Object();
	codTitAcr.type    	 = "character";
	codTitAcr.name 	     = "cod-tit-acr"; 
	codTitAcr.label 	 = "codTitAcr";

	var cdnCliente 	 	 = new Object();
	cdnCliente.type    	 = "integer";
	cdnCliente.name 	 = "cdn-cliente"; 
	cdnCliente.label 	 = "cdnCliente";

	var nomAbrev   	 	 = new Object();
	nomAbrev.type 	 	 = "character";
	nomAbrev.name 	 	 = "nom-abrev"; 
	nomAbrev.label		 = "nomAbrev";

	var datemisDocto 	 = new Object();
	datemisDocto.type    = "date";
	datemisDocto.name    = "dat-emis-docto"; 
	datemisDocto.label   = "datemisDocto";

	var datVenctoTitAcr  = new Object();
	datVenctoTitAcr.type = "date";
	datVenctoTitAcr.name = "dat-vencto-tit-acr"; 
	datVenctoTitAcr.label= "datVenctoTitAcr";

	var valOriginTitAcr  = new Object();
	valOriginTitAcr.type = "decimal";
	valOriginTitAcr.name = "val-origin-tit-acr"; 
	valOriginTitAcr.label= "valOriginTitAcr";

	var valSdoTitAcr 	 = new Object();
	valSdoTitAcr.type  	 = "decimal";
	valSdoTitAcr.name  	 = "val-sdo-tit-acr"; 
	valSdoTitAcr.label   = "valSdoTitAcr";
	
    //formador do parametro value para temp-table
	var tTable			= new Object();
    tTable.name 		= "tt-tit-acr";
    tTable.records 		= new Array();
    tTable.fields		= [codEmpresa, codEstab, codEspecDocto, codSerDocto, codTitAcr, cdnCliente, nomAbrev, datemisDocto, datVenctoTitAcr, valOriginTitAcr, valSdoTitAcr];
    
    //array para receber os parametros input da chamada da função
   
    var input 		= new Object();
    input.dataType	= "character";
    input.name  	= "p-cod-tit-acr";
    input.label 	= "p-cod-tit-acr";
    input.type 	    = "input";
    input.value 	= filtro;
    
	var output 		= new Object();
	output.dataType	= "temptable";
	output.name 	= "tt-tit-acr";
	output.type 	= "output";
	output.value 	= tTable;
	
	var params = [input, output];
	
	log.info(JSON.stringify(params));
	//conversor dos parametros de input para Json
	return JSON.stringify(params);
}