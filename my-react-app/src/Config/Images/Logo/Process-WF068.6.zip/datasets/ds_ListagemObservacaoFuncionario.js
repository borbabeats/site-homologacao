function createDataset(fields, constraints, sortFields) {
      var newDataset = DatasetBuilder.newDataset();

      newDataset.addColumn("cdn_funcionario");
      newDataset.addColumn("dat_obs_func");
      newDataset.addColumn("dat_term_obs");
      newDataset.addColumn("cdn_obs_func");
      newDataset.addColumn("des_obs_func");


      var filtro  =  ""+fields[0];
      //var filtro = "

      try {
            var serviceProvider = ServiceManager.getService('TOTVS');
            var serviceLocator = serviceProvider.instantiate('com.totvs.framework.ws.execbo.service.WebServiceExecBO');
            var service = serviceLocator.getWebServiceExecBOPort();

            var token = service.userLogin("fluig");
            var json = montaJson(filtro);

            var resp = service.callProcedureWithToken(token, "dzp/dzwf001.p", "ws-busca-funcionario-observ", json);
            
            var respObj = JSON.parse(resp);

            var callProcedureWithTokenResponse = JSON.parse(respObj[0].value);

            for (var i in callProcedureWithTokenResponse.records) {
                  newDataset.addRow([
                        callProcedureWithTokenResponse.records[i]["cdn-funcionario"],
                        callProcedureWithTokenResponse.records[i]["dat-obs-func"],
                        callProcedureWithTokenResponse.records[i]["dat-term-obs"],
                        callProcedureWithTokenResponse.records[i]["cdn-obs-func"],
                        callProcedureWithTokenResponse.records[i]["des-obs-func"]

                  ]
                  );
            }
      } catch (e) {
            log.info("ERRO: " + e);
      }

      return newDataset;
}

function montaJson(filtro) {
      log.info("montaJson");

      var cdn_funcionario = {}
      cdn_funcionario.type = "integer";
      cdn_funcionario.name = "cdn-funcionario";
      cdn_funcionario.label = "cdn_funcionario";

      var dat_obs_func = {}
      dat_obs_func.type = "date";
      dat_obs_func.name = "dat-obs-func";
      dat_obs_func.label = "dat_obs_func";

      var dat_term_obs = {}
      dat_term_obs.type = "date";
      dat_term_obs.name = "dat-term-obs";
      dat_term_obs.label = "dat_term_obs";

      var cdn_obs_func = {}
      cdn_obs_func.type = "integer";
      cdn_obs_func.name = "cdn-obs-func";
      cdn_obs_func.label = "cdn_obs_func";

      var des_obs_func = {}
      des_obs_func.type = "character";
      des_obs_func.name = "des-obs-func";
      des_obs_func.label = "des_obs_func";



      var tTable = {};
      tTable.name = 'tt-obs-func';
      tTable.records = [];
      tTable.fields = [cdn_funcionario, dat_obs_func, dat_term_obs, cdn_obs_func, des_obs_func];


      var input = {};
      input.dataType = "integer";
      input.name = "p-cdn-funcionario";
      input.label = "p-cdn-funcionario";
      input.type = "input";
      input.value = filtro;


      var output = {};
      output.dataType = "temptable";
      output.name = "tt-obs-func";
      output.type = "output";
      output.value = tTable;


      var params = [input, output];

      log.info(JSON.stringify(params));
      //conversor dos parametros de input para Json
      return JSON.stringify(params);
}
