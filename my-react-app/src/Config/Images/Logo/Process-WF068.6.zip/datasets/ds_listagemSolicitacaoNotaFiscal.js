function createDataset(fields, constraints, sortFields) {
	var newDataset = DatasetBuilder.newDataset();

	newDataset.addColumn("NRSolicitacao");
	newDataset.addColumn("Data");
	newDataset.addColumn("cod_emitente");
	newDataset.addColumn("nome_emitente");
	newDataset.addColumn("it_codigo");
	newDataset.addColumn("desc_item");
	newDataset.addColumn("quantidade");
	newDataset.addColumn("valor");
	newDataset.addColumn("observacao");


// 	var filtro = '137911';
	var filtro = '';

	if (constraints[0].initialValue != null && constraints[0].initialValue != 300)
		filtro = "" + constraints[0].initialValue;
	else
		filtro = "" + constraints[1].initialValue;

	try {
		var serviceProvider = ServiceManager.getService('TOTVS');
		var serviceLocator = serviceProvider.instantiate('com.totvs.framework.ws.execbo.service.WebServiceExecBO');
		var service = serviceLocator.getWebServiceExecBOPort();

		var token = service.userLogin("fluig");
		var json = montaJson(filtro);

		var resp = service.callProcedureWithToken(token, "dzp/dzwf001.p", "ws-busca-solic-nota", json);

		var respObj = JSON.parse(resp);

		var callProcedureWithTokenResponse = JSON.parse(respObj[0].value);

		for (var i in callProcedureWithTokenResponse.records) {
			newDataset.addRow([
				callProcedureWithTokenResponse.records[i]["nr-solicitacao"],
				callProcedureWithTokenResponse.records[i]["dt-solicitacao"],
				callProcedureWithTokenResponse.records[i]["cod-emitente"],
				callProcedureWithTokenResponse.records[i]["nome-emitente"],
				callProcedureWithTokenResponse.records[i]["it-codigo"],
				callProcedureWithTokenResponse.records[i]["desc-item"],
				callProcedureWithTokenResponse.records[i]["quantidade"],
				callProcedureWithTokenResponse.records[i]["valor"],
				callProcedureWithTokenResponse.records[i]["observacao"]

			]
			);
		}
	} catch (e) {
		log.info("ERRO: " + e);
	}

	return newDataset;
}

function montaJson(filtro) {
	log.info("montaJson");

	var nr_solicitacao = {}
	nr_solicitacao.type = "integer";
	nr_solicitacao.name = "nr-solicitacao";
	nr_solicitacao.label = "NRSolicitacao";

	var dt_solicitacao = {}
	dt_solicitacao.type = "date";
	dt_solicitacao.name = "dt-solicitacao";
	dt_solicitacao.label = "Data";

	var cod_emitente = {}
	cod_emitente.type = "integer";
	cod_emitente.name = "cod-emitente";
	cod_emitente.label = "cod_emitente";

	var nome_emitente = {}
	nome_emitente.type = "character";
	nome_emitente.name = "nome-emitente";
	nome_emitente.label = "nome_emitente";

	var it_codigo = {}
	it_codigo.type = "character";
	it_codigo.name = "it-codigo";
	it_codigo.label = "it_codigo";

	var desc_item = {}
	desc_item.type = "character";
	desc_item.name = "desc-item";
	desc_item.label = "desc_item";

	var quantidade = {}
	quantidade.type = "decimal";
	quantidade.name = "quantidade";
	quantidade.label = "quantidade";

	var valor = {}
	valor.type = "decimal";
	valor.name = "valor";
	valor.label = "valor";

	var observacao = {}
	observacao.type = "character";
	observacao.name = "observacao";
	observacao.label = "observacao";


	var tTable = {};
	tTable.name = 'tt-solic-nota';
	tTable.records = [];
	tTable.fields = [nr_solicitacao, dt_solicitacao, cod_emitente, nome_emitente, it_codigo, desc_item, quantidade, valor, observacao];

	var input = {};
	input.dataType = "integer";
	input.name = "p-nr-solicitacao";
	input.label = "p-nr-solicitacao";
	input.type = "input";
	input.value = filtro;


	var output = {};
	output.dataType = "temptable";
	output.name = "tt-solic-nota";
	output.type = "output";
	output.value = tTable;


	var params = [input, output];

	log.info(JSON.stringify(params));
	//conversor dos parametros de input para Json
	return JSON.stringify(params);
}