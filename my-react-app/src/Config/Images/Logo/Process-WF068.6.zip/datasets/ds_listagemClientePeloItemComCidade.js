function createDataset(fields, constraints, sortFields){
	var newDataset = DatasetBuilder.newDataset();
	newDataset.addColumn("Código Maxiforja");
	newDataset.addColumn("Nome abreviado");
	newDataset.addColumn("Código cliente");
	newDataset.addColumn("Cidade");
	newDataset.addColumn("Estado");
	
	// var filtro  =   "16375.01000";
	var filtro  =   ""+fields[0];
	var codEmitente  =   ""+fields[1];

	try {
		// Utiliza o ServiceManager para obter uma referencia ao servico.
		var serviceProvider = ServiceManager.getService('TOTVS');
		var serviceLocator  = serviceProvider.instantiate('com.totvs.framework.ws.execbo.service.WebServiceExecBO');
		var service         = serviceLocator.getWebServiceExecBOPort();

		// Faz login e recebe o token de autenticacao
		var token = service.userLogin("fluig");

		var json  = montaJson(filtro);

		// Chama a procedure passando os parametros e o token de autenticacao.
		var resp = service.callProcedureWithToken(token, "dzp/dzwf001.r", "ws-busca-item-cliente-cidade", json);

		var respObj = JSON.parse(resp);

		var callProcedureWithTokenResponse = JSON.parse(respObj[0].value);
		
		for (var i in callProcedureWithTokenResponse.records){
			if(codEmitente == callProcedureWithTokenResponse.records[i]["cod-emitente"]){
				newDataset.addRow(new Array(
				callProcedureWithTokenResponse.records[i]["cod-emitente"],
				callProcedureWithTokenResponse.records[i]["nome-abrev"],
				callProcedureWithTokenResponse.records[i]["item-do-cli"],
				callProcedureWithTokenResponse.records[i]["cidade"],
				callProcedureWithTokenResponse.records[i]["estado"])
				);
	    		}
	    	}
	} catch (e) {
		log.info("ERRO: "+e);
	}

	return newDataset;
}

function montaJson(filtro){
	log.info("montaJson");

	var codEmit 	= new Object();
	codEmit.type 	= "integer";
	codEmit.name 	= "cod-emitente";
	codEmit.label 	= "codigoEmitente";

	var nomeAbrev 	= new Object();
	nomeAbrev.type 	= "character";
	nomeAbrev.name 	= "nome-abrev";
	nomeAbrev.label = "nomeAbrev"; 

	var codItCli 	= new Object();
	codItCli.type 	= "character";
	codItCli.name 	= "item-do-cli";
	codItCli.label 	= "NumItemCliente";
	
	var cidCli 		= new Object();
	cidCli.type 	= "character";
	cidCli.name 	= "cidade";
	cidCli.label 	= "cidadeCliente";
	
	var estCli 		= new Object();
	estCli.type 	= "character";
	estCli.name 	= "estado";
	estCli.label 	= "estadoCliente";
	    
    //formador do paremetro value para temp-table
    var tTable		= new Object();
    tTable.name 	= "tt-item-cli-cidade";
    tTable.records 	= new Array();
    tTable.fields 	= [codEmit, nomeAbrev, codItCli, cidCli, estCli];
    
    //array para receber os parametros input da chamada da função
   
    var input 		= new Object();
	input.dataType	= "character";
	input.name 		= "p-it-codigo";
	input.label 	= "p-it-codigo";
	input.type 		= "input";
	input.value 	= filtro;
    
	var output 		= new Object();
	output.dataType	= "temptable";
	output.name 	= "tt-item-cli-cidade";
	output.type 	= "output";
	output.value 	= tTable;
	
	var params = [input, output];
	
	log.info(JSON.stringify(params));
	//conversor dos parametros de input para Json
	return JSON.stringify(params);
}