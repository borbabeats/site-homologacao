function createDataset(fields, constraints, sortFields) {
    var newDataset = DatasetBuilder.newDataset();
    try {

        // var numSolicDe = ""
        // var numSolicAte = ""
        var dateDe = ""
        var dateAte = ""
        var numMatricula = ""
        // var strNome = ""

        if (fields != null) {
            // numSolicDe = '' + fields[0]
            // numSolicAte = '' + fields[1]
            dateDe = '' + fields[0]
            dateAte = '' + fields[1]
            numMatricula = '' + fields[2]
            // strNome = '' + fields[5]
        }

        var dataSource = "/jdbc/AppDS";
        var ic = new javax.naming.InitialContext();
        var ds = ic.lookup(dataSource);
        var created = false;

        var myQuery = "Select p.NUM_PROCES , t.zoom_matricula , t.txt_nomeSolicitante , t.txt_cargo , t.txt_centroCusto , DATE_FORMAT(p.START_DATE ,'%d/%m/%Y') as dataInicio from ml001064  as t inner join proces_workflow as p on p.NR_DOCUMENTO_CARD = t.documentid where"

        // if (numSolicDe != '' && numSolicDe != null)
        //     myQuery += " (p.NUM_PROCES > " + numSolicDe
        // else
        //     myQuery += " (p.NUM_PROCES > 0"

        // if (numSolicAte != '' && numSolicAte != null)
        //     myQuery += " and p.NUM_PROCES < " + numSolicAte + ")"
        // else
        //     myQuery += " and p.NUM_PROCES < 999999999)"

        if (dateDe != '' && dateDe != null)
            myQuery += "  (p.START_DATE >'" + dateDe + "'"
        else
            myQuery += "  (p.START_DATE >'0001-01-01' "

        if (dateAte != '' && dateAte != null)
            myQuery += " and p.START_DATE < '" + dateAte + "')"
        else
            myQuery += " and p.START_DATE < '9999-12-31')"

        if (numMatricula != '' && numMatricula != null)
            myQuery += " and t.zoom_matricula = " + numMatricula

        // if (strNome != '' && strNome != null)
        //     myQuery += " and t.txt_nomeSolicitante like '%" + strNome + "%'"

        myQuery += " order by  p.NUM_PROCES desc;"

        log.error("QUERYYYYYY " + myQuery);

        var conn = ds.getConnection();
        var stmt = conn.createStatement();
        var rs = stmt.executeQuery(myQuery);
        var columnCount = rs.getMetaData().getColumnCount();
        while (rs.next()) {
            if (!created) {
                for (var i = 1; i <= columnCount; i++) {
                    newDataset.addColumn(rs.getMetaData().getColumnName(i));
                }
                created = true;
            }
            var Arr = new Array();
            for (var i = 1; i <= columnCount; i++) {
                var obj = rs.getObject(rs.getMetaData().getColumnName(i));
                if (null != obj) {
                    Arr[i - 1] = rs.getObject(rs.getMetaData().getColumnName(i)).toString();
                } else {
                    Arr[i - 1] = "null";
                }
            }
            newDataset.addRow(Arr);
        }
    } catch (e) {
        log.error("ERRO==============> " + e.message + ": " + myQuery);
    } finally {
        if (stmt != null) {
            stmt.close();
        }
        if (conn != null) {
            conn.close();
        }
    }

    return newDataset;
}