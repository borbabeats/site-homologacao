function createDataset(fields, constraints, sortFields){
	var newDataset = DatasetBuilder.newDataset();
	newDataset.addColumn("CodCCusto");
	newDataset.addColumn("Descricao");
	newDataset.addColumn("CodGestor");
	newDataset.addColumn("Gestor");
	newDataset.addColumn("codDiretor");
	newDataset.addColumn("Diretor");
	
	var filtro = '';

		if (constraints[0].initialValue != null && constraints[0].initialValue != 300) 
			filtro = "" + constraints[0].initialValue;
		else
			filtro = "" + constraints[1].initialValue;

	//var filtro  = "23121003"; // coloca uma num valido

	try {
		// Utiliza o ServiceManager para obter uma referencia ao servico.
		var serviceProvider = ServiceManager.getService('TOTVS');
		var serviceLocator  = serviceProvider.instantiate('com.totvs.framework.ws.execbo.service.WebServiceExecBO');
		var service         = serviceLocator.getWebServiceExecBOPort();

		// Faz login e recebe o token de autenticacao
		var token = service.userLogin("fluig");

		var json  = montaJson(filtro);

		// Chama a procedure passando os parametros e o token de autenticacao.
		var resp = service.callProcedureWithToken(token, "dzp/dzwf001.p", "ws-busca-ccusto-codigo", json);

		var respObj = JSON.parse(resp);

		var callProcedureWithTokenResponse = JSON.parse(respObj[0].value);

		for (var i in callProcedureWithTokenResponse.records){
	    	newDataset.addRow(new Array(
	    	callProcedureWithTokenResponse.records[i]["cod-ccusto"],
	    	callProcedureWithTokenResponse.records[i]["descricao"],
	    	callProcedureWithTokenResponse.records[i]["cod-usuar-gestor"],
			callProcedureWithTokenResponse.records[i]["nom-usuario-gestor"],
	    	callProcedureWithTokenResponse.records[i]["cod-usuar-diretor"],
			callProcedureWithTokenResponse.records[i]["nom-usuario-diretor"])//field da temptable
			);
	    }
	} catch (e) {
		log.info("### ERRO: "+e);
	}

	return newDataset;
}

function montaJson(filtro){
	log.info("montaJson");

	var codigo     	= new Object();
	codigo.type	   	= "character";//parameter type
	codigo.name    	= "cod-ccusto";//field da temptable
	codigo.label   	= "codigo";

	var descricao   = new Object();
	descricao.type  = "character";
	descricao.name	= "descricao";
	descricao.label	= "descricao";

	var codGestor   = new Object();
	codGestor.type 	= "character";
	codGestor.name	= "cod-usuar-gestor";
	codGestor.label	= "codGestor";

	var nomGestor  	= new Object();
	nomGestor.type  = "character";
	nomGestor.name	= "nom-usuario-gestor";
	nomGestor.label	= "nomGestor";	
	
	var codDiretor  = new Object();
	codDiretor.type = "character";
	codDiretor.name	= "cod-usuar-diretor";
	codDiretor.label= "codDiretor";

	var nomDiretor  = new Object();
	nomDiretor.type = "character";
	nomDiretor.name	= "nom-usuario-diretor";
	nomDiretor.label= "nomDiretor";

    //formador do parametro value para temp-table
	var tTable		= new Object();
    tTable.name   	= "tt-ccusto";//nome da temp-table
    tTable.records 	= new Array();
    tTable.fields	= [codigo, descricao, codGestor, nomGestor, codDiretor, nomDiretor];

    //array para receber os parametros input da chamada da função

    var input 		 = new Object();
    input.dataType   = "character";
    input.name  	 = "p-cod-ccusto";//procedure input
    input.label 	 = "p-cod-ccusto";
    input.type 	  	 = "input";
    input.value 	 = filtro;

	var output 	  	 = new Object();
	output.dataType  = "temptable";
	output.name   	 = "tt-ccusto";//nome da temp-table
	output.type   	 = "output";
	output.value  	 = tTable;

	var params = [input, output];

	log.info(JSON.stringify(params));
	//conversor dos parametros de input para Json
	return JSON.stringify(params);
}
