function createDataset(fields, constraints, sortFields) {

    // Cria as colunas
    var newDataset = DatasetBuilder.newDataset();
    newDataset.addColumn("Codigo_familia");
    newDataset.addColumn("Nome_familia");
    newDataset.addColumn("Conta_contabil");

    var array   = new Array();
    var auxArray;
    var filtro  =   constraints[1];

    // Grupo 15
    array.push(new Array("15AMOSTR", "AMOSTRAS DE COMPONENTES", 					"2 - 4.1.3.0.0200"));
    array.push(new Array("15CIND", 	"COMPONENTES INDUSTRIAIS", 						"2 - 4.1.3.0.0200"));
    // Grupo 20
    array.push(new Array("20ABRA", 	"ABRASIVOS", 									"2 - 4.1.3.0.0200"));
    array.push(new Array("20DESM", 	"DESMOLDANTE", 									"3 - 4.1.3.0.0300"));
    array.push(new Array("20GRAN", 	"GRANALHAS", 									"2 - 4.1.3.0.0200"));
    array.push(new Array("20QUIM", 	"QUIMICOS", 									"3 - 4.1.3.0.0300"));
    array.push(new Array("20SOLD", 	"SOLDA", 										"2 - 4.1.3.0.0200"));
    array.push(new Array("20TINT", 	"TINTAS PRODUÇÃO", 								"2 - 4.1.3.0.0200"));
    // Grupo 25
    array.push(new Array("25APPS", 	"ACESSORIOS, PAPELAO E PLASTICO", 				"7 - 4.1.3.0.0500"));
    array.push(new Array("25CAIX", 	"CAIXAS DE TERCEIROS", 							"7 - 4.1.3.0.0500"));
    array.push(new Array("25CEST", 	"CESTOS INOX - TRAT. TERMICO", 					"2 - 4.1.3.0.0200"));
    array.push(new Array("25EMBA", 	"EMBALAGENS DE AÇO", 							"7 - 4.1.3.0.0500"));
    array.push(new Array("25EMBI", 	"EMBALAGENS DE USO INTERNO", 					"7 - 4.1.3.0.0500"));
    array.push(new Array("25EMBL", 	"EMBALAGENS DE PAPELAO", 						"7 - 4.1.3.0.0500"));
    array.push(new Array("25EMBM", 	"EMBALAGENS DE MADEIRA", 						"7 - 4.1.3.0.0500"));
    array.push(new Array("25EMBP", 	"EMBALAGENS PLASTICAS",							"7 - 4.1.3.0.0500"));
    array.push(new Array("25EMBT", 	"EMBALAGENS DE TERCEIROS", 						"7 - 4.1.3.0.0500"));
    // Grupo 30
    array.push(new Array("30EPIS", 	"EPIS", 										"75 - 4.2.2.6.0010"));
    array.push(new Array("30MAMB", 	"MEIO AMBIENTE", 								"4 - 4.1.3.0.0400"));
    array.push(new Array("30SINA", 	"SINALIZACAO/IDENTIFICACAO", 					"4 - 4.1.3.0.0400"));
    array.push(new Array("30SMAQ", 	"SEGURANCA EM MAQUINAS", 						"4 - 4.1.3.0.0400"));
    array.push(new Array("30SPAT", 	"SEGURANCA PATRIMONIAL", 						"4 - 4.1.3.0.0400"));
    array.push(new Array("30UNIF", 	"UNIFORME", 									"75 - 4.2.2.6.0010"));
    // Grupo 35
    array.push(new Array("35AMBU", 	"AMBULATORIO", 									"6 - 4.2.2.6.0001"));
    array.push(new Array("35CONF", 	"MATERIAIS P/CONFRATERNIZACAO", 				"59 - 4.2.2.6.0004"));
    array.push(new Array("35CRAC", 	"CRACHAS DE IDENTIFICACAO", 					"60 - 4.2.2.6.0003"));
    array.push(new Array("35CVAT", 	"CARTAO VALE TRANSPORTE", 						"42 - 4.2.1.3.0002"));
    array.push(new Array("35ESCR", 	"ESCRITORIO", 									"36 - 4.2.2.7.0003"));
    array.push(new Array("35FLOR", 	"FLORICULTURA", 								"58 - 4.2.2.6.0002"));
    array.push(new Array("35INFO", 	"INFORMATICA", 									"64 - 4.2.2.7.0004"));
    array.push(new Array("35LABO", 	"INSTRUMENTOS DE LABORATORIO", 					"4 - 4.1.3.0.0400"));
    array.push(new Array("35LIMP", 	"LIMPEZA", 										"66 - 4.2.2.7.0002"));
    array.push(new Array("35LIVR", 	"LIVROS, NORMAS E PUBLICACOES", 				"67 - 4.2.2.6.0007"));
    // Grupo 40
    array.push(new Array("40ACOF", 	"ACO PARA FERRAMENTARIA", 						"41 - 4.1.3.0.0100"));
    array.push(new Array("40ESTAMP", "FERRAMENTAIS DE ESTAMPAGEM", 					"41 - 4.1.3.0.0100"));
    array.push(new Array("40FUNDID", "FERRAMENTAIS DE FUNDIDOS", 					"41 - 4.1.3.0.0100"));
    array.push(new Array("40GRAF", 	"GRAFITES PARA ELETROEROSAO", 					"4 - 4.1.3.0.0400"));
    array.push(new Array("40INJETA", "FERRAMENTAIS DE INJETADOS", 					"41 - 4.1.3.0.0100"));
    array.push(new Array("40MATRIZ", "FERRAMENTAIS DE FORJAMENTO", 					"41 - 4.1.3.0.0100"));
    // Grupo 45
    array.push(new Array("45ACOM", 	"ACOS DE MANUTENCAO", 							"4 - 4.1.3.0.0400"));
    array.push(new Array("45CONS", 	"CONSTRUCAO CIVIL", 							"4 - 4.1.3.0.0400"));
    array.push(new Array("45ELEC", 	"MAT. ELETRO/ELETRON. CRITICOS", 				"4 - 4.1.3.0.0400"));
    array.push(new Array("45ELET", 	"MATERIAIS MANUTENCAO ELETRICA/ELETRONICA", 	"4 - 4.1.3.0.0400"));
    array.push(new Array("45EQUC", 	"EQUIP-CRÍTICOS PECAS REPOSICAO", 				"4 - 4.1.3.0.0400"));
    array.push(new Array("45EQUI", 	"EQUIPAMENTOS (PECAS REPOSICAO)", 				"4 - 4.1.3.0.0400"));
    array.push(new Array("45FERM", 	"FERRAMENTAS MANUAIS", 							"4 - 4.1.3.0.0400"));
    array.push(new Array("45FERP", 	"FERRAMENTAS PNEUMATICAS", 						"4 - 4.1.3.0.0400"));
    array.push(new Array("45INFO", 	"MATERIAIS MANUTENCAO INFORMATICA", 			"4 - 4.1.3.0.0400"));
    array.push(new Array("45MECA", 	"MATERIAIS MANUT. MECANICA", 					"4 - 4.1.3.0.0400"));
    array.push(new Array("45MECC", 	"MAT. MANUT. MECANICA CRÍTICOS", 				"4 - 4.1.3.0.0400"));
    array.push(new Array("45TINT", 	"Tintas Manutenção", 							"4 - 4.1.3.0.0400"));
    array.push(new Array("45VPPA", 	"VIDROS,PLASTICOS,POLIM.,ADESIV.", 				"4 - 4.1.3.0.0400"));
    // Grupo 50
    array.push(new Array("50ACES", 	"ACESSORIOS E SUPORTES DE USINAGEM", 			"2 - 4.1.3.0.0200"));
    array.push(new Array("50ACFF", 	"ACESSORIOS P/ FERRAM. FORJAR", 				"2 - 4.1.3.0.0400"));
    array.push(new Array("50ACFF", 	"ACESSÓRIOS P/FERRAMENTA DE FORJAMENTO", 		"2 - 4.1.3.0.0400"));
    array.push(new Array("50ALAR", 	"ALARGADORES", 									"2 - 4.1.3.0.0200"));
    array.push(new Array("50BRCH", 	"BROCHAS", 										"2 - 4.1.3.0.0200"));
    array.push(new Array("50BROC", 	"BROCAS", 										"2 - 4.1.3.0.0200"));
    array.push(new Array("50BRUN", 	"BRUNIDORES", 									"2 - 4.1.3.0.0200"));
    array.push(new Array("50CALI", 	"CALIBRES", 									"2 - 4.1.3.0.0200"));
    array.push(new Array("50CORD", 	"CORDOALHAS", 									"2 - 4.1.3.0.0200"));
    array.push(new Array("50COSS", 	"COSSINETES E SIMILARES", 						"2 - 4.1.3.0.0200"));
    array.push(new Array("50DISP", 	"DISPOSITIVOS DE USINAGEM", 					"2 - 4.1.3.0.0200"));
    array.push(new Array("50ESCA", 	"ESCAREADORES", 								"2 - 4.1.3.0.0200"));
    array.push(new Array("50FRES", 	"FRESAS", 										"2 - 4.1.3.0.0200"));
    array.push(new Array("50INDU", 	"INDUTORES", 									"2 - 4.1.3.0.0200"));
    array.push(new Array("50INSE", 	"INSERTOS", 									"2 - 4.1.3.0.0200"));
    array.push(new Array("50MACH", 	"MACHOS", 										"2 - 4.1.3.0.0200"));
    array.push(new Array("50MAND", 	"BARRAS DE MADRILAR", 							"2 - 4.1.3.0.0200"));
    array.push(new Array("50NCOR", 	"NAVALHAS DE CORTE", 							"2 - 4.1.3.0.0200"));
    array.push(new Array("50REBO", 	"REBOLOS E DRESSADORES", 						"2 - 4.1.3.0.0200"));
    array.push(new Array("50ROLO", 	"ROLOS LAMINADORES", 							"2 - 4.1.3.0.0200"));
    array.push(new Array("50SERR", 	"SERRAS", 										"2 - 4.1.3.0.0200"));
    array.push(new Array("50STOR", 	"SUPORTES DE TORNEAMENTO", 						"2 - 4.1.3.0.0200"));
    // Grupo 60
    array.push(new Array("60ALIM", 	"SERV. REFEITÓRIO", 							"30 - 4.2.2.3.0001"));
    array.push(new Array("60APER", 	"ASSINATURA DE PERIODICOS", 					"46 - 4.2.2.9.0001"));
    array.push(new Array("60AUDI", 	"SERV. AUDITORIAS", 							"51 - 4.2.2.3.0008"));
    array.push(new Array("60BENE", 	"BENEFICIAMENTO", 								"37 - 4.2.2.3.0013"));
    array.push(new Array("60CCIV", 	"SERVICOS DE CONSTRUCAO CIVIL", 				"30 - 4.2.2.3.0001"));
    array.push(new Array("60CONS", 	"SERV. CONSULTORIA", 							"52 - 4.2.2.3.0009"));
    array.push(new Array("60DEAD", 	"SERV. DESEMBARACO ADUANEIRO", 					"62 - 4.2.2.3.0014"));
    array.push(new Array("60FRCR", 	"FRETE DAS COLETAS DE RESÍDUOS", 				"70 - 4.2.2.8.0007"));
    array.push(new Array("60FRNA", 	"FRETE NACIONAL EXPRESSO", 						"49 - 4.2.2.8.0002"));
    array.push(new Array("60FRIN", 	"FRETE INTERNACIONAL", 							"27 - 4.2.2.8.0003"));
    array.push(new Array("60FRIX", 	"FRETE INTERNACIONAL EXPRESSO", 				"63 - 4.2.2.8.0004"));
    array.push(new Array("60FRVD", 	"FRETE SOBRE VENDAS", 							"47 - 4.2.2.8.0005"));
    array.push(new Array("60FRVX", 	"FRETE SOBRE VENDAS EXPRESSO", 					"48 - 4.2.2.8.0006"));
    array.push(new Array("60JURI", 	"SERV. JURIDICOS", 								"54 - 4.2.2.3.0004"));
    array.push(new Array("60LABO", 	"LABORATORIO E ANALISES", 						"30 - 4.2.2.3.0001"));
    array.push(new Array("60LIMP", 	"SERV. LIMPEZA", 								"61 - 4.2.2.3.0007"));
    array.push(new Array("60LOCA", 	"LOCACOES", 									"28 - 4.2.2.1.0014"));
    array.push(new Array("60LOGI", 	"SERVICOS DE LOGISTICA", 						"30 - 4.2.2.3.0001"));
    array.push(new Array("60MANU", 	"SERVICOS DE MANUTENCAO", 						"30 - 4.2.2.3.0001"));
    array.push(new Array("60PUBL", 	"PUBLICAÇÕES", 									"57 - 4.2.2.9.0008"));
    array.push(new Array("60RECS", 	"SERV. RECRUTAMENTO E SELECAO", 				"55 - 4.2.2.3.0010"));
    array.push(new Array("60REFE", 	"SERVICOS RECUPER. FERRAMENTAS", 				"5 - 4.2.2.3.0015"));
    array.push(new Array("60RETE", 	"SERVICOS RETRABALHO EMBALAGEM", 				"30 - 4.2.2.3.0001"));
    array.push(new Array("60RETP", 	"SERV. RETRABALHO PEÇA ACABADA", 				"37 - 4.2.2.3.0013"));
    array.push(new Array("60SADM", 	"SERVICOS ADMINISTRATIVOS GERAIS", 				"30 - 4.2.2.3.0001"));
    array.push(new Array("60SCAL", 	"CALIBRACOES E AFERICOES", 						"30 - 4.2.2.3.0001"));
    array.push(new Array("60SEGV", 	"SERV. DE SEGURANCA E VIGILANCIA", 				"31 - 4.2.2.3.0006"));
    array.push(new Array("60SEMA", 	"SEGURANCA E MEIO AMBIENTE", 					"30 - 4.2.2.3.0001"));
    array.push(new Array("60SINF", 	"SERVICOS DE INFORMATICA", 						"50 - 4.2.2.3.0011"));
    array.push(new Array("60SOFT", 	"Licenças de Softwares", 						"65 - 4.2.2.3.0012"));
    array.push(new Array("60SPRO", 	"SERVICOS PRODUTIVOS GERAIS", 					"30 - 4.2.2.3.0001"));
    array.push(new Array("60SVID", 	"SERVICOS SEGURO DE VIDA", 						"43 - 4.2.2.1.0010"));
    array.push(new Array("60TREI", 	"SERVICOS DE TREINAMENTO", 						"39 - 4.2.2.6.0008"));
    array.push(new Array("60VIAG", 	"SERVICOS DE VIAGENS", 							"32 - 4.2.2.5.0001"));
    // Grupo 90
    array.push(new Array("90DMOV", 	"DISPOSITIVOS DE MOVIMENTACAO", 				"2 - 4.1.3.0.0200"));
    array.push(new Array("90MAQU", 	"MAQUINA E EQUIPAMENTOS", 						"4 - 4.1.3.0.0400"));
    array.push(new Array("90MOVU", 	"MOVEIS E UTENSILIOS", 							"4 - 4.1.3.0.0400"));
    // Grupo 91
    array.push(new Array("91INST", 	"INSTRUMENTOS  DE METROLOGIA", 					"2 - 4.1.3.0.0200"));
    // Grupo 99
    array.push(new Array("99VDSUC", "VENDA DE SUCATA", 								"4 - 4.1.3.0.0400"));

    if(filtro != undefined && filtro != null){
        filtro = filtro.initialValue;
        for(var i = 0; i < array.length; i++){
            auxArray    =   array[i];
            for(var j = 0; j < auxArray.length; j++){
                if(auxArray[j].toLowerCase().indexOf(filtro.toString().toLowerCase()) != -1){
                    newDataset.addRow(auxArray);
                    j = auxArray.length;
                }
            }
        }
    }else{
        for(var i = 0; i < array.length; i++){
            newDataset.addRow(array[i]);
        }
    }
    
    return newDataset;
}