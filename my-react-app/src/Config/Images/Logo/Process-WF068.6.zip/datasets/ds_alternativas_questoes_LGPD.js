function createDataset(fields, constraints, sortFields) {

      // Cria as colunas
      var newDataset = DatasetBuilder.newDataset();
      newDataset.addColumn("id_question");
      newDataset.addColumn("question");

      var  array = [], array_ = [];
      array.push([1, 'Qual é o objetivo da LGPD?']);
      array.push([2, 'A lei se aplica a Maxiforja?']);
      array.push([3, 'Quem fiscaliza o cumprimento da lei em território brasileiro?']);
      array.push([4, 'Quem é o “titular do dado pessoal”?']);
      array.push([5, 'O que são “dados pessoais”?']);
      array.push([6, 'O que são “dados pessoais sensíveis”?']);
      array.push([7, 'Cite 3 integrantes da legislação?']);
      array.push([8, 'Cite 3 princípios da LGPD?']);
      array.push([9, 'A lei está disponível para consulta?']);
      array.push([10, 'Qual é o prazo para as Empresas se adequarem a LGPD?']);
      array.push([11, 'Você é coordenador de um departamento, e está trabalhando em um projeto de melhoria de máquinas de sua empresa. E envia para o seu e-mail pessoal informações sobre processos de fabricação e dados de produção para criar uma tabela que usará na empresa. Esta iniciativa é correta?']);
      array.push([12, 'Você percebe que possui acesso a um programa do sistema de sua empresa, que fornece informações pessoais de colegas de trabalho, como CPF, endereço, telefone, etc. E nas suas atividades não utiliza estas informações para nenhuma finalidade. Qual ação você deve tomar?']);
      array.push([13, 'Um novo funcionário fornece seus dados pessoais para a sua nova empresa. Esta empresa tem a responsabilidade de?']);
      array.push([14, 'São recolhidos durante o processo de admissão, dados referentes à saúde dos novos funcionários. Para este caso, a legislação (LGPD) orienta?']);
      array.push([15, 'Em quais casos a Lei Geral de Proteção de Dados não se aplica?']);
      array.push([16, 'Qual é a função do "Operador", considerado pela LGPD como um dos agentes de tratamento de dados na empresa?']);
      array.push([17, 'Aponte qual é a frase mais adequada e que resume as orientações relativas aos 3 pilares da LGPD, princípios de Finalidade, Necessidade e Adequação?']);
      array.push([18, 'Qual das três alternativas descreve uma das penalidades previstas em lei, para os casos de não atendimento da LGPD?']);
      array.push([19, 'Segundo a legislação o que não se pode fazer no tratamento dos dados pessoais?']);
      array.push([20, 'A empresa possui uma pasta compartilhada em sua rede interna, onde todas as áreas possuem acesso. É correto disponibilizar dados pessoais de colaboradores através deste recurso?']);

      for (var i = 0; i < array.length; i++) {
            newDataset.addRow(array[i]);
      }

      return newDataset;
}