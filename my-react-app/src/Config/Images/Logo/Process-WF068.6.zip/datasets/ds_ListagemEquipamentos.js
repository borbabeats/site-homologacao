function createDataset(fields, constraints, sortFields) {
      var newDataset = DatasetBuilder.newDataset();
      newDataset.addColumn("cod_maquina");
      newDataset.addColumn("dt_validade_ini");
      newDataset.addColumn("dt_validade_fin");
      newDataset.addColumn("lg_equip_critico");
      newDataset.addColumn("num_bem_pat");
      newDataset.addColumn("descricao_bem");
      newDataset.addColumn("plaqueta_pat");
      newDataset.addColumn("dt_fim_garantia");
      newDataset.addColumn("cc_codigo");
      newDataset.addColumn("descricao_cc");
      newDataset.addColumn("cd_categ_equipto");
      newDataset.addColumn("descricao_categ");
      newDataset.addColumn("localizacao");
      newDataset.addColumn("observacao");

      var filtro = ''+fields[0];

      if(filtro == '' || filtro == 'cod_maquina')
            filtro = ''+constraints[1].initialValue;



      try {
            var serviceProvider = ServiceManager.getService('TOTVS');
            var serviceLocator = serviceProvider.instantiate('com.totvs.framework.ws.execbo.service.WebServiceExecBO');
            var service = serviceLocator.getWebServiceExecBOPort();

            var token = service.userLogin("fluig");
            var json = montaJson(filtro);

            var resp = service.callProcedureWithToken(token, "dzp/dzwf001.p", "ws-busca-equipamento", json);

            var respObj = JSON.parse(resp);

            var callProcedureWithTokenResponse = JSON.parse(respObj[0].value);

            for (var i in callProcedureWithTokenResponse.records) {
                  newDataset.addRow([
                        callProcedureWithTokenResponse.records[i]["cod-maquina"],
                        callProcedureWithTokenResponse.records[i]["dt-validade-ini"],
                        callProcedureWithTokenResponse.records[i]["dt-validade-fin"],
                        callProcedureWithTokenResponse.records[i]["lg-equip-critico"],
                        callProcedureWithTokenResponse.records[i]["num-bem-pat"],
                        callProcedureWithTokenResponse.records[i]["descricao-bem"],
                        callProcedureWithTokenResponse.records[i]["plaqueta-pat"],
                        callProcedureWithTokenResponse.records[i]["dt-fim-garantia"],
                        callProcedureWithTokenResponse.records[i]["cc-codigo"],
                        callProcedureWithTokenResponse.records[i]["descricao-cc"],
                        callProcedureWithTokenResponse.records[i]["cd-categ-equipto"],
                        callProcedureWithTokenResponse.records[i]["descricao-categ"],
                        callProcedureWithTokenResponse.records[i]["localizacao"],
                        callProcedureWithTokenResponse.records[i]["observacao"]

                  ]
                  );
            }
      } catch (e) {
            log.info("ERRO: " + e);
      }

      return newDataset;
}

function montaJson(filtro) {
      log.info("montaJson");

      var cod_maquina = {}
      cod_maquina.type = "character";
      cod_maquina.name = "cod-maquina";
      cod_maquina.label = "cod_maquina";

      var dt_validade_ini = {}
      dt_validade_ini.type = "date";
      dt_validade_ini.name = "dt-validade-ini";
      dt_validade_ini.label = "dt_validade_ini";

      var dt_validade_fin = {}
      dt_validade_fin.type = "date";
      dt_validade_fin.name = "dt-validade-fin";
      dt_validade_fin.label = "dt_validade_fin";

      var lg_equip_critico = {}
      lg_equip_critico.type = "logical";
      lg_equip_critico.name = "lg-equip-critico";
      lg_equip_critico.label = "lg_equip_critico";

      var num_bem_pat = {}
      num_bem_pat.type = "integer";
      num_bem_pat.name = "num-bem-pat";
      num_bem_pat.label = "num_bem_pat";

      var descricao_bem = {}
      descricao_bem.type = "character";
      descricao_bem.name = "descricao-bem";
      descricao_bem.label = "descricao_bem";

      var plaqueta_pat = {}
      plaqueta_pat.type = "character";
      plaqueta_pat.name = "plaqueta-pat";
      plaqueta_pat.label = "plaqueta_pat";

      var dt_fim_garantia = {}
      dt_fim_garantia.type = "date";
      dt_fim_garantia.name = "dt-fim-garantia";
      dt_fim_garantia.label = "dt_fim_garantia";

      var cc_codigo = {}
      cc_codigo.type = "character";
      cc_codigo.name = "cc-codigo";
      cc_codigo.label = "cc_codigo";

      var descricao_cc = {}
      descricao_cc.type = "character";
      descricao_cc.name = "descricao-cc";
      descricao_cc.label = "descricao_cc";

      var cd_categ_equipto = {}
      cd_categ_equipto.type = "integer";
      cd_categ_equipto.name = "cd-categ-equipto";
      cd_categ_equipto.label = "cd_categ_equipto";

      var descricao_categ = {}
      descricao_categ.type = "character";
      descricao_categ.name = "descricao-categ";
      descricao_categ.label = "descricao_categ";

      var localizacao = {}
      localizacao.type = "character";
      localizacao.name = "localizacao";
      localizacao.label = "localizacao";

      var observacao = {}
      observacao.type = "character";
      observacao.name = "observacao";
      observacao.label = "observacao";



      var tTable = {};
      tTable.name = 'tt-equipamento';
      tTable.records = [];
      tTable.fields = [cod_maquina, dt_validade_ini, dt_validade_fin, lg_equip_critico, num_bem_pat, descricao_bem, plaqueta_pat, dt_fim_garantia, cc_codigo, descricao_cc, cd_categ_equipto, descricao_categ, localizacao, observacao];


      var input = {};
      input.dataType = "character";
      input.name = "p-cod-maquina";
      input.label = "p-cod-maquina";
      input.type = "input";
      input.value = filtro; //'  ' 

      var input1 = {};
      input1.dataType = "character";
      input1.name = "p-num-bem-pat";
      input1.label = "p-num-bem-pat";
      input1.type = "input";
      input1.value = filtro; // '006763'


      var output = {};
      output.dataType = "temptable";
      output.name = "tt-equipamento";
      output.type = "output";
      output.value = tTable;


      var params = [input, input1, output];

      log.info(JSON.stringify(params));
      //conversor dos parametros de input para Json
      return JSON.stringify(params);
}
