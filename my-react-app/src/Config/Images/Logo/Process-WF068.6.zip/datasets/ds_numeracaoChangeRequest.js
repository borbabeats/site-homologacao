function createDataset(fields, constraints, sortFields) {
	var newDataset = DatasetBuilder.newDataset();
	
	newDataset.addColumn("Numero_Ultimo_CR");
	newDataset.addColumn("Numero_Novo_CR");
	newDataset.addColumn("Prefixo_Geral");
	newDataset.addColumn("Prefixo_SAT");
	newDataset.addColumn("Prefixo_GMT");
	
	var ChangeResquest = "CR";
	var sat = "SAT";
	var gmt = "GMT";
	
	var c1          = DatasetFactory.createConstraint("metadata#active", "true", "true", ConstraintType.MUST);
    var constraints = new Array(c1);
	var dataset 	= DatasetFactory.getDataset("ds_changeRequest", null, constraints, null);
    var numeroAtual = addZero(dataset.rowsCount);
    var novoNumero  = addZero(dataset.rowsCount + 1);
	
	newDataset.addRow(new Array(numeroAtual, novoNumero, ChangeResquest, sat, gmt));
	
	return newDataset;
}

function addZero(value){
	value = value.toString();
	while(value.length < 6){
		value = "0" + value;
	}
	return value;
}