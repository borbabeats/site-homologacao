function createDataset(fields, constraints, sortFields) {
      var newDataset = DatasetBuilder.newDataset();

      newDataset.addColumn("cdn_funcionario");
      newDataset.addColumn("nome_func");
      newDataset.addColumn("cpf");
      newDataset.addColumn("cod_ccusto");
      newDataset.addColumn("desc_cc");
      newDataset.addColumn("cod_cargo");
      newDataset.addColumn("desc_cargo");
      newDataset.addColumn("dat_nascimento");
      newDataset.addColumn("port_nece_esp");
      newDataset.addColumn("estab_cipa");
      newDataset.addColumn("dt_fim_estab_cipa");
      newDataset.addColumn("estab_sindic");
      newDataset.addColumn("dt_fim_estab_sindic");
      newDataset.addColumn("estab_acidente");
      newDataset.addColumn("dt_fim_estab_acidente");
      newDataset.addColumn("estab_doenca");
      newDataset.addColumn("dt_fim_estab_doenca");
      newDataset.addColumn("dt_ultima_aso");
      newDataset.addColumn("dat_admis_func");
      newDataset.addColumn("dat_desligto_func");
      newDataset.addColumn("num_ambien_risco");
      newDataset.addColumn("nom_ambien_risco");
      newDataset.addColumn("idi_tip_func");
      newDataset.addColumn("desc_tipo_funcionario");
      newDataset.addColumn("qti_dias_contrat_trab");
      newDataset.addColumn("qti_dias_suspensao");
      newDataset.addColumn("dat_term_contrat_trab");
      newDataset.addColumn("qti_dias_prorrog_contrat_trab");
      newDataset.addColumn("qti_dias_prorrog_suspensao");
      newDataset.addColumn("dat_term_prorrog_contrat_trab");
      newDataset.addColumn("cod_id_estad_fisic");
      newDataset.addColumn("nom_abrev_pessoa_fisic");
      newDataset.addColumn("func_adm");


      var filtro  =  ""+fields[0];
      // var filtro = "32634612488643"

      try {
            var serviceProvider = ServiceManager.getService('TOTVS');
            var serviceLocator = serviceProvider.instantiate('com.totvs.framework.ws.execbo.service.WebServiceExecBO');
            var service = serviceLocator.getWebServiceExecBOPort();

            var token = service.userLogin("fluig");
            var json = montaJson(filtro);

            var resp = service.callProcedureWithToken(token, "dzp/dzwf001.p", "ws-busca-funcionario-cracha", json);
            
            var respObj = JSON.parse(resp);

            var callProcedureWithTokenResponse = JSON.parse(respObj[0].value);

            for (var i in callProcedureWithTokenResponse.records) {
                  newDataset.addRow([
                        callProcedureWithTokenResponse.records[i]["cdn-funcionario"],
                        callProcedureWithTokenResponse.records[i]["nome-func"],
                        callProcedureWithTokenResponse.records[i]["cpf"],
                        callProcedureWithTokenResponse.records[i]["cod-ccusto"],
                        callProcedureWithTokenResponse.records[i]["desc-cc"],
                        callProcedureWithTokenResponse.records[i]["cod-cargo"],
                        callProcedureWithTokenResponse.records[i]["desc-cargo"],
                        callProcedureWithTokenResponse.records[i]["dat-nascimento"],
                        callProcedureWithTokenResponse.records[i]["port-nece-esp"],
                        callProcedureWithTokenResponse.records[i]["estab-cipa"],
                        callProcedureWithTokenResponse.records[i]["dt-fim-estab-cipa"],
                        callProcedureWithTokenResponse.records[i]["estab-sindic"],
                        callProcedureWithTokenResponse.records[i]["dt-fim-estab-sindic"],
                        callProcedureWithTokenResponse.records[i]["estab-acidente"],
                        callProcedureWithTokenResponse.records[i]["dt-fim-estab-acidente"],
                        callProcedureWithTokenResponse.records[i]["estab-doenca"],
                        callProcedureWithTokenResponse.records[i]["dt-fim-estab-doenca"],
                        callProcedureWithTokenResponse.records[i]["dt-ultima-aso"],
                        callProcedureWithTokenResponse.records[i]["dat-admis-func"],
                        callProcedureWithTokenResponse.records[i]["dat-desligto-func"],
                        callProcedureWithTokenResponse.records[i]["num-ambien-risco"],
                        callProcedureWithTokenResponse.records[i]["nom-ambien-risco"],
                        callProcedureWithTokenResponse.records[i]["idi-tip-func"],
                        callProcedureWithTokenResponse.records[i]["desc-tipo-funcionario"],
                        callProcedureWithTokenResponse.records[i]["qti-dias-contrat-trab"],
                        callProcedureWithTokenResponse.records[i]["qti-dias-suspensao"],
                        callProcedureWithTokenResponse.records[i]["dat-term-contrat-trab"],
                        callProcedureWithTokenResponse.records[i]["qti-dias-prorrog-contrat-trab"],
                        callProcedureWithTokenResponse.records[i]["qti-dias-prorrog-suspensao"],
                        callProcedureWithTokenResponse.records[i]["dat-term-prorrog-contrat-trab"],
                        callProcedureWithTokenResponse.records[i]["cod-id-estad-fisic"],
                        callProcedureWithTokenResponse.records[i]["nom-abrev-pessoa-fisic"],
                        callProcedureWithTokenResponse.records[i]["func-adm"]

                  ]
                  );
            }
      } catch (e) {
            log.info("ERRO: " + e);
      }

      return newDataset;
}

function montaJson(filtro) {
      log.info("montaJson");

      var cdn_funcionario = {}
      cdn_funcionario.type = "integer";
      cdn_funcionario.name = "cdn-funcionario";
      cdn_funcionario.label = "cdn_funcionario";

      var nome_func = {}
      nome_func.type = "character";
      nome_func.name = "nome-func";
      nome_func.label = "nome_func";

      var cpf = {}
      cpf.type = "character";
      cpf.name = "cpf";
      cpf.label = "cpf";

      var cod_ccusto = {}
      cod_ccusto.type = "character";
      cod_ccusto.name = "cod-ccusto";
      cod_ccusto.label = "cod_ccusto";

      var desc_cc = {}
      desc_cc.type = "character";
      desc_cc.name = "desc-cc";
      desc_cc.label = "desc_cc";

      var cod_cargo = {}
      cod_cargo.type = "integer";
      cod_cargo.name = "cod-cargo";
      cod_cargo.label = "cod_cargo";

      var desc_cargo = {}
      desc_cargo.type = "character";
      desc_cargo.name = "desc-cargo";
      desc_cargo.label = "desc_cargo";

      var dat_nascimento = {}
      dat_nascimento.type = "date";
      dat_nascimento.name = "dat-nascimento";
      dat_nascimento.label = "dat_nascimento";

      var port_nece_esp = {}
      port_nece_esp.type = "logical";
      port_nece_esp.name = "port-nece-esp";
      port_nece_esp.label = "port_nece_esp";

      var estab_cipa = {}
      estab_cipa.type = "logical";
      estab_cipa.name = "estab-cipa";
      estab_cipa.label = "estab_cipa";

      var dt_fim_estab_cipa = {}
      dt_fim_estab_cipa.type = "date";
      dt_fim_estab_cipa.name = "dt-fim-estab-cipa";
      dt_fim_estab_cipa.label = "dt_fim_estab_cipa";

      var estab_sindic = {}
      estab_sindic.type = "logical";
      estab_sindic.name = "estab-sindic";
      estab_sindic.label = "estab_sindic";

      var dt_fim_estab_sindic = {}
      dt_fim_estab_sindic.type = "date";
      dt_fim_estab_sindic.name = "dt-fim-estab-sindic";
      dt_fim_estab_sindic.label = "dt_fim_estab_sindic";

      var estab_acidente = {}
      estab_acidente.type = "logical";
      estab_acidente.name = "estab-acidente";
      estab_acidente.label = "estab_acidente";

      var dt_fim_estab_acidente = {}
      dt_fim_estab_acidente.type = "date";
      dt_fim_estab_acidente.name = "dt-fim-estab-acidente";
      dt_fim_estab_acidente.label = "dt_fim_estab_acidente";

      var estab_doenca = {}
      estab_doenca.type = "logical";
      estab_doenca.name = "estab-doenca";
      estab_doenca.label = "estab_doenca";

      var dt_fim_estab_doenca = {}
      dt_fim_estab_doenca.type = "date";
      dt_fim_estab_doenca.name = "dt-fim-estab-doenca";
      dt_fim_estab_doenca.label = "dt_fim_estab_doenca";

      var dt_ultima_aso = {}
      dt_ultima_aso.type = "date";
      dt_ultima_aso.name = "dt-ultima-aso";
      dt_ultima_aso.label = "dt_ultima_aso";

      var dat_admis_func = {}
      dat_admis_func.type = "date";
      dat_admis_func.name = "dat-admis-func";
      dat_admis_func.label = "dat_admis_func";

      var dat_desligto_func = {}
      dat_desligto_func.type = "date";
      dat_desligto_func.name = "dat-desligto-func";
      dat_desligto_func.label = "dat_desligto_func";

      var num_ambien_risco = {}
      num_ambien_risco.type = "integer";
      num_ambien_risco.name = "num-ambien-risco";
      num_ambien_risco.label = "num_ambien_risco";

      var nom_ambien_risco = {}
      nom_ambien_risco.type = "character";
      nom_ambien_risco.name = "nom-ambien-risco";
      nom_ambien_risco.label = "nom_ambien_risco";

      var idi_tip_func = {}
      idi_tip_func.type = "integer";
      idi_tip_func.name = "idi-tip-func";
      idi_tip_func.label = "idi_tip_func";

      var desc_tipo_funcionario = {}
      desc_tipo_funcionario.type = "character";
      desc_tipo_funcionario.name = "desc-tipo-funcionario";
      desc_tipo_funcionario.label = "desc_tipo_funcionario";

      var qti_dias_contrat_trab = {}
      qti_dias_contrat_trab.type = "integer";
      qti_dias_contrat_trab.name = "qti-dias-contrat-trab";
      qti_dias_contrat_trab.label = "qti_dias_contrat_trab";

      var qti_dias_suspensao = {}
      qti_dias_suspensao.type = "integer";
      qti_dias_suspensao.name = "qti-dias-suspensao";
      qti_dias_suspensao.label = "qti_dias_suspensao";

      var dat_term_contrat_trab = {}
      dat_term_contrat_trab.type = "date";
      dat_term_contrat_trab.name = "dat-term-contrat-trab";
      dat_term_contrat_trab.label = "dat_term_contrat_trab";

      var qti_dias_prorrog_contrat_trab = {}
      qti_dias_prorrog_contrat_trab.type = "integer";
      qti_dias_prorrog_contrat_trab.name = "qti-dias-prorrog-contrat-trab";
      qti_dias_prorrog_contrat_trab.label = "qti_dias_prorrog_contrat_trab";

      var qti_dias_prorrog_suspensao = {}
      qti_dias_prorrog_suspensao.type = "integer";
      qti_dias_prorrog_suspensao.name = "qti-dias-prorrog-suspensao";
      qti_dias_prorrog_suspensao.label = "qti_dias_prorrog_suspensao";

      var dat_term_prorrog_contrat_trab = {}
      dat_term_prorrog_contrat_trab.type = "date";
      dat_term_prorrog_contrat_trab.name = "dat-term-prorrog-contrat-trab";
      dat_term_prorrog_contrat_trab.label = "dat_term_prorrog_contrat_trab";

      var cod_id_estad_fisic = {}
      cod_id_estad_fisic.type = "character";
      cod_id_estad_fisic.name = "cod-id-estad-fisic";
      cod_id_estad_fisic.label = "cod_id_estad_fisic";

      var nom_abrev_pessoa_fisic = {}
      nom_abrev_pessoa_fisic.type = "character";
      nom_abrev_pessoa_fisic.name = "nom-abrev-pessoa-fisic";
      nom_abrev_pessoa_fisic.label = "nom_abrev_pessoa_fisic";

      var func_adm = {}
      func_adm.type = "logical";
      func_adm.name = "func-adm";
      func_adm.label = "func_adm";



      var tTable = {};
      tTable.name = 'tt-funcionario';
      tTable.records = [];
      tTable.fields = [cdn_funcionario, nome_func, cpf, cod_ccusto, desc_cc, cod_cargo, desc_cargo, dat_nascimento, port_nece_esp, estab_cipa, dt_fim_estab_cipa, estab_sindic, dt_fim_estab_sindic, estab_acidente, dt_fim_estab_acidente, estab_doenca, dt_fim_estab_doenca, dt_ultima_aso, dat_admis_func, dat_desligto_func, num_ambien_risco, nom_ambien_risco, idi_tip_func, desc_tipo_funcionario, qti_dias_contrat_trab, qti_dias_suspensao, dat_term_contrat_trab, qti_dias_prorrog_contrat_trab, qti_dias_prorrog_suspensao, dat_term_prorrog_contrat_trab, cod_id_estad_fisic, nom_abrev_pessoa_fisic, func_adm];


      var input = {};
      input.dataType = "character";
      input.name = "p-cracha";
      input.label = "p-cracha";
      input.type = "input";
      input.value = filtro;


      var output = {};
      output.dataType = "temptable";
      output.name = "tt-funcionario";
      output.type = "output";
      output.value = tTable;


      var params = [input, output];

      log.info(JSON.stringify(params));
      //conversor dos parametros de input para Json
      return JSON.stringify(params);
}
