function createDataset(fields, constraints, sortFields){
	var newDataset = DatasetBuilder.newDataset();
	newDataset.addColumn("Cargo");
	newDataset.addColumn("Código Grp Conhecto");
	newDataset.addColumn("Nome Grp Conhecto");
	newDataset.addColumn("Código Conhecto");
	newDataset.addColumn("Nome Conhecto");
	newDataset.addColumn("nivCargo");

	var filtroInt = parseInt(""+fields[1]);

	try {
		// Utiliza o ServiceManager para obter uma referencia ao servico.
		var serviceProvider = ServiceManager.getService('TOTVS');
		var serviceLocator  = serviceProvider.instantiate('com.totvs.framework.ws.execbo.service.WebServiceExecBO');
		var service         = serviceLocator.getWebServiceExecBOPort();

		// Faz login e recebe o token de autenticacao
		var token = service.userLogin("fluig");

		var json  = montaJson(filtroInt);

		// Chama a procedure passando os parametros e o token de autenticacao.
		var resp = service.callProcedureWithToken(token, "dzp/dzwf001.r", "ws-busca-conhecto", json);

		var respObj = JSON.parse(resp);

		var callProcedureWithTokenResponse = JSON.parse(respObj[0].value);
		
		for (var i in callProcedureWithTokenResponse.records){
	    	newDataset.addRow(new Array(
			callProcedureWithTokenResponse.records[i]["cod-cargo"], 
			callProcedureWithTokenResponse.records[i]["cod-grp-conhecto"], 
			callProcedureWithTokenResponse.records[i]["desc-grp-conhecto"], 
			callProcedureWithTokenResponse.records[i]["cod-conhecto"], 
			callProcedureWithTokenResponse.records[i]["desc-conhecto"],
			callProcedureWithTokenResponse.records[i]["idi_niv_requis_cargo"])
			);
	    	}
	} catch (e) {
		log.info("ERRO: "+e);
	}

	return newDataset;
}

function montaJson(filtroInt){
	log.info("montaJson");

	var codCargo 	= {};
	codCargo.type 	= "integer";
	codCargo.name 	= "cod-cargo";
	codCargo.label 	= "cargo";

	var codGrpConh 	= {};
	codGrpConh.type 	= "integer";
	codGrpConh.name 	= "cod-grp-conhecto";
	codGrpConh.label 	= "codGrpConhecto"; 

	var desGrpConh 	= {};
	desGrpConh.type 	= "character";
	desGrpConh.name 	= "desc-grp-conhecto";
	desGrpConh.label 	= "descGrpConhecto";
	
	var codConh 	= {};
	codConh.type 	= "integer";
	codConh.name 	= "cod-conhecto";
	codConh.label 	= "codConhecto";
	
	var desConh 	= {};
	desConh.type 	= "character";
	desConh.name 	= "desc-conhecto";
	desConh.label 	= "descConhecto";

	var nivCargo  	= {};
	nivCargo.type 	= "character";
	nivCargo.name 	= "idi_niv_requis_cargo";
	nivCargo.label 	= "idi_niv_requis_cargo";
	    
    //formador do paremetro value para temp-table
    var tTable		= {};
    tTable.name 		= "tt-cargo-conhecto";
    tTable.records 	= new Array();
    tTable.fields 	= [codCargo, codGrpConh, desGrpConh, codConh, desConh, nivCargo];
    
    //array para receber os parametros input da chamada da função
   
    var input 		= {};
	input.dataType	= "integer";
	input.name 		= "p-cod-cargo";
	input.label 	= "p-cod-cargo";
	input.type 		= "input";
	input.value 	= filtroInt;
    
	var output 		= {};
	output.dataType	= "temptable";
	output.name 	= "tt-cargo-conhecto";
	output.type 	= "output";
	output.value 	= tTable;
	
	var params = [input, output];
	
	log.info(JSON.stringify(params));
	//conversor dos parametros de input para Json
	return JSON.stringify(params);
}