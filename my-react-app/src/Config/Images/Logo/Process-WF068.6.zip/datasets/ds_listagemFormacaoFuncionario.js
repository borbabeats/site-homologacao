function createDataset(fields, constraints, sortFields) {
    var newDataset = DatasetBuilder.newDataset();
    newDataset.addColumn("funcionario");
    newDataset.addColumn("curso");
    newDataset.addColumn("DescriçãoCurso");
    newDataset.addColumn("TipoCurso");
    newDataset.addColumn("DescTipoCurso");
    newDataset.addColumn("LogiTipoCurso");
    newDataset.addColumn("NivelHierarquico");
    newDataset.addColumn("NivelFunc");
    newDataset.addColumn("FuncChefia");
    newDataset.addColumn("GrauInstrução");
    newDataset.addColumn("DescGrauInstrucao");
    newDataset.addColumn("GrauInstrucaoRaiz");
    newDataset.addColumn("GrauInstrucSped");
    newDataset.addColumn("GrauInstrucIntegr");
    newDataset.addColumn("desGrauInstrucIntegr");
    newDataset.addColumn("qtdHoraCursoTrein");
    newDataset.addColumn("desTitulacao");
    newDataset.addColumn("dataInicCursotrein");
    newDataset.addColumn("datFimCursoTrein");
    newDataset.addColumn("cdnInstitTrein");
    newDataset.addColumn("desInstitTrein");
    newDataset.addColumn("desTipInstitTrein");
    newDataset.addColumn("dataValidCursoTrein");
    newDataset.addColumn("dataEntregCertif");
    newDataset.addColumn("valMedNota");
    newDataset.addColumn("desSitTrein");
    newDataset.addColumn("desCaractGeral");

	var filtro  =   ""+fields[0];
// 	var filtro = "11903"
    filtro = parseInt(filtro)
     
    try {

            // Utiliza o ServiceManager para obter uma referencia ao servico.
		var serviceProvider = ServiceManager.getService('TOTVS');
		var serviceLocator  = serviceProvider.instantiate('com.totvs.framework.ws.execbo.service.WebServiceExecBO');
		var service         = serviceLocator.getWebServiceExecBOPort();

		// Faz login e recebe o token de autenticacao
		var token = service.userLogin("fluig");

		var json  = montaJson(filtro);

        var resp = service.callProcedureWithToken(token, "dzp/dzwf001.p", "ws-busca-funcionario-formacao", json);
        
        var respObj = JSON.parse(resp);

        var callProcedureWithTokenResponse = JSON.parse(respObj[0].value);
        for (var i in callProcedureWithTokenResponse.records) {
            newDataset.addRow([
                callProcedureWithTokenResponse.records[i]["cdn-funcionario"],
                callProcedureWithTokenResponse.records[i]["cdn-curso-trein"],
                callProcedureWithTokenResponse.records[i]["des-curso-trein"],
                callProcedureWithTokenResponse.records[i]["cdn-tip-curso-trein"],
                callProcedureWithTokenResponse.records[i]["des-tip-curso-trein"],
                callProcedureWithTokenResponse.records[i]["log-tip-curso-epm"],
                callProcedureWithTokenResponse.records[i]["cdn-niv-hier-funcnal"],
                callProcedureWithTokenResponse.records[i]["des-niv-hier-funcnal"],
                callProcedureWithTokenResponse.records[i]["funcao-chefia"],
                callProcedureWithTokenResponse.records[i]["cdn-grau-instruc"],
                callProcedureWithTokenResponse.records[i]["des-grau-instruc"],
                callProcedureWithTokenResponse.records[i]["cdn-grau-instruc-rais"],
                callProcedureWithTokenResponse.records[i]["cdn-grau-instruc-sped"],
                callProcedureWithTokenResponse.records[i]["cdn-grau-instruc-integr"],
                callProcedureWithTokenResponse.records[i]["des-grau-instruc-integr"],
                callProcedureWithTokenResponse.records[i]["qtd-hora-curso-trein"],
                callProcedureWithTokenResponse.records[i]["des-titulacao"],
                callProcedureWithTokenResponse.records[i]["dat-inic-curso-trein"],
                callProcedureWithTokenResponse.records[i]["dat-fim-curso-trein"],
                callProcedureWithTokenResponse.records[i]["cdn-instit-trein"],
                callProcedureWithTokenResponse.records[i]["des-instit-trein"],
                callProcedureWithTokenResponse.records[i]["des-tip-instit-trein"],
                callProcedureWithTokenResponse.records[i]["dat-valid-curso-trein"],
                callProcedureWithTokenResponse.records[i]["dat-entreg-certif"],
                callProcedureWithTokenResponse.records[i]["val-med-nota"],
                callProcedureWithTokenResponse.records[i]["des-sit-trein"],
                callProcedureWithTokenResponse.records[i]["des-caract-geral"],
            ]);
        }
    } catch (e) {
        log.info("ERRO: " + e);
        return e;
    }
    return newDataset;
}

function montaJson(filtro) {
    log.info("montaJson");
    
    var func = {};
    func.type = "integer";
    func.name = "cdn-funcionario";
    func.label = "func";
    
    var curso = {};
    curso.type = "integer";
    curso.name = "cdn-curso-trein";
    curso.label = "curso";
    
    var descCurso = {};
    descCurso.type = "character";
    descCurso.name = "des-curso-trein";
    descCurso.label = "descCurso";
    
    var tipocurso = {};
    tipocurso.type = "integer";
    tipocurso.name = "cdn-tip-curso-trein";
    tipocurso.label = "tipocurso";
    
    var desctipocurso = {};
    desctipocurso.type = "character";
    desctipocurso.name = "des-tip-curso-trein";
    desctipocurso.label = "desctipocurso";
    
    var logtipocurso = {};
    logtipocurso.type = "logical";
    logtipocurso.name = "log-tip-curso-epm";
    logtipocurso.label = "logtipocurso";
    
    var NivelHierarquico = {};
    NivelHierarquico.type = "integer";
    NivelHierarquico.name = "cdn-niv-hier-funcnal";
    NivelHierarquico.label = "NivelHierarquico";
    
    var NivelFunc = {};
    NivelFunc.type = "character";
    NivelFunc.name = "des-niv-hier-funcnal";
    NivelFunc.label = "NivelFunc";
    
    var FuncChefia = {};
    FuncChefia.type = "logical";
    FuncChefia.name = "funcao-chefia";
    FuncChefia.label = "FuncChefia";
    
    var GrauInstrucao = {};
    GrauInstrucao.type = "integer";
    GrauInstrucao.name = "cdn-grau-instruc";
    GrauInstrucao.label = "GrauInstrucao";
    
    var DescGrauInstrucao = {};
    DescGrauInstrucao.type = "character";
    DescGrauInstrucao.name = "des-grau-instruc";
    DescGrauInstrucao.label = "DescGrauInstrucao";
    
    var GrauInstrucaoRaiz = {};
    GrauInstrucaoRaiz.type = "integer";
    GrauInstrucaoRaiz.name = "cdn-grau-instruc-rais";
    GrauInstrucaoRaiz.label = "GrauInstrucaoRaiz";
    
    var GrauInstrucSped = {};
    GrauInstrucSped.type = "integer";
    GrauInstrucSped.name = "cdn-grau-instruc-sped";
    GrauInstrucSped.label = "GrauInstrucSped";
    
    var GrauInstrucIntegr = {};
    GrauInstrucIntegr.type = "integer";
    GrauInstrucIntegr.name = "cdn-grau-instruc-integr";
    GrauInstrucIntegr.label = "GrauInstrucIntegr";
    
    var desGrauInstrucIntegr = {};
    desGrauInstrucIntegr.type = "character";
    desGrauInstrucIntegr.name = "des-grau-instruc-integr";
    desGrauInstrucIntegr.label = "desGrauInstrucIntegr";
    
    var qtdHoraCursoTrein = {};
    qtdHoraCursoTrein.type = "decimal";
    qtdHoraCursoTrein.name = "qtd-hora-curso-trein";
    qtdHoraCursoTrein.label = "qtdHoraCursoTrein";
    
    var desTitulacao = {};
    desTitulacao.type = "character";
    desTitulacao.name = "des-titulacao";
    desTitulacao.label = "desTitulacao";
    
    var dataInicCursotrein = {};
    dataInicCursotrein.type = "date";
    dataInicCursotrein.name = "dat-inic-curso-trein";
    dataInicCursotrein.label = "dataInicCursotrein";
    
    var datFimCursoTrein = {};
    datFimCursoTrein.type = "date";
    datFimCursoTrein.name = "dat-fim-curso-trein";
    datFimCursoTrein.label = "datFimCursoTrein";
    
    var cdnInstitTrein = {};
    cdnInstitTrein.type = "integer";
    cdnInstitTrein.name = "cdn-instit-trein";
    cdnInstitTrein.label = "cdnInstitTrein";
    
    var desInstitTrein = {};
    desInstitTrein.type = "character";
    desInstitTrein.name = "des-instit-trein";
    desInstitTrein.label = "desInstitTrein";
    
    var desTipInstitTrein = {};
    desTipInstitTrein.type = "character";
    desTipInstitTrein.name = "des-tip-instit-trein";
    desTipInstitTrein.label = "desTipInstitTrein ";
    
    var dataValidCursoTrein = {};
    dataValidCursoTrein.type = "date";
    dataValidCursoTrein.name = "dat-valid-curso-trein";
    dataValidCursoTrein.label = "dataValidCursoTrein";
    
    var dataEntregCertif = {};
    dataEntregCertif.type = "date";
    dataEntregCertif.name = "dat-entreg-certif";
    dataEntregCertif.label = "dataEntregCertif";
    
    var valMedNota = {};
    valMedNota.type = "decimal";
    valMedNota.name = "val-med-nota";
    valMedNota.label = "valMedNota";

    var desSitTrein = {};
    desSitTrein.type = "character";
    desSitTrein.name = "des-sit-trein";
    desSitTrein.label = "desSitTrein";

    var desCaractGeral = {};
    desCaractGeral.type = "character";
    desCaractGeral.name = "des-caract-geral";
    desCaractGeral.label = "desCaractGeral";
    
    var tTable = {};
    tTable.name = "tt-funcionario-formacao";
    tTable.records = new Array();
    tTable.fields = [ func, curso, descCurso, tipocurso, desctipocurso, logtipocurso, NivelHierarquico, NivelFunc, FuncChefia, GrauInstrucao, DescGrauInstrucao, GrauInstrucaoRaiz, GrauInstrucSped, GrauInstrucIntegr, desGrauInstrucIntegr, qtdHoraCursoTrein, desTitulacao, dataInicCursotrein, datFimCursoTrein, cdnInstitTrein, desInstitTrein, desTipInstitTrein, dataValidCursoTrein, dataEntregCertif, valMedNota, desSitTrein, desCaractGeral];
    
    var input 		 = {};
    input.dataType   = "integer";
    input.name  	 = "p-cdn-funcionario";//procedure input
    input.label 	 = "p-cdn-funcionario";
    input.type 	  	 = "input";
    input.value 	 = filtro;

    var output = {};
    output.dataType = "temptable";
    output.name = "tt-funcionario-formacao";
    output.type = "output";
    output.value = tTable;
    var params = [input, output];

    log.info(JSON.stringify(params));
    return JSON.stringify(params);
}