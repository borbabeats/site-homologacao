function createDataset(fields, constraints, sortFields) {
    var newDataset = DatasetBuilder.newDataset();
    
    var matricula = ''+fields[0]
    
    var dataSource = "/jdbc/AppDS";
    var ic = new javax.naming.InitialContext();
    var ds = ic.lookup(dataSource);
    var created = false;

    var myQuery = "Select distinct(IF(zoom_matricula is not null , zoom_matricula, txt_matricula)) as matricula, count(zoom_matricula or txt_matricula) as count from ml001015 where main_etapa = 'Cadastro Atualizado' and main_status != 'Cadastro Cancelado'  and (zoom_matricula = "+matricula+" or txt_matricula = "+matricula+");";

    try {
        var conn = ds.getConnection();
        var stmt = conn.createStatement();
        var rs = stmt.executeQuery(myQuery);
        var columnCount = rs.getMetaData().getColumnCount();
        while (rs.next()) {
            if (!created) {
                for (var i = 1; i <= columnCount; i++) {
                    newDataset.addColumn(rs.getMetaData().getColumnName(i));
                }
                created = true;
            }
            var Arr = new Array();
            for (var i = 1; i <= columnCount; i++) {
                var obj = rs.getObject(rs.getMetaData().getColumnName(i));
                if (null != obj) {
                    Arr[i - 1] = rs.getObject(rs.getMetaData().getColumnName(i)).toString();
                } else {
                    Arr[i - 1] = "null";
                }
            }
            newDataset.addRow(Arr);
        }
    } catch (e) {
        log.error("ERRO==============> " + e.message);
    } finally {
        if (stmt != null) {
            stmt.close();
        }
        if (conn != null) {
            conn.close();
        }
    }
    
    return newDataset;
}