function createDataset(fields, constraints, sortFields) {
var dataset = DatasetBuilder.newDataset();

    dataset.addColumn("role");
    dataset.addColumn("colleague");
    dataset.addColumn("name");

    //papel fixo para teste
    var roleId = "WF010_Aprovadores";

    //Você deveria receber a empresa e o papel via constraint
    var companyRoleFilter = DatasetFactory.createConstraint("workflowColleagueRolePK.companyId"
            , getValue("WKCompany"), getValue("WKCompany"), ConstraintType.MUST);
    var roleFilter = DatasetFactory.createConstraint("workflowColleagueRolePK.roleId"
            , "WF010_Aprovadores", "WF010_Aprovadores", ConstraintType.MUST);
    var constraintsRole = new Array(companyRoleFilter, roleFilter);

    //Chama dataset PAPELxUSUARIO filtrando por empresa e papel
    var colleaguesByRole = DatasetFactory.getDataset("workflowColleagueRole", [], constraintsRole, []);

    for (var i = 0; i < colleaguesByRole.rowsCount; i++) {
        //Filtros usuario
        var companyUserFilter = DatasetFactory.createConstraint("colleaguePK.companyId"
                , getValue("WKCompany"), getValue("WKCompany"), ConstraintType.MUST);
        var userFilter = DatasetFactory.createConstraint("colleaguePK.colleagueId"
                , colleaguesByRole.getValue(i, "workflowColleagueRolePK.colleagueId")
                , colleaguesByRole.getValue(i, "workflowColleagueRolePK.colleagueId"), ConstraintType.MUST);
        var constraintsUser = new Array(companyUserFilter, userFilter);
        //Consulta usuários
        var colleagues = DatasetFactory.getDataset("colleague", [], constraintsUser, []);

        log.info("colleague = " + colleaguesByRole.getValue(i, "workflowColleagueRolePK.colleagueId"));
        log.info("constraints = " + constraintsUser);
        log.info("colleagues = " + colleagues.rowsCount);
        dataset.addRow(new Array(
                colleaguesByRole.getValue(i,"workflowColleagueRolePK.roleId"),
                colleaguesByRole.getValue(i, "workflowColleagueRolePK.colleagueId"), 
                colleagues.getValue(0, "colleagueName")));
    }
    return dataset;
}