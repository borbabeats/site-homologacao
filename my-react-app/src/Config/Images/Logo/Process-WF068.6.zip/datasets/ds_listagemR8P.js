function createDataset(fields, constraints, sortFields){
	log.info("começou teste filtro")
	var newDataset = DatasetBuilder.newDataset();
	newDataset.addColumn("Relatorio");
	newDataset.addColumn("Categoria");
	newDataset.addColumn("CategoriaDesc");
	newDataset.addColumn("ItemCodigo");
	newDataset.addColumn("ItemDescricao");
	newDataset.addColumn("NumOrderm");

	var filtro = '';

		if (constraints[0].initialValue != null && constraints[0].initialValue != 300) 
			filtro = "" + constraints[0].initialValue;
		else
			filtro = "" + constraints[1].initialValue;
	//var filtro  =   "1";

	try {
		// Utiliza o ServiceManager para obter uma referencia ao servico.
		var serviceProvider = ServiceManager.getService('TOTVS');
		var serviceLocator  = serviceProvider.instantiate('com.totvs.framework.ws.execbo.service.WebServiceExecBO');
		var service         = serviceLocator.getWebServiceExecBOPort();

		// Faz login e recebe o token de autenticacao
		var token = service.userLogin("fluig");

		var json  = montaJson(filtro);

		// Chama a procedure passando os parametros e o token de autenticacao.
		var resp = service.callProcedureWithToken(token, "dzp/dzwf001.p", "ws-busca-rop-relatorio", json);
																		
		var respObj = JSON.parse(resp);

		var callProcedureWithTokenResponse = JSON.parse(respObj[0].value);
		
		for (var i in callProcedureWithTokenResponse.records){
	    	newDataset.addRow(new Array(
			callProcedureWithTokenResponse.records[i]["nr-relatorio"], 
			callProcedureWithTokenResponse.records[i]["ind-categoria"], 
			callProcedureWithTokenResponse.records[i]["ind-categoria-des"], 
			callProcedureWithTokenResponse.records[i]["it-codigo"], 
			callProcedureWithTokenResponse.records[i]["desc-item"],
			callProcedureWithTokenResponse.records[i]["num-ordem"])
			);
	    }
	} catch (e) {
		log.info("ERRO: "+e);
	}

	return newDataset;
}

function montaJson(filtro){
	log.info("montaJson");

	var relatorio 	= new Object();
	relatorio.type 	= "integer";
	relatorio.name 	= "nr-relatorio";
	relatorio.label = "relatorio";

	var categoria 	= new Object();
	categoria.type 	= "integer";
	categoria.name 	= "ind-categoria"; 
	categoria.label = "categoria"; 

	var categoriaDesc 	= new Object();
	categoriaDesc.type 	= "character";
	categoriaDesc.name 	= "ind-categoria-des";  
	categoriaDesc.label = "categoriaDesc";
	    
	var itemCodigo 		= new Object();
	itemCodigo.type 	= "character";
	itemCodigo.name 	= "it-codigo";  
	itemCodigo.label 	= "itemCodigo";
	    
	var itemDesc 		= new Object();
	itemDesc.type 		= "character";
	itemDesc.name 		= "desc-item";  
	itemDesc.label 		= "itemDesc";
	    
	var numOrdem 		= new Object();
	numOrdem.type 		= "character";
	numOrdem.name 		= "num-ordem";  
	numOrdem.label 		= "numOrdem";
	
    //formador do paremetro value para temp-table
    var tTable 		= new Object();
    tTable.name 	= "tt-rop-relatorio";
    tTable.records 	= new Array();
    tTable.fields 	= [relatorio, categoria, categoriaDesc, itemCodigo, itemDesc, numOrdem];
    
    //array para receber os parametros input da chamada da função
   
    var input 		= new Object();
    input.dataType	= "integer";
    input.name 		= "p-nr-relatorio";
    input.label 	= "p-nr-relatorio";
    input.type 		= "input";
    input.value 	= filtro;
    
	var output 		= new Object();
	output.dataType	= "temptable";
	output.name 	= "tt-rop-relatorio";
	output.type 	= "output";
	output.value 	= tTable;
	
	var params = [input, output];
	
	log.info(JSON.stringify(params));
	//conversor dos parametros de input para Json
	return JSON.stringify(params);
}