function createDataset(fields, constraints, sortFields) {

    // Cria as colunas
    var newDataset = DatasetBuilder.newDataset();
    newDataset.addColumn("Sala");
    var array = [];
    var auxArray;
    var filtro = constraints[1];

    array.push(['Sala 1 - Tecnologia da Informação']);
    array.push(['Sala 2 - Recursos Humanos']);
    array.push(['Sala 3 - Jurídico']);
    array.push(['Sala 4 - Compras/Financeiro/Controladoria']);
    array.push(['Sala 5 - Ambulatório']);
    array.push(['Sala 6 - Segurança do Trabalho']);
    array.push(['Sala 7 - Fiscal']);
    array.push(['Sala 8 - Vendas']);
    array.push(['Sala 9 - Engenharia de Produto/Gestão da Qualidade/Assistência Técnica']);
    array.push(['Sala 10 - Usinagem 1, PCP e Logística']);
    array.push(['Sala 11 - Cromo (Contâiner)']);
    array.push(['Sala 12 - Manutenção Forjaria']);
    array.push(['Sala 13 - Forjaria Ind.']);
    array.push(['Sala 14 - P&D']);
    array.push(['Sala 15 - Metrologia']);
    array.push(['Sala 16 - Laboratório Químico']);
    array.push(['Sala 17 - Usinagem 2']);
    array.push(['Sala 18 - Preset Usinagem']);
    array.push(['Sala 19 - Laboratório Metalúrgico']);
    array.push(['Sala 20 - Laboratório Testes Mecânicos']);
    array.push(['Sala 21 - Almoxarifado']);
    array.push(['Sala 22 - Engenharia Civil']);
    array.push(['Sala 23 - Manutenção Usinagem']);
    array.push(['Sala 24 - Cobre']);
    array.push(['Sala 25 - Níquel']);
    array.push(['Sala 26 - Vanádio']);
    array.push(['Sala 27 - Carbono']);
    array.push(['Sala 28 - Boro']);
    array.push(['Sala 29 - Tungstênio']);
    array.push(['Sala 30 - Titânio']);
    array.push(['Sala 31 - Alumínio']);
    array.push(['Sala 32 - Nitrogênio']);
    array.push(['Sala 33 - Nióbio']);
    array.push(['Sala 34 - Molibdênio']);
    array.push(['Sala 35 - Manganês']);
    array.push(['Sala 36 - Bismuto']);
    array.push(['Sala 37 - Refeitório']);

    if(filtro != undefined && filtro != null){
        filtro = filtro.initialValue;
        for(var i = 0; i < array.length; i++){
            auxArray    =   array[i];
            for(var j = 0; j < auxArray.length; j++){
                if(auxArray[j].toLowerCase().indexOf(filtro.toString().toLowerCase()) != -1){
                    newDataset.addRow(auxArray);
                    j = auxArray.length;
                }
            }
        }
    }else{
        for(var i = 0; i < array.length; i++){
            newDataset.addRow(array[i]);
        }
    }
   

    return newDataset;
}