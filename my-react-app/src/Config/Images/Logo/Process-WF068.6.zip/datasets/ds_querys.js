function createDataset(fields, constraints, sortFields) {
    try {
        var newDataset = DatasetBuilder.newDataset();
        var dataSource = "/jdbc/AppDS";
        var ic = new javax.naming.InitialContext();
        var ds = ic.lookup(dataSource);
        var conn = ds.getConnection();
        var stmt = conn.createStatement();
        var created = false;
        
        var rs = stmt.executeQuery(fields[0]);
        var columnCount = rs.getMetaData().getColumnCount();
        while (rs.next()) {
            if (!created) {
                for (var i = 1; i <= columnCount; i++) {
                    newDataset.addColumn(rs.getMetaData().getColumnName(i));
                }
                created = true;
            }
            var Arr = [];
            for (var j = 1; j <= columnCount; j++) {
                var obj = rs.getObject(rs.getMetaData().getColumnName(j));
                null !== obj ? Arr[j - 1] = rs.getObject(rs.getMetaData().getColumnName(j)).toString() : Arr[j - 1] = "null";
            }
            newDataset.addRow(Arr);
        }
    } catch (e) {
        log.error("ERRO==============> " + e.message);
    } finally {
        if (stmt !== null) stmt.close();
        if (conn !== null) conn.close();
    }
    return newDataset;
}