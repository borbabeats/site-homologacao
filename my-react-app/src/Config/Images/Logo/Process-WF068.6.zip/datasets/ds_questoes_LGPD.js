function createDataset(fields, constraints, sortFields) {
      var dataset_qst = DatasetBuilder.newDataset();
      dataset_qst.addColumn("agr_topic");
      dataset_qst.addColumn("agr_question");
      dataset_qst.addColumn("question");
      dataset_qst.addColumn("resp");

      var  array_ = [];

      array_.push(['1', 1, 'A LGPD foi criada com o objetivo de proporcionar ao cidadão brasileiro uma garantia para que os seus dados pessoais sejam tratados de forma confidencial', 1]);
      array_.push(['1', 2, 'Proteger os dados pessoais de pessoa jurídica', 0]);
      array_.push(['1', 3, 'Proteger os dados das empresas, clientes e fornecedores', 0]);

      array_.push(['2', 1, 'Não', 0]);
      array_.push(['2', 2, 'Sim. Todas as empresas que realizam tratamento de dados de pessoas físicas precisam atender a LGPD', 1]);
      array_.push(['2', 3, 'Talvez', 0]);

      array_.push(['3', 1, 'GDPR – Regulamentação Geral de Proteção de Dados', 0]);
      array_.push(['3', 2, 'LGPD – Lei Geral de Proteção de Dados', 0]);
      array_.push(['3', 3, 'ANPD – Agência Nacional de Proteção de Dados', 1]);

      array_.push(['4', 1, 'É a pessoa natural a quem pertencem os dados pessoais', 1]);
      array_.push(['4', 2, 'É o pessoa jurídica que realiza o tratamento dos dados pessoais', 0]);
      array_.push(['4', 3, 'É o profissional que realiza o tratamento dos dados pessoais', 0]);

      array_.push(['5', 1, 'São todas as informações relacionadas aos funcionários públicos', 0]);
      array_.push(['5', 2, 'É uma informação relacionada à pessoa jurídica, onde o indivíduo através dela possa ser identificado', 0]);
      array_.push(['5', 3, 'É uma informação relacionada à pessoa natural, onde o indivíduo através dela possa ser identificado', 1]);

      array_.push(['6', 1, 'É todo o dado que não se refere a pessoas físicas', 0]);
      array_.push(['6', 2, 'É qualquer dado pessoal, que através dele o indivíduo possa ser discriminado, por exemplo, dados de origem racial e convicção religiosa', 1]);
      array_.push(['6', 3, 'Referem-se aos dados profissionais do indivíduo', 0]);

      array_.push(['7', 1, 'Controlador, Encarregado de Proteção de Dados e Operador', 1]);
      array_.push(['7', 2, 'Europa, Rússia e China', 0]);
      array_.push(['7', 3, 'Brasil, Espanha e Canadá', 0]);

      array_.push(['8', 1, 'Planejamento, Implementação e Revisão', 0]);
      array_.push(['8', 2, 'Operação, Livre Acesso e Finalização', 0]);
      array_.push(['8', 3, 'Finalidade, Necessidade e Adequação', 1]);

      array_.push(['9', 1, 'Não. Somente as empresas podem acessar o conteúdo da legislação', 0]);
      array_.push(['9', 2, 'Sim a legislação é pública. Acessar a internet e pesquisar por LGPD ou Lei 13.709/18, ou também poderá acessar diretamente no site oficial do Planalto', 1]);
      array_.push(['9', 3, 'Não', 0]);

      array_.push(['10', 1, '1 ano', 0]);
      array_.push(['10', 2, '6 meses', 0]);
      array_.push(['10', 3, 'A lei já está em vigor, as empresas precisam se adequarem imediatamente', 1]);

      array_.push(['11', 1, 'Sim. A LGPD tem como objetivo proteger o titular dos dados (pessoa física), e como os dados em questão não são relacionados com dados pessoais, não há problema, visto que não faz parte do escopo da legislação', 0]);
      array_.push(['11', 2, 'Sim. Os gestores das empresas são protegidos pela LGPD pois são responsáveis pelos dados confidenciais, podendo utilizar toda informação da empresa conforme a necessidade', 0]);
      array_.push(['11', 3, 'Não. Toda e qualquer informação da empresa precisa ser tratada com confidencialidade, e mesmo que as características das informações não são relacionadas a pessoas físicas são caracterizadas como Segredo Industrial e devem ser preservadas', 1]);

      array_.push(['12', 1, 'Apagar todos os dados pessoais do programa, pois em hipótese nenhuma a empresa pode tratar dados pessoais de colaboradores. Após notificar sua gestão do ocorrido', 0]);
      array_.push(['12', 2, 'Nenhuma. Pois você jamais utilizará as informações do programa para prejudicar o titular dos dados', 0]);
      array_.push(['12', 3, 'Imediatamente acionar sua gestão ou o Encarregado de Proteção de Dados da sua empresa, solicitando a retirada do acesso', 1]);

      array_.push(['13', 1, 'Não compartilhar nenhum dado pessoal com empresas parceiras', 0]);
      array_.push(['13', 2, 'Notificar a ANPD para receber a orientação de como serão tratados os dados pessoais', 0]);
      array_.push(['13', 3, 'Obter o consentimento do titular dos dados pessoais para compartilhar as informações, deixando explícito a finalidade da transferência', 1]);

      array_.push(['14', 1, 'Em não solicitar dados relacionados à saúde do colaborador, pois estas informações são consideradas sensíveis e não podem ser tratadas pelas empresas', 0]);
      array_.push(['14', 2, 'A lei não prevê este tipo de situação', 0]);
      array_.push(['14', 3, 'A legislação considera este tipo de informação como sensível, e prevê a impossibilidade do tratamento destes dados para fins discriminatórios, ilícitos ou abusivos', 1]);

      array_.push(['15', 1, 'A lei não se aplica ao tratamento de dados pessoas físicas', 0]);
      array_.push(['15', 2, 'A lei não se aplica as empresas públicas, somente empresas privadas', 0]);
      array_.push(['15', 3, 'A lei não se aplica aos tratamentos de dados realizado por pessoas naturais, para finalidades exclusivamente particulares e não econômicas', 1]);

      array_.push(['16', 1, 'Pessoa indicada pelo controlador e titular do dado para atuar como canal de comunicação entre a empresa e a Autoridade Nacional de Proteção de Dados (ANPD) (art. 5º, VIII)', 1]);
      array_.push(['16', 2, 'Pessoa natural ou jurídica, de direito público ou privado que realiza tratamento, conforme instruções do controlador (art. 5º, VII)', 0]);
      array_.push(['16', 3, 'Pessoa natural ou jurídica, de direito público ou privado, a quem competem as decisões referentes ao tratamento de dados pessoais (art. 5º,VI)', 0]);

      array_.push(['17', 1, 'A organização precisa evidenciar a adoção de medidas eficazes e capazes de comprovar a observância e o cumprimento das normas de proteção de dados pessoais e, inclusive, da eficácia dessas medidas', 0]);
      array_.push(['17', 2, 'A utilização de medidas técnicas e administrativas são imprescindíveis para a proteção dos dados pessoais de acessos não autorizados e de situações acidentais ou ilícitas de destruição, perda, alteração, comunicação ou difusão', 0]);
      array_.push(['17', 3, 'Para fazer a coleta do dado é necessário ter uma finalidade legítima, recolher somente o que é necessário, e estar adequado ao que foi informado ao titular', 1]);

      array_.push(['18', 1, 'Multa simples, de até 2% (dois por cento) do faturamento da empresa, limitada, no total, a R$ 25.000.000,00 (vinte e cinco milhões de reais) pelo total de infrações anual', 0]);
      array_.push(['18', 2, 'Imediata interrupção no fornecimento de produtos e serviços da empresa que violou as regras da legislação', 0]);
      array_.push(['18', 3, 'Multa simples, de até 2% (dois por cento) do faturamento da pessoa jurídica de direito privado, grupo ou conglomerado no Brasil no seu último exercício, excluídos os tributos, limitada, no total, a R$ 50.000.000,00 (cinquenta milhões de reais) por infração', 1]);

      array_.push(['19', 1, 'Não nomear um Encarregado de Proteção de dados pessoais', 0]);
      array_.push(['19', 2, 'Compartilhar dados pessoais', 0]);
      array_.push(['19', 3, 'Tratar dados pessoais sem finalidade definida', 1]);

      array_.push(['20', 1, 'Sim. Desde que os usuários tenham uma finalidade legítima para utilização das informações', 0]);
      array_.push(['20', 2, 'Não. Pois mesmo que as informações disponibilizadas tenham uma finalidade legítima, segundo os princípios de Segurança e Prevenção, no contexto que foi apresentado, somente a pessoa interessada precisa ter acesso à informação', 1]);
      array_.push(['20', 3, 'Não. Pois nem todos os usuários que acessam a rede interna possuem contrato de confidencialidade', 0]);

      for (var i = 0; i < array_.length; i++) {
            dataset_qst.addRow(array_[i]);
      }

      return dataset_qst;
}