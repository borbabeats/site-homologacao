function createDataset(fields, constraints, sortFields) {
	var newDataset = DatasetBuilder.newDataset();
	var arrayColabs = new Array();
	
	newDataset.addColumn("ID_Fluig");
	newDataset.addColumn("Nome_Completo");

	var array   = new Array();
    var auxArray;
    var filtro  =   constraints[1];
	
	var c1          	= DatasetFactory.createConstraint("invi_idColabSubst", "", "", ConstraintType.MUST_NOT);
	var c2          	= DatasetFactory.createConstraint("metadata#active", true, true, ConstraintType.MUST);
	var c3          	= DatasetFactory.createConstraint("main_status", "Cancelado", "Cancelado", ConstraintType.MUST_NOT);
	var c4          	= DatasetFactory.createConstraint("versao", "1", "1", ConstraintType.MUST_NOT);
    var constraints 	= new Array(c1, c2, c3, c4);
    var a1          	= "invi_idColabSubst";
    var fields			= new Array(a1);
	var dataset 		= DatasetFactory.getDataset("ds_requisicaoDePessoal", fields, constraints, null);

	var c5          	= DatasetFactory.createConstraint("active", true, true, ConstraintType.MUST);
	var c6          	= DatasetFactory.createConstraint("colleaguePK.colleagueId", "admin", "admin", ConstraintType.MUST_NOT);
	var c7          	= DatasetFactory.createConstraint("colleaguePK.colleagueId", "wcmpublico", "wcmpublico", ConstraintType.MUST_NOT);
	var c8          	= DatasetFactory.createConstraint("colleaguePK.colleagueId", "consumerkeyteste", "consumerkeyteste", ConstraintType.MUST_NOT);
	var c9          	= DatasetFactory.createConstraint("colleaguePK.colleagueId", "administrador", "administrador", ConstraintType.MUST_NOT);
    var constraints2 	= new Array(c5, c6, c7, c8, c9);
    var a2          	= "colleagueName";
    var a3          	= "colleaguePK.colleagueId";
    var fields2			= new Array(a2, a3);
    var sortingFields 	= new Array("colleagueName");
	var colleague 		= DatasetFactory.getDataset("colleague", fields2, constraints2, sortingFields);	
	
	for(var i = 0; i < dataset.rowsCount; i++) {
		arrayColabs.push(dataset.getValue(i, "invi_idColabSubst"));
    }
	
	var inputValidate = "yes";
	for(var j = 0; j < colleague.rowsCount; j++) {
		for(var k = 0; k < arrayColabs.length; k++){
			if(colleague.getValue(j, "colleaguePK.colleagueId") == arrayColabs[k]){
				inputValidate = "no";
			}
		}
		if(inputValidate == "yes"){
			array.push(new Array(colleague.getValue(j, "colleaguePK.colleagueId"), colleague.getValue(j, "colleagueName")));
		}
        inputValidate = "yes";
    }

    if(filtro != undefined && filtro != null){
        filtro = filtro.initialValue;
        for(var i = 0; i < array.length; i++){
            auxArray    =   array[i];
            for(var j = 0; j < auxArray.length; j++){
                if(auxArray[j].toLowerCase().indexOf(filtro.toString().toLowerCase()) != -1){
                    newDataset.addRow(auxArray);
                    j = auxArray.length;
                }
            }
        }
    }else{
        for(var i = 0; i < array.length; i++){
            newDataset.addRow(array[i]);
        }
    }
	
	return newDataset;
}