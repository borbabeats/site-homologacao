function createDataset(fields, constraints, sortFields){
	var newDataset = DatasetBuilder.newDataset();
	newDataset.addColumn("Numero");
	newDataset.addColumn("Descricao");

	var filtro = '';

		if (constraints[0].initialValue != null && constraints[0].initialValue != 300) 
			filtro = "" + constraints[0].initialValue;
		else
			filtro = "" + constraints[1].initialValue;
	//var filtro  = "84"; // coloca uma num valido


	try {
		// Utiliza o ServiceManager para obter uma referencia ao servico.
		var serviceProvider = ServiceManager.getService('TOTVS');
		var serviceLocator  = serviceProvider.instantiate('com.totvs.framework.ws.execbo.service.WebServiceExecBO');
		var service         = serviceLocator.getWebServiceExecBOPort();

		// Faz login e recebe o token de autenticacao
		var token = service.userLogin("fluig");

		var json  = montaJson(filtro);

		// Chama a procedure passando os parametros e o token de autenticacao.
		var resp = service.callProcedureWithToken(token, "dzp/dzwf001.p", "ws-busca-ncm", json);

		var respObj = JSON.parse(resp);

		var callProcedureWithTokenResponse = JSON.parse(respObj[0].value);

		for (var i in callProcedureWithTokenResponse.records){
	    	newDataset.addRow(new Array(
			callProcedureWithTokenResponse.records[i]["class-fiscal"],
			callProcedureWithTokenResponse.records[i]["descricao"])
			);
	    }
	} catch (e) {
		log.info("### ERRO: "+e);
	}

	return newDataset;
}

function montaJson(filtro){
	log.info("montaJson");

	var Ncm  		= new Object();
	Ncm.type 		= "character";
	Ncm.name		= "class-fiscal";
	Ncm.label		= "Ncm";

	var Descricao 	= new Object();
	Descricao.type 	= "character";
	Descricao.name  = "descricao";
	Descricao.label	= "Descricao";

    //formador do parametro value para temp-table
	var tTable		= new Object();
    tTable.name     = "tt-cassif-fisc";
    tTable.records  = new Array();
    tTable.fields	= [Ncm, Descricao];

    //array para receber os parametros input da chamada da função

    var input 		 = new Object();
    input.dataType   = "character";
    input.name  	 = "p-class-fiscal";//procedure input
    input.label 	 = "Numero";
    input.type 	  	 = "input";
    input.value 	 = filtro;

	var output 	  	= new Object();
	output.dataType	= "temptable";
	output.name   	= "tt-cassif-fisc";//nome da temp-table
	output.type   	= "output";
	output.value  	= tTable;

	var params = [input, output];

	log.info(JSON.stringify(params));
	//conversor dos parametros de input para Json
	return JSON.stringify(params);
}