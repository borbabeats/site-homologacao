function createDataset(fields, constraints, sortFields) {
        var newDataset = DatasetBuilder.newDataset();

        newDataset.addColumn("cdn_curso_trein");
        newDataset.addColumn("des_curso_trein");
        newDataset.addColumn("nom_vers_trein");
        newDataset.addColumn("cdn_tip_curso_trein");
        newDataset.addColumn("des_tip_curso_trein");
        newDataset.addColumn("cdn_niv_hier_funcnal");
        newDataset.addColumn("des_niv_hier_funcnal");
        newDataset.addColumn("cdn_grau_instruc");
        newDataset.addColumn("des_grau_instruc");
        newDataset.addColumn("qtd_hora_curso_trein");
        newDataset.addColumn("des_titulacao");
        newDataset.addColumn("qtd_min_treindo_turma");


        var filtro = '';

        if (constraints[0].initialValue != null && constraints[0].initialValue != 300)
                filtro = "" + constraints[0].initialValue;
        else
                filtro = "" + constraints[1].initialValue;

        try {
                var serviceProvider = ServiceManager.getService('TOTVS');
                var serviceLocator = serviceProvider.instantiate('com.totvs.framework.ws.execbo.service.WebServiceExecBO');
                var service = serviceLocator.getWebServiceExecBOPort();

                var token = service.userLogin("fluig");
                var json = montaJson(filtro);

                var resp = service.callProcedureWithToken(token, "dzp/dzwf001.p", "ws-busca-curso-trein", json);

                var respObj = JSON.parse(resp);

                var callProcedureWithTokenResponse = JSON.parse(respObj[0].value);

                for (var i in callProcedureWithTokenResponse.records) {
                        newDataset.addRow([
                                callProcedureWithTokenResponse.records[i]["cdn-curso-trein"],
                                callProcedureWithTokenResponse.records[i]["des-curso-trein"],
                                callProcedureWithTokenResponse.records[i]["nom-vers-trein"],
                                callProcedureWithTokenResponse.records[i]["cdn-tip-curso-trein"],
                                callProcedureWithTokenResponse.records[i]["des-tip-curso-trein"],
                                callProcedureWithTokenResponse.records[i]["cdn-niv-hier-funcnal"],
                                callProcedureWithTokenResponse.records[i]["des-niv-hier-funcnal"],
                                callProcedureWithTokenResponse.records[i]["cdn-grau-instruc"],
                                callProcedureWithTokenResponse.records[i]["des-grau-instruc"],
                                callProcedureWithTokenResponse.records[i]["qtd-hora-curso-trein"],
                                callProcedureWithTokenResponse.records[i]["des-titulacao"],
                                callProcedureWithTokenResponse.records[i]["qtd-min-treindo-turma"]
                        ]
                        );
                }
        } catch (e) {
                log.info("ERRO: " + e);
        }

        return newDataset;
}

function montaJson(filtro) {
        log.info("montaJson");

        var cdn_curso_trein = {}
        cdn_curso_trein.type = "integer";
        cdn_curso_trein.name = "cdn-curso-trein";
        cdn_curso_trein.label = "cdn_curso_trein";

        var des_curso_trein = {}
        des_curso_trein.type = "character";
        des_curso_trein.name = "des-curso-trein";
        des_curso_trein.label = "des_curso_trein";

        var nom_vers_trein = {}
        nom_vers_trein.type = "character";
        nom_vers_trein.name = "nom-vers-trein";
        nom_vers_trein.label = "nom_vers_trein";

        var cdn_tip_curso_trein = {}
        cdn_tip_curso_trein.type = "integer";
        cdn_tip_curso_trein.name = "cdn-tip-curso-trein";
        cdn_tip_curso_trein.label = "cdn_tip_curso_trein";

        var des_tip_curso_trein = {}
        des_tip_curso_trein.type = "character";
        des_tip_curso_trein.name = "des-tip-curso-trein";
        des_tip_curso_trein.label = "des_tip_curso_trein";

        var cdn_niv_hier_funcnal = {}
        cdn_niv_hier_funcnal.type = "integer";
        cdn_niv_hier_funcnal.name = "cdn-niv-hier-funcnal";
        cdn_niv_hier_funcnal.label = "cdn_niv_hier_funcnal";

        var des_niv_hier_funcnal = {}
        des_niv_hier_funcnal.type = "character";
        des_niv_hier_funcnal.name = "des-niv-hier-funcnal";
        des_niv_hier_funcnal.label = "des_niv_hier_funcnal";

        var cdn_grau_instruc = {}
        cdn_grau_instruc.type = "integer";
        cdn_grau_instruc.name = "cdn-grau-instruc";
        cdn_grau_instruc.label = "cdn_grau_instruc";

        var des_grau_instruc = {}
        des_grau_instruc.type = "character";
        des_grau_instruc.name = "des-grau-instruc";
        des_grau_instruc.label = "des_grau_instruc";

        var qtd_hora_curso_trein = {}
        qtd_hora_curso_trein.type = "integer";
        qtd_hora_curso_trein.name = "qtd-hora-curso-trein";
        qtd_hora_curso_trein.label = "qtd_hora_curso_trein";

        var des_titulacao = {}
        des_titulacao.type = "character";
        des_titulacao.name = "des-titulacao";
        des_titulacao.label = "des_titulacao";

        var qtd_min_treindo_turma = {}
        qtd_min_treindo_turma.type = "integer";
        qtd_min_treindo_turma.name = "qtd-min-treindo-turma";
        qtd_min_treindo_turma.label = "qtd_min_treindo_turma";


        var tTable = {};
        tTable.name = 'tt-curso-trein';
        tTable.records = [];
        tTable.fields = [cdn_curso_trein, des_curso_trein, nom_vers_trein, cdn_tip_curso_trein, des_tip_curso_trein, cdn_niv_hier_funcnal, des_niv_hier_funcnal, cdn_grau_instruc, des_grau_instruc, qtd_hora_curso_trein, des_titulacao, qtd_min_treindo_turma];

        var input = {};
        input.dataType = "character";
        input.name = "p-des-curso-trein";
        input.label = "p-des-curso-trein";
        input.type = "input";
        input.value = filtro;


        var output = {};
        output.dataType = "temptable";
        output.name = "tt-curso-trein";
        output.type = "output";
        output.value = tTable;


        var params = [input, output];

        log.info(JSON.stringify(params));
        //conversor dos parametros de input para Json
        return JSON.stringify(params);
}