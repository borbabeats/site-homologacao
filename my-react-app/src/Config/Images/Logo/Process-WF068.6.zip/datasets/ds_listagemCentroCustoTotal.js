function createDataset(fields, constraints, sortFields) {
      var newDataset = DatasetBuilder.newDataset();

      newDataset.addColumn("cod_ccusto");
      newDataset.addColumn("descricao");
      newDataset.addColumn("cod_usuar_gestor");
      newDataset.addColumn("nom_usuario_gestor");
      newDataset.addColumn("cod_usuar_diretor");
      newDataset.addColumn("nom_usuario_diretor");


      //var filtro  =  ""+constraints[0].initialValue;
      var filtro = ""

      try {
            var serviceProvider = ServiceManager.getService('TOTVS');
            var serviceLocator = serviceProvider.instantiate('com.totvs.framework.ws.execbo.service.WebServiceExecBO');
            var service = serviceLocator.getWebServiceExecBOPort();

            var token = service.userLogin("fluig");
            var json = montaJson(filtro);

            var resp = service.callProcedureWithToken(token, "dzp/dzwf001.p", "ws-busca-ccusto", json);
            
            var respObj = JSON.parse(resp);

            var callProcedureWithTokenResponse = JSON.parse(respObj[0].value);

            for (var i in callProcedureWithTokenResponse.records) {
                  newDataset.addRow([
                        callProcedureWithTokenResponse.records[i]["cod-ccusto"],
                        callProcedureWithTokenResponse.records[i]["descricao"],
                        callProcedureWithTokenResponse.records[i]["cod-usuar-gestor"],
                        callProcedureWithTokenResponse.records[i]["nom-usuario-gestor"],
                        callProcedureWithTokenResponse.records[i]["cod-usuar-diretor"],
                        callProcedureWithTokenResponse.records[i]["nom-usuario-diretor"]

                  ]
                  );
            }
      } catch (e) {
            log.info("ERRO: " + e);
      }

      return newDataset;
}

function montaJson(filtro) {
      log.info("montaJson");

      var cod_ccusto = {}
      cod_ccusto.type = "character";
      cod_ccusto.name = "cod-ccusto";
      cod_ccusto.label = "cod_ccusto";

      var descricao = {}
      descricao.type = "character";
      descricao.name = "descricao";
      descricao.label = "descricao";

      var cod_usuar_gestor = {}
      cod_usuar_gestor.type = "character";
      cod_usuar_gestor.name = "cod-usuar-gestor";
      cod_usuar_gestor.label = "cod_usuar_gestor";

      var nom_usuario_gestor = {}
      nom_usuario_gestor.type = "character";
      nom_usuario_gestor.name = "nom-usuario-gestor";
      nom_usuario_gestor.label = "nom_usuario_gestor";

      var cod_usuar_diretor = {}
      cod_usuar_diretor.type = "character";
      cod_usuar_diretor.name = "cod-usuar-diretor";
      cod_usuar_diretor.label = "cod_usuar_diretor";

      var nom_usuario_diretor = {}
      nom_usuario_diretor.type = "character";
      nom_usuario_diretor.name = "nom-usuario-diretor";
      nom_usuario_diretor.label = "nom_usuario_diretor";



      var tTable = {};
      tTable.name = 'tt-ccusto               ';
      tTable.records = [];
      tTable.fields = [cod_ccusto, descricao, cod_usuar_gestor, nom_usuario_gestor, cod_usuar_diretor, nom_usuario_diretor];


      // var input = {};
      // input.dataType = "";
      // input.name = "";
      // input.label = "";
      // input.type = "input";
      // input.value = filtro;


      var output = {};
      output.dataType = "temptable";
      output.name = "tt-ccusto";
      output.type = "output";
      output.value = tTable;


      var params = [ output];

      log.info(JSON.stringify(params));
      //conversor dos parametros de input para Json
      return JSON.stringify(params);
}