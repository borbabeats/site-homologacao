function createDataset(fields, constraints, sortFields){
	var newDataset = DatasetBuilder.newDataset();
	newDataset.addColumn("Resposta");
	newDataset.addColumn("Erro");
	
	// Inputs para procedure
	var ferramenta 		= ""+fields[0];
	var ocorrencia		= ""+fields[1];
	var descricao   		= ""+fields[2];
	var prioridade		= ""+fields[3];
	var solicitante		= ""+fields[4];
	var workflow		= ""+fields[5];
	var problema  		= ""+fields[6];
	var objetivo      	= ""+fields[7];
	var email	      	= ""+fields[8];
	
	// Converte para inteiro campos characteres 

	try {
		// Utiliza o ServiceManager para obter uma referencia ao servico.
		var serviceProvider = ServiceManager.getService('TOTVS');
		var serviceLocator  = serviceProvider.instantiate('com.totvs.framework.ws.execbo.service.WebServiceExecBO');
		var service         = serviceLocator.getWebServiceExecBOPort();

		// Faz login e recebe o token de autenticacao
		var token = service.userLogin("fluig");

		var json  = montaJson(ferramenta, ocorrencia, descricao, prioridade, solicitante, workflow, problema, objetivo, email);

		// Chama a procedure passando os parametros e o token de autenticacao.
		var resp = service.callProcedureWithToken(token, "dzp/dzwf002.p", "ws-cria-chamado", json);
		
		var respObj = JSON.parse(resp);

        	var Resposta = [respObj[0].value , respObj[1].value]
		newDataset.addRow(Resposta);
	} catch (e) {
		log.info("ERRO: "+e);
	}	
	return newDataset;
}
function montaJson(ferramenta, ocorrencia, descricao, prioridade, solicitante, workflow, problema, objetivo, email){
	log.info("montaJson");
	
	var resposta 	= {};
	resposta.type 	= "integer";
	resposta.name 	= "p-nr-chamado";
	resposta.label 	= "p-nr-chamado";

	var erro 		= {};
	erro.type 		= "integer";
	erro.name 		= "p-erro";
	erro.label 		= "p-erro";
    
    //array para receber os parametros input da chamada da função
   	
	var input1 			= {};
	input1.dataType		= "integer";
	input1.name 		= "p-cod-ferramenta";
	input1.label 		= "p-cod-ferramenta";
	input1.type 		= "input";
	input1.value 		= ferramenta;
	
	var input2 			= {};
	input2.dataType		= "integer";
	input2.name 		= "p-cod-ocorrencia";
	input2.label 		= "p-cod-ocorrencia";
	input2.type 		= "input";
	input2.value 		= ocorrencia;
	
	var input3 			= {};
	input3.dataType		= "character";
	input3.name 		= "p-descricao";
	input3.label 		= "p-descricao";
	input3.type 		= "input";
	input3.value 		= descricao;
	
	var input4 			= {};
	input4.dataType		= "integer";
	input4.name 		= "p-ind-prioridade";
	input4.label 		= "p-ind-prioridade";
	input4.type 		= "input";
	input4.value 		= prioridade;
	
	var input5			= {};
	input5.dataType		= "character";
	input5.name 		= "p-solicitante";
	input5.label 		= "p-solicitante";
	input5.type 		= "input";
	input5.value 		= solicitante;
	
	var input6 			= {};
	input6.dataType		= "character";
	input6.name 		= "p-cod-workflow";
	input6.label 		= "p-cod-workflow";
	input6.type 		= "input";
	input6.value 		= workflow;
	
	var input7 			= {};
	input7.dataType		= "character";
	input7.name 		= "p-descr-problema";
	input7.label 		= "p-descr-problema";
	input7.type 		= "input";
	input7.value 		= problema;
	
	var input8 			= {};
	input8.dataType		= "character";
	input8.name 		= "p-objetivo";
	input8.label 		= "p-objetivo";
	input8.type 		= "input";
	input8.value 		= objetivo;
    
	var input9 			= {};
	input9.dataType		= "logical";
	input9.name 		= "p-envia-email";
	input9.label 		= "p-envia-email";
	input9.type 		= "input";
	input9.value 		= email;
    
	var output1 		= {};
	output1.dataType		= "integer";
	output1.name 		= "p-nr-chamado";
	output1.type 		= "output";
	output1.value 		= resposta;

	var output2 		= {};
	output2.dataType		= "character";
	output2.name 		= "p-erro";
	output2.type 		= "output";
	output2.value 		= erro;
	
	var params = [input1, input2, input3, input4, input5, input6, input7, input8, input9, output1, output2];
	
	log.info(JSON.stringify(params));
	//conversor dos parametros de input para Json
	return JSON.stringify(params);
}

