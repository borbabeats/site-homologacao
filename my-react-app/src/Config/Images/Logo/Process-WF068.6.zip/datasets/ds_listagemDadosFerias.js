function createDataset(fields, constraints, sortFields){
	var newDataset = DatasetBuilder.newDataset();
	newDataset.addColumn("Codigo");
	newDataset.addColumn("InicPeriodoFerias");
	newDataset.addColumn("TermPeriodoFerias");
	newDataset.addColumn("QtdDiasPeriodo");
	newDataset.addColumn("QtdDiasConcedido");
	newDataset.addColumn("QtdDiasSaldo");
	newDataset.addColumn("UltDtConcessao");
	newDataset.addColumn("UltQtdDiasGozad");
	newDataset.addColumn("UltQtdDiasAbdo");
	newDataset.addColumn("UltQtdDiasLicen");
	newDataset.addColumn("DataLimite");
	newDataset.addColumn("Apto");

	 var filtro  =   ""+fields[1];
	 filtro = parseInt(filtro);
	//var filtro = "11903";

	try {
		// Utiliza o ServiceManager para obter uma referencia ao servico.
		var serviceProvider = ServiceManager.getService('TOTVS');
		var serviceLocator  = serviceProvider.instantiate('com.totvs.framework.ws.execbo.service.WebServiceExecBO');
		var service         = serviceLocator.getWebServiceExecBOPort();

		// Faz login e recebe o token de autenticacao
		var token = service.userLogin("fluig");

		var json  = montaJson(filtro);

		// Chama a procedure passando os parametros e o token de autenticacao.
		var resp = service.callProcedureWithToken(token, "dzp/dzwf001.r", "ws-busca-funcionario-ferias", json);

		var respObj = JSON.parse(resp);

		var callProcedureWithTokenResponse = JSON.parse(respObj[0].value);
		
		for (var i in callProcedureWithTokenResponse.records){
	    	newDataset.addRow(new Array(
			callProcedureWithTokenResponse.records[i]["cdn-funcionario"],
			callProcedureWithTokenResponse.records[i]["dat-inic-period-aqst-ferias"],
			callProcedureWithTokenResponse.records[i]["dat-term-period-aqst-ferias"],
			callProcedureWithTokenResponse.records[i]["qtd-dias-direito-period-aqst"],
			callProcedureWithTokenResponse.records[i]["qtd-dias-ferias-concedid"],
			callProcedureWithTokenResponse.records[i]["qtd-dias-saldo"],
			callProcedureWithTokenResponse.records[i]["ult-dat-concess-efetd"],
			callProcedureWithTokenResponse.records[i]["ult-qtd-dias-gozado"],
			callProcedureWithTokenResponse.records[i]["ult-qtd-dias-abdo"],
	    		callProcedureWithTokenResponse.records[i]["ult-qtd-dias-licenc-concedid"],
	    		callProcedureWithTokenResponse.records[i]["dat-limite-concessao"],
	    		callProcedureWithTokenResponse.records[i]["apto-venda"]
		    ));
	    }
	} catch (e) {
		log.info("ERRO: "+e);
	}

	return newDataset;
}

function montaJson(filtro){
	log.info("montaJson");

	var codigo 			= new Object();
	codigo.type 		= "integer";
	codigo.name 		= "cdn-funcionario";
	codigo.label 		= "codigo";

	var InicPeriodoFerias 	= new Object();
	InicPeriodoFerias.type 	= "date";
	InicPeriodoFerias.name 	= "dat-inic-period-aqst-ferias"; 
	InicPeriodoFerias.label = "InicPeriodoFerias"; 

	var TermPeriodoFerias 	= new Object();
	TermPeriodoFerias.type 	= "date";
	TermPeriodoFerias.name 	= "dat-term-period-aqst-ferias";  
	TermPeriodoFerias.label = "TermPeriodoFerias";

	var QtdDiasPeriodo 		= new Object();
	QtdDiasPeriodo.type 	= "decimal";
	QtdDiasPeriodo.name 	= "qtd-dias-direito-period-aqst"; 
	QtdDiasPeriodo.label  	= "QtdDiasPeriodo";   

	var QtdDiasConcedido 	= new Object();
	QtdDiasConcedido.type 	= "decimal";
	QtdDiasConcedido.name 	= "qtd-dias-ferias-concedid";  
	QtdDiasConcedido.label  = "QtdDiasConcedido";  

	var QtdDiasSaldo 		= new Object();
	QtdDiasSaldo.type 	= "decimal";
	QtdDiasSaldo.name 	= "qtd-dias-saldo";  
	QtdDiasSaldo.label  	= "QtdDiasSaldo"; 

	var UltDtConcessao 	= new Object();
	UltDtConcessao.type 	= "date";
	UltDtConcessao.name 	= "ult-dat-concess-efetd";  
	UltDtConcessao.label  	= "UltDtConcessao"; 

	var UltQtdDiasGozad	= new Object();
	UltQtdDiasGozad.type 	= "decimal";
	UltQtdDiasGozad.name 	= "ult-qtd-dias-gozado";  
	UltQtdDiasGozad.label  	= "UltQtdDiasGozad"; 

	var UltQtdDiasAbdo 	= new Object();
	UltQtdDiasAbdo.type 	= "decimal";
	UltQtdDiasAbdo.name 	= "ult-qtd-dias-abdo"; 
	UltQtdDiasAbdo.label  	= "UltQtdDiasAbdo";
	
	var UltQtdDiasLicen 	= new Object();
	UltQtdDiasLicen.type 	= "decimal";
	UltQtdDiasLicen.name 	= "ult-qtd-dias-licenc-concedid"; 
	UltQtdDiasLicen.label  	= "UltQtdDiasLicen"; 

	var dataLimite 		= new Object();
	dataLimite.type 		= "date";
	dataLimite.name 		= "dat-limite-concessao"; 
	dataLimite.label 		= "dataLimite"; 
	
	var aptoVenda 		= new Object();
	aptoVenda.type 		= "logical";
	aptoVenda.name 		= "apto-venda"; 
	aptoVenda.label 		= "aptoVenda"; 
	
    //formador do paremetro value para temp-table
    	var tt_periodos_ferias 		= new Object();
    	tt_periodos_ferias.name 	= "tt-periodos-ferias";
    	tt_periodos_ferias.records 	= new Array();
    	tt_periodos_ferias.fields 	= [codigo, InicPeriodoFerias, TermPeriodoFerias, QtdDiasPeriodo, QtdDiasConcedido, QtdDiasSaldo, UltDtConcessao, UltQtdDiasGozad, UltQtdDiasAbdo, UltQtdDiasLicen, dataLimite, aptoVenda];
    
    	var apto 	        = {};
	apto.type 	    = "logical";
	apto.name 	    = "p-apto-venda";
	apto.label 	    = "p-apto-venda";
    //array para receber os parametros input da chamada da função
   
    	var input 		= new Object();
    	input.dataType	= "integer";
    	input.name 		= "p-cdn-funcionario";
    	input.label 		= "p-cdn-funcionario";
    	input.type 		= "input";
    	input.value 		= filtro;
    
	var output 		= new Object();
	output.dataType	= "temptable";
	output.name 	= "tt-periodos-ferias";
	output.type 	= "output";
	output.value 	= tt_periodos_ferias;
	
	var params = [input, output];
	
	log.info(JSON.stringify(params));
	//conversor dos parametros de input para Json
	return JSON.stringify(params);
}