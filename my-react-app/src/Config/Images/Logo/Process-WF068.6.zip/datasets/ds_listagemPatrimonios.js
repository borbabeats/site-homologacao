function createDataset(fields, constraints, sortFields) {
	var newDataset = DatasetBuilder.newDataset();
	newDataset.addColumn("CodigoPatrimonio");
	newDataset.addColumn("Descricao");
	newDataset.addColumn("Numero");
	newDataset.addColumn("Descricao");
	newDataset.addColumn("CCusto");
	newDataset.addColumn("DescCCusto");
	
	var filtro = '';

	if (constraints[0].initialValue != null && constraints[0].initialValue != 300)
		filtro = "" + constraints[0].initialValue;
	else
		filtro = "" + constraints[1].initialValue;
// 	filtro  = "48"; // coloca uma num valido


	try {
		// Utiliza o ServiceManager para obter uma referencia ao servico.
		var serviceProvider = ServiceManager.getService('TOTVS');
		var serviceLocator = serviceProvider.instantiate('com.totvs.framework.ws.execbo.service.WebServiceExecBO');
		var service = serviceLocator.getWebServiceExecBOPort();

		// Faz login e recebe o token de autenticacao
		var token = service.userLogin("fluig");

		var json = montaJson(filtro);

		// Chama a procedure passando os parametros e o token de autenticacao.
		var resp = service.callProcedureWithToken(token, "dzp/dzwf001.p", "ws-busca-patrimonio", json);

		var respObj = JSON.parse(resp);

		var callProcedureWithTokenResponse = JSON.parse(respObj[0].value);

		for (var i in callProcedureWithTokenResponse.records) {
			newDataset.addRow(new Array(
				callProcedureWithTokenResponse.records[i]["cod-cta-pat"],
				callProcedureWithTokenResponse.records[i]["des-cta-pat"],
				callProcedureWithTokenResponse.records[i]["num-bem-pat"],
				callProcedureWithTokenResponse.records[i]["des-bem-pat"],
				callProcedureWithTokenResponse.records[i]["cod-ccusto"],
				callProcedureWithTokenResponse.records[i]["dest-tit-ctbl"])
			);
		}
	} catch (e) {
		log.info("### ERRO: " + e);
	}

	return newDataset;
}

function montaJson(filtro) {
	log.info("montaJson");

	var cod_cta_pat = {};
	cod_cta_pat.type = "character";
	cod_cta_pat.name = "cod-cta-pat";
	cod_cta_pat.label = "cod_cta_pat";

	var des_cta_pat = {};
	des_cta_pat.type = "character";
	des_cta_pat.name = "des-cta-pat";
	des_cta_pat.label = "des_cta_pat";

	var Numero = {};
	Numero.type = "integer";
	Numero.name = "num-bem-pat";
	Numero.label = "Numero";

	var Descricao = {};
	Descricao.type = "character";
	Descricao.name = "des-bem-pat";
	Descricao.label = "Descricao";

	var CCusto = {};
	CCusto.type = "character";
	CCusto.name = "cod-ccusto";
	CCusto.label = "CCusto";

	var DesccCusto = {};
	DesccCusto.type = "character";
	DesccCusto.name = "dest-tit-ctbl";
	DesccCusto.label = "DesccCusto";

	//formador do parametro value para temp-table
	var tTable = {};
	tTable.name = "tt-bem-pat";
	tTable.records = [];
	tTable.fields = [cod_cta_pat, des_cta_pat, Numero, Descricao, CCusto, DesccCusto];

	//array para receber os parametros input da chamada da função

	var input = {};
	input.dataType = "integer";
	input.name = "p-num-bem-pat";//procedure input
	input.label = "Numero";
	input.type = "input";
	input.value = filtro;

	var output = {};
	output.dataType = "temptable";
	output.name = "tt-bem-pat";//nome da temp-table
	output.type = "output";
	output.value = tTable;

	var params = [input, output];

	log.info(JSON.stringify(params));
	//conversor dos parametros de input para Json
	return JSON.stringify(params);
}