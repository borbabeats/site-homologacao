function createDataset(fields, constraints, sortFields) {
	try {
	    var newDataset = DatasetBuilder.newDataset();
	    newDataset.addColumn("Resposta");

	
    // 	var nome = "" + fields[1];
    	
    var data = "24/01/2023"

	// Converte para inteiro campos characteres 
	var codigo = 2
		// Utiliza o ServiceManager para obter uma referencia ao servico.
		var serviceProvider = ServiceManager.getService('TOTVS');
		var serviceLocator = serviceProvider.instantiate('com.totvs.framework.ws.execbo.service.WebServiceExecBO');
		var service = serviceLocator.getWebServiceExecBOPort();

		// Faz login e recebe o token de autenticacao
		var token = service.userLogin("fluig");

		var json = montaJson(data, codigo);

		// Chama a procedure passando os parametros e o token de autenticacao.
		var resp = service.callProcedureWithToken(token, "dzp/dzwf001.p", "ws-cotacao-moeda", json);

		var respObj = JSON.parse(resp);

		var resposta = respObj[0].value;

		newDataset.addRow(new Array('resposta'));
		newDataset.addRow(new Array(resposta));

return newDataset;
	} catch (e) {
		log.info("ERRO: " + e);
	}
	
}
function montaJson(data, codigo) {
	log.info("montaJson");

	var resposta = new Object();
	resposta.type = "decimal";
	resposta.name = "p-vl-cotacao";
	resposta.label = "p-vl-cotacao";

	//array para receber os parametros input da chamada da função

	var input1 = new Object();
	input1.dataType = "character";
	input1.name = "p-data";
	input1.label = "p-data";
	input1.type = "input";
	input1.value = data;

	var input2 = new Object();
	input2.dataType = "integer";
	input2.name = "p-mo-codigo";
	input2.label = "p-mo-codigo";
	input2.type = "input";
	input2.value = codigo;


	var output = new Object();
	output.dataType = "decimal";
	output.name = "p-vl-cotacao";
	output.type = "output";
	output.value = resposta;

	var params = [input1, input2, output];

	log.info(JSON.stringify(params));
	//conversor dos parametros de input para Json
	return JSON.stringify(params);
}