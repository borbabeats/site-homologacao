function createDataset(fields, constraints, sortFields){
	var newDataset = DatasetBuilder.newDataset();
	newDataset.addColumn("ok");
	newDataset.addColumn("erro");
	
	// Inputs para procedure
	var codFunc 		= ""+fields[0];
	var dtInicio		= ""+fields[1];
	var dtFim   	    = ""+fields[2];
	var CodMedida		= ""+fields[3];
	var TextoObs		= ""+fields[4];
	
	// Converte para inteiro campos characteres 

	try {
		// Utiliza o ServiceManager para obter uma referencia ao servico.
		var serviceProvider = ServiceManager.getService('TOTVS');
		var serviceLocator  = serviceProvider.instantiate('com.totvs.framework.ws.execbo.service.WebServiceExecBO');
		var service         = serviceLocator.getWebServiceExecBOPort();

		// Faz login e recebe o token de autenticacao
		var token = service.userLogin("fluig");

		var json  = montaJson(codFunc, dtInicio, dtFim, CodMedida, TextoObs);

		// Chama a procedure passando os parametros e o token de autenticacao.
		var resp = service.callProcedureWithToken(token, "dzp/dzwf002.p", "ws-inclui-observ-func", json);
		
		var respObj = JSON.parse(resp);

        var Resposta = [respObj[0].value, respObj[1].value]
		newDataset.addRow(Resposta);
		
	} catch (e) {
		log.info("ERRO: "+e);
	}	
	return newDataset;
}
function montaJson(codFunc, dtInicio, dtFim, CodMedida, TextoObs){
	log.info("montaJson");
	
	var ok     	= new Object();
	ok.type 	    = "logical";
	ok.name 	    = "p-ok";
	ok.label 	    = "p-ok";

	var erro 	        = new Object();
	erro.type 	    = "character";
	erro.name 	    = "p-erro";
	erro.label 	    = "p-erro";
    
    //array para receber os parametros input da chamada da função
   	
	var input1 			= new Object();
	input1.dataType		= "integer";
	input1.name 		= "p-cdn-funcionario";
	input1.label 		= "p-cdn-funcionario";
	input1.type 		= "input";
	input1.value 		= codFunc;
	
	var input2 			= new Object();
	input2.dataType		= "date";
	input2.name 		= "p-dt-inicio";
	input2.label 		= "p-dt-inicio";
	input2.type 		= "input";
	input2.value 		= dtInicio;
	
	var input3 			= new Object();
	input3.dataType		= "date";
	input3.name 		= "p-dt-termino";
	input3.label 		= "p-dt-termino";
	input3.type 		= "input";
	input3.value 		= dtFim;
	
	var input4 			= new Object();
	input4.dataType		= "integer";
	input4.name 		= "p-cdn-obs-func";
	input4.label 		= "p-cdn-obs-func";
	input4.type 		= "input";
	input4.value 		= CodMedida;
	
	var input5			= new Object();
	input5.dataType		= "character";
	input5.name 		= "p-texto-obs";
	input5.label 		= "p-texto-obs";
	input5.type 		= "input";
	input5.value 		= TextoObs;
    
	var output1 		= new Object();
	output1.dataType	= "logical";
	output1.name 		= "p-ok";
	output1.type 		= "output";
	output1.value 		= ok;

	var output2 		= new Object();
	output2.dataType	= "character";
	output2.name 		= "p-erro";
	output2.type 		= "output";
	output2.value 		= erro;
	
	var params = [input1, input2, input3, input4, input5, output1, output2];
	
	log.info(JSON.stringify(params));
	//conversor dos parametros de input para Json
	return JSON.stringify(params);
}
