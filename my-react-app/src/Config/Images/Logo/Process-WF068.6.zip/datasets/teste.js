function createDataset(fields, constraints, sortFields) {
    var c1 = DatasetFactory.createConstraint("approved", "true", "true", ConstraintType.MUST_NOT);
	var c2 = DatasetFactory.createConstraint("assessmentId", "389", "389", ConstraintType.MUST);
    var c3 = DatasetFactory.createConstraint("status", "FINISHED", "FINISHED", ConstraintType.MUST);
    var constraints = new Array(c1, c2, c3);
    var dataset = DatasetFactory.getDataset("assessmentApplicationGenericDataset", null, constraints, null);
    
    return dataset;
}