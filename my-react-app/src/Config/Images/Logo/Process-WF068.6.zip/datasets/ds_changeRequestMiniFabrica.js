function createDataset(fields, constraints, sortFields) {
var dataset = DatasetBuilder.newDataset();
	
    dataset.addColumn("group");
    dataset.addColumn("colleague");
    dataset.addColumn("name");

    //grupo fixo para teste
    var groupId = "Change_Request_MiniFabrica";

    //Você deveria receber a empresa e o papel via constraint
    var companyGroupFilter = DatasetFactory.createConstraint("colleagueGroupPK.companyId"
            , getValue("WKCompany"), getValue("WKCompany"), ConstraintType.MUST);
    var groupFilter = DatasetFactory.createConstraint("colleagueGroupPK.groupId"
            , groupId, groupId, ConstraintType.MUST);
    var constraintsGroup = new Array(companyGroupFilter, groupFilter);

    //Chama dataset PAPELxUSUARIO filtrando por empresa e papel
    var colleaguesByGroup = DatasetFactory.getDataset("colleagueGroup", [], constraintsGroup, []);

    for (var i = 0; i < colleaguesByGroup.rowsCount; i++) {
        //Filtros usuario
        var companyUserFilter = DatasetFactory.createConstraint("colleaguePK.companyId"
                , getValue("WKCompany"), getValue("WKCompany"), ConstraintType.MUST);
        var userFilter = DatasetFactory.createConstraint("colleaguePK.colleagueId"
                , colleaguesByGroup.getValue(i, "colleagueGroupPK.colleagueId")
                , colleaguesByGroup.getValue(i, "colleagueGroupPK.colleagueId"), ConstraintType.MUST);
        var constraintsUser = new Array(companyUserFilter, userFilter);
        //Consulta usuários
        var colleagues = DatasetFactory.getDataset("colleague", [], constraintsUser, []);

        log.info("colleague = " + colleaguesByGroup.getValue(i, "colleagueGroupPK.colleagueId"));
        log.info("constraints = " + constraintsUser);
        log.info("colleagues = " + colleagues.rowsCount);
        dataset.addRow(new Array(
        		colleaguesByGroup.getValue(i,"colleagueGroupPK.groupId"),
                colleaguesByGroup.getValue(i, "colleagueGroupPK.colleagueId"),
                colleagues.getValue(0, "colleagueName")));
    }
    return dataset;
}
