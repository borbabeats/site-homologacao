function createDataset(fields, constraints, sortFields){
	var newDataset = DatasetBuilder.newDataset();
	newDataset.addColumn("CodUsuario");
	newDataset.addColumn("NomeUsuario");
	newDataset.addColumn("EmailUsuario");
	newDataset.addColumn("cdnUsuario");
	newDataset.addColumn("UsuarioSO");
	newDataset.addColumn("UsuarioFluig");
	newDataset.addColumn("Permite");

	var filtro  =  "SAL";

	try {
		// Utiliza o ServiceManager para obter uma referencia ao servico.
		var serviceProvider = ServiceManager.getService('TOTVS');
		var serviceLocator  = serviceProvider.instantiate('com.totvs.framework.ws.execbo.service.WebServiceExecBO');
		var service         = serviceLocator.getWebServiceExecBOPort();

		// Faz login e recebe o token de autenticacao
		var token = service.userLogin("fluig");

		var json  = montaJson(filtro);

		// Chama a procedure passando os parametros e o token de autenticacao.
		var resp = service.callProcedureWithToken(token, "dzp/dzwf001.p", "ws-busca-usuario-grupo-informacoes", json);

		var respObj = JSON.parse(resp);

		var callProcedureWithTokenResponse = JSON.parse(respObj[0].value);

		for (var i in callProcedureWithTokenResponse.records){
            	newDataset.addRow(new Array(
					callProcedureWithTokenResponse.records[i]["cod-usuario"],
					callProcedureWithTokenResponse.records[i]["nom-usuario"],
					callProcedureWithTokenResponse.records[i]["cod-e-mail-local"],
					callProcedureWithTokenResponse.records[i]["cdn-funcionario"],
					callProcedureWithTokenResponse.records[i]["cod-usuar-so"],
					callProcedureWithTokenResponse.records[i]["cod-usuar-fluig"],
					callProcedureWithTokenResponse.records[i]["sal-permite-alterar"]
				)
            );
	    }
	} catch (e) {
		log.info("ERRO: "+e);
	}

	return newDataset;
}

function montaJson(filtro){
	log.info("montaJson");

	var codusuario    = new Object();
	codusuario.type  = "character";
	codusuario.name  = "cod-usuario";
	codusuario.label = "codusuario";

	var nomeusuario   = new Object();
	nomeusuario.type  = "character";
	nomeusuario.name  = "nom-usuario";
	nomeusuario.label = "nomeusuario";

	var codigo   = new Object();
	codigo.type  = "integer";
	codigo.name  = "cdn-funcionario";
	codigo.label = "usuario";

	var email   = new Object();
	email.type  = "character";
	email.name  = "cod-e-mail-local";
	email.label = "mail";

	var usuarioSO   = new Object();
	usuarioSO.type  = "character";
	usuarioSO.name  = "cod-usuar-so";
	usuarioSO.label = "usuarioSO";
	
	var usuFluig   = new Object();
	usuFluig.type  = "character";
	usuFluig.name  = "cod-usuar-fluig";
	usuFluig.label = "UsuFluig";

	var permite   = new Object();
	permite.type  = "logical";
	permite.name  = "sal-permite-alterar";
	permite.label = "permite";

    //formador do parametro value para temp-table
	var tTable		= new Object();
    tTable.name     = "tt-usuarios-atrib-dados";
    tTable.records  = new Array();
    tTable.fields	= [codusuario, nomeusuario, email,codigo, usuarioSO, usuFluig, permite];

    //array para receber os parametros input da chamada da função

    var input 		 = new Object();
    input.dataType   = "character";
    input.name  	 = "p-cod-grp-atrib-dados";//procedure input
    input.label 	 = "p-cod-grp-atrib-dados";
    input.type 	  	 = "input";
    input.value 	 = filtro;

	var output 	  	= new Object();
	output.dataType	= "temptable";
	output.name   	= "tt-usuarios-atrib-dados"; //nome da temp-table
	output.type   	= "output";
	output.value  	= tTable;

	var params = [input, output];

	log.info(JSON.stringify(params));
	//conversor dos parametros de input para Json
	return JSON.stringify(params);
}










