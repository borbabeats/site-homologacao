function createDataset(fields, constraints, sortFields) {

    // Cria as colunas
    // DataSet Indicadores: srv_form_indicador
    var newDataset = DatasetBuilder.newDataset();
    // var nomeIndicador;
    // newDataset.addColumn("Codigo_Indicador");
    newDataset.addColumn("Nome_Indicador");
    
    // var array   = [];
    // var auxArray;
    // var filtro  =   constraints[1];

	// var c5          	= DatasetFactory.createConstraint("active", true, true, ConstraintType.SHOULD);
	// var c5          	= DatasetFactory.createConstraint("txt_nomeIndicador", matUsuario, matUsuario, ConstraintType.SHOULD);

    // c1 = DatasetFactory.createConstraint("mail", "%" + constraints[0].initialValue + "%" , "%" + constraints[0].finalValue + "%",  ConstraintType.SHOULD);
    // c2 = DatasetFactory.createConstraint("login", "%" + constraints[0].initialValue + "%", "%" + constraints[0].finalValue + "%",  ConstraintType.SHOULD);
    // c1.setLikeSearch(true);
    // c2.setLikeSearch(true);
    // filter = new Array (c1, c2);

    var indicadores = DatasetFactory.getDataset("ds_FormularioIndicadorAtual", null, null, null);
    for(i = 0; i < indicadores.rowsCount; i++){
        // indicadores.getValue(i,"txt_codigoIndicador"),
        newDataset.addRow(new Array(colleaguesByGroup.getValue(i,"txt_nomeIndicador")));
    }   
    return newDataset;
}