function createDataset(fields, constraints, sortFields) {    
    // Monta Dataset
    var dataset 	= 	DatasetBuilder.newDataset();
    var matricula	=	"54ylia1w0jtmfwup1490872541446";
    var acessToken	=	"4e12ba1f-f61a-442f-8988-a31048917782";
    var tokenSecret	=	"eb0b4edd-b8c9-471b-9dd5-8420c8e1cdffb1b9a5f3-0d65-4847-958c-c6d93a679f26";
    dataset.addColumn("Matrícula_RH");
 
    var servicoURL = "http://10.0.136.48/api/public/2.0/users/listData/"+matricula;    
    var myApiConsumer =  oauthUtil.getGenericConsumer("consumerkey_OAuth","consumerSecret_OAuth", acessToken, tokenSecret);    
    var data = myApiConsumer.get(servicoURL);        
          
    var objdata = JSON.parse(data);  
    var conteudo2 	=	objdata.content["Matrícula_RH"];

    dataset.addRow(new Array(conteudo2));
    return dataset;    
}  