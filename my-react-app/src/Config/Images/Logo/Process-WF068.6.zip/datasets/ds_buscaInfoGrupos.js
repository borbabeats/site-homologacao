function createDataset(fields, constraints, sortFields) {
    try {
        var dataset = DatasetBuilder.newDataset();

        dataset.addColumn("group");
        dataset.addColumn("colleague");
        dataset.addColumn("name");

        //grupo fixo para teste
        // var groupId = '' + fields[0];
        var groupId = fields;

        for (let index = 0; index < groupId.length; index++) {
            if(groupId[index] === '') return;
            
            var colleaguesByGroup = DatasetFactory.getDataset(
                "colleagueGroup",
                [],
                [
                    DatasetFactory.createConstraint(
                        "colleagueGroupPK.companyId",
                        getValue("WKCompany"),
                        getValue("WKCompany"),
                        ConstraintType.MUST
                    ),
                    DatasetFactory.createConstraint(
                        "colleagueGroupPK.groupId",
                        groupId[index],
                        groupId[index],
                        ConstraintType.MUST
                    )
                ],
                []
            );

            for (var i = 0; i < colleaguesByGroup.rowsCount; i++) {
                var colleagues = DatasetFactory.getDataset(
                    "colleague", null,
                    [
                        DatasetFactory.createConstraint(
                            "colleaguePK.companyId",
                            getValue("WKCompany"),
                            getValue("WKCompany"),
                            ConstraintType.MUST
                        ),
                        DatasetFactory.createConstraint(
                            "colleaguePK.colleagueId",
                            colleaguesByGroup.getValue(i, "colleagueGroupPK.colleagueId"),
                            colleaguesByGroup.getValue(i, "colleagueGroupPK.colleagueId"),
                            ConstraintType.MUST
                        )
                    ], null
                );

                dataset.addRow(new Array(colleaguesByGroup.getValue(i, "colleagueGroupPK.groupId"), colleaguesByGroup.getValue(i, "colleagueGroupPK.colleagueId"),
                    colleagues.getValue(0, "colleagueName")));
            }
        }
    } catch (error) {
        log.info('ERRO: dataset "ds_buscaInfoGrupos":' + error);
    } finally {
        return dataset;
    }
}