function createDataset(fields, constraints, sortFields) {
	try {
		var newDataset = DatasetBuilder.newDataset();
		newDataset.addColumn("Codigo");
		newDataset.addColumn("Descricao");
		newDataset.addColumn("PrimeiroDiaTurno");

		var filtro = '';

		if (constraints[0].initialValue != null && constraints[0].initialValue != 300)
			filtro = "" + constraints[0].initialValue;
		else
			filtro = "" + constraints[1].initialValue;

		var serviceProvider = ServiceManager.getService('TOTVS');
		var serviceLocator = serviceProvider.instantiate('com.totvs.framework.ws.execbo.service.WebServiceExecBO');
		var service = serviceLocator.getWebServiceExecBOPort();

		var resp = service.callProcedureWithToken(
			service.userLogin("fluig"),
			"dzp/dzwf001.p",
			"ws-busca-turno-trab",
			montaJson(filtro)
		);

		var callProcedureWithTokenResponse = JSON.parse(JSON.parse(resp)[0].value);
// 		log.info(resp);
		for (var i in callProcedureWithTokenResponse.records) {
			newDataset.addRow(new Array(
				callProcedureWithTokenResponse.records[i]["cdn-turno-trab"],
				callProcedureWithTokenResponse.records[i]["des-turno-trab"],//field da temptable
				callProcedureWithTokenResponse.records[i]["i-primeiro-dia-trabalho"])
			);
		}
	} catch (e) {
		log.info("### ERRO: " + e);
	} 

	return newDataset;
}

function montaJson(filtro) {
	log.info("montaJson");

	var codigo = {};
	codigo.type = "integer";//parameter type
	codigo.name = "cdn-turno-trab";//field da temptable
	codigo.label = "codigo";

	var descricao = {};
	descricao.type = "character";
	descricao.name = "des-turno-trab";
	descricao.label = "descricao";

	var primeiroDiaTrabalho = {};
	primeiroDiaTrabalho.type = "integer";
	primeiroDiaTrabalho.name = "i-primeiro-dia-trabalho";
	primeiroDiaTrabalho.label = "primeiroDiaTrabalho";

	//formador do parametro value para temp-table
	var tTable = {};
	tTable.name = "tt-turno-trab";//nome da temp-table
	tTable.records = [];
	tTable.fields = [codigo, descricao, primeiroDiaTrabalho];

	//array para receber os parametros input da chamada da função

	var input = {};
	input.dataType = "character";
	input.name = "p-des-turno-trab";//procedure input
	input.label = "p-des-turno-trab";
	input.type = "input";
	input.value = filtro;

	var output = {};
	output.dataType = "temptable";
	output.name = "tt-turno-trab";//nome da temp-table
	output.type = "output";
	output.value = tTable;

	var params = [input, output];

	log.info(JSON.stringify(params));
	//conversor dos parametros de input para Json
	return JSON.stringify(params);
}
