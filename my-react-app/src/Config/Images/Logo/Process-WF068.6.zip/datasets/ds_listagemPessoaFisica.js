function createDataset(fields, constraints, sortFields){
	var newDataset = DatasetBuilder.newDataset();
	newDataset.addColumn("Código");
	newDataset.addColumn("Nome");
	newDataset.addColumn("Telefone");
	newDataset.addColumn("Empresa");
	newDataset.addColumn("Contato Maxiforja");

	var filtro = '';

		if (constraints[0].initialValue != null && constraints[0].initialValue != 300) 
			filtro = "" + constraints[0].initialValue;
		else
			filtro = "" + constraints[1].initialValue;

	try {
		// Utiliza o ServiceManager para obter uma referencia ao servico.
		var serviceProvider = ServiceManager.getService('TOTVS');
		var serviceLocator  = serviceProvider.instantiate('com.totvs.framework.ws.execbo.service.WebServiceExecBO');
		var service         = serviceLocator.getWebServiceExecBOPort();

		// Faz login e recebe o token de autenticacao
		var token = service.userLogin("fluig");

		var json  = montaJson(filtro);

		// Chama a procedure passando os parametros e o token de autenticacao.
		var resp = service.callProcedureWithToken(token, "dzp/dzwf001.r", "ws-busca-pessoa-fisica", json);

		var respObj = JSON.parse(resp);

		var callProcedureWithTokenResponse = JSON.parse(respObj[0].value);
		
		for (var i in callProcedureWithTokenResponse.records){
	    	newDataset.addRow(new Array(
			callProcedureWithTokenResponse.records[i]["cod-pessoa-fisica"], 
			callProcedureWithTokenResponse.records[i]["nome"], 
			callProcedureWithTokenResponse.records[i]["celular"], 
			callProcedureWithTokenResponse.records[i]["empresa"], 
			callProcedureWithTokenResponse.records[i]["contato"])
			);
	    }
	} catch (e) {
		log.info("ERRO: "+e);
	}

	return newDataset;
}

function montaJson(filtro){
	log.info("montaJson");

	var codigo 		= new Object();
	codigo.type 	= "integer";
	codigo.name 	= "cod-pessoa-fisica";
	codigo.label 	= "codigo";

	var nome 		= new Object();
	nome.type 		= "character";
	nome.name 		= "nome"; 
	nome.label 		= "nome"; 

	var celular 	= new Object();
	celular.type 	= "character";
	celular.name 	= "celular";  
	celular.label 	= "celular";

	var empresa 	= new Object();
	empresa.type 	= "character";
	empresa.name 	= "empresa"; 
	empresa.label   = "empresa";   

	var contato 	= new Object();
	contato.type 	= "character";
	contato.name 	= "contato";  
	contato.label  	= "contato";  
	    
    //formador do paremetro value para temp-table
    var tt_pessoa 			= new Object();
    tt_pessoa.name 			= "tt-pessoa-fisica";
    tt_pessoa.records 		= new Array();
    tt_pessoa.fields 		= [codigo, nome, celular, empresa, contato];
    
    //array para receber os parametros input da chamada da função
   
    var tt_pessoa_filt 		= new Object();
    tt_pessoa_filt.dataType	= "character";
    tt_pessoa_filt.name 	= "p-nome";
    tt_pessoa_filt.label 	= "p-nome";
    tt_pessoa_filt.type 	= "input";
    tt_pessoa_filt.value 	= filtro;
    
	var tt_pessoa_var 		= new Object();
	tt_pessoa_var.dataType	= "temptable";
	tt_pessoa_var.name 		= "tt-pessoa-fisica";
	tt_pessoa_var.type 		= "output";
	tt_pessoa_var.value 	= tt_pessoa;
	
	var params = [tt_pessoa_filt, tt_pessoa_var];
	
	log.info(JSON.stringify(params));
	//conversor dos parametros de input para Json
	return JSON.stringify(params);
}