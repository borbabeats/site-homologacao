function createDataset(fields, constraints, sortFields){
	var newDataset = DatasetBuilder.newDataset();
	newDataset.addColumn("TbPreco");
	newDataset.addColumn("Descricao");
	newDataset.addColumn("Situacao");

	var FiltroGrupo = parseInt("2");
	//var FiltroGrupo = "";
	var filtro = '';

		if (constraints[0].initialValue != null && constraints[0].initialValue != 300) 
			filtro = "" + constraints[0].initialValue;
		else
			filtro = "" + constraints[1].initialValue;
	
	try {
		// Utiliza o ServiceManager para obter uma referencia ao servico.
		var serviceProvider = ServiceManager.getService('TOTVS');
		var serviceLocator  = serviceProvider.instantiate('com.totvs.framework.ws.execbo.service.WebServiceExecBO');
		var service         = serviceLocator.getWebServiceExecBOPort();

		// Faz login e recebe o token de autenticacao
		var token = service.userLogin("fluig");

		var json  = montaJson(filtro, FiltroGrupo);
		// Chama a procedure passando os parametros e o token de autenticacao.
		var resp = service.callProcedureWithToken(token, "dzp/dzwf001.r", "ws-busca-tb-preco" , json);

		var respObj = JSON.parse(resp);

		var callProcedureWithTokenResponse = JSON.parse(respObj[0].value);
		
		for (var i in callProcedureWithTokenResponse.records){
			
	    	newDataset.addRow(new Array(
			callProcedureWithTokenResponse.records[i]["nr-tabpre"], 
			callProcedureWithTokenResponse.records[i]["descricao"],
			callProcedureWithTokenResponse.records[i]["lg-ativa"])
			);
	    }
	}catch (e) {
		log.info("ERRO: "+e);
	}

	return newDataset;
}

function montaJson(filtro1 , filtro2){
	log.info("montaJson");

	var TbPreco 	= new Object();
	TbPreco.type 	= "character";
	TbPreco.name 	= "nr-tabpre"; 
	TbPreco.label 	= "TbPreco"; 

	var descricao	= new Object();
	descricao.type 	= "character";
	descricao.name 	= "descricao";  
	descricao.label = "descricao";

	var situacao	= new Object();
	situacao.type 	= "logical";
	situacao.name 	= "lg-ativa";  
	situacao.label 	= "situacao";
	    
    //formador do paremetro value para temp-table
    var tt_tb_preco 		= new Object();
    tt_tb_preco.name 		= "tt-tb-preco";
    tt_tb_preco.records 	= new Array();
    tt_tb_preco.fields 	    = [TbPreco, descricao, situacao];
    
    //array para receber os parametros input da chamada da função
   
    var input 		= new Object();
    input.dataType	= "character";
    input.name 		= "p-nr-tabpre";
    input.label 	= "p-nr-tabpre";
    input.type 		= "input";
    input.value 	= filtro1;
    
	var input2 		= new Object();
    input2.dataType	= "integer";
	input2.name		= "p-status";
    input2.label 	= "p-status";
    input2.type		= "input";
    input2.value 	= filtro2;
    
	var output 		= new Object();
	output.dataType	= "temptable";
	output.name 	= "tt-tb-preco";
	output.type 	= "output";
	output.value 	= tt_tb_preco;
	
	var params = [input, input2 , output];
	
	log.info(JSON.stringify(params));
	//conversor dos parametros de input para Json
	return JSON.stringify(params);
}