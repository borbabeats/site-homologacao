function createDataset(fields, constraints, sortFields){
	var newDataset = DatasetBuilder.newDataset();
	newDataset.addColumn("Código");
	newDataset.addColumn("Nome");
	newDataset.addColumn("CNPJ");
	newDataset.addColumn("Endereço");
	newDataset.addColumn("Bairro");
	newDataset.addColumn("Cidade");
	newDataset.addColumn("Estado");
	newDataset.addColumn("CEP");
	newDataset.addColumn("Telefone");
	newDataset.addColumn("Email");
	newDataset.addColumn("Identificador");
	newDataset.addColumn("Razão");

	var filtro  =   ""+fields[0];

	// var filtro = "10251";

	try {
		// Utiliza o ServiceManager para obter uma referencia ao servico.
		var serviceProvider = ServiceManager.getService('TOTVS');
		var serviceLocator  = serviceProvider.instantiate('com.totvs.framework.ws.execbo.service.WebServiceExecBO');
		var service         = serviceLocator.getWebServiceExecBOPort();

		// Faz login e recebe o token de autenticacao
		var token = service.userLogin("fluig");

		var json  = montaJson(filtro);

		// Chama a procedure passando os parametros e o token de autenticacao.
		var resp = service.callProcedureWithToken(token, "dzp/dzwf001.r", "ws-busca-emitente-tbpreco", json);

		var respObj = JSON.parse(resp);

		var callProcedureWithTokenResponse = JSON.parse(respObj[0].value);
		
		for (var i in callProcedureWithTokenResponse.records){
	    	newDataset.addRow(
				[
					callProcedureWithTokenResponse.records[i]["cod-emitente"], 
					callProcedureWithTokenResponse.records[i]["nome-abrev"], 
					callProcedureWithTokenResponse.records[i]["cnpj"], 
					callProcedureWithTokenResponse.records[i]["endereco"], 
					callProcedureWithTokenResponse.records[i]["bairro"], 
					callProcedureWithTokenResponse.records[i]["cidade"], 
					callProcedureWithTokenResponse.records[i]["estado"], 
					callProcedureWithTokenResponse.records[i]["cep"], 
					callProcedureWithTokenResponse.records[i]["telefone"], 
					callProcedureWithTokenResponse.records[i]["e-mail"], 
					callProcedureWithTokenResponse.records[i]["identific"],
					callProcedureWithTokenResponse.records[i]["nome-emit"]
				]
			);
	    }
	} catch (e) {
		log.info("ERRO: "+e);
	}

	return newDataset;
}


function montaJson(filtro){
	log.info("montaJson");

	var codigo 		= {};
	codigo.type 	= "integer";
	codigo.name 	= "cod-emitente";
	codigo.label 	= "codigo";

	var nome 		= {};
	nome.type 		= "character";
	nome.name 		= "nome-abrev"; 
	nome.label 		= "nome"; 

	var cnpj 		= {};
	cnpj.type 		= "character";
	cnpj.name 		= "cnpj";  
	cnpj.label 		= "cnpj";

	var endereco 	= {};
	endereco.type 	= "character";
	endereco.name 	= "endereco"; 
	endereco.label 	= "endereco";   

	var bairro 		= {};
	bairro.type 	= "character";
	bairro.name 	= "bairro";  
	bairro.label  	= "bairro";  

	var cidade 		= {};
	cidade.type 	= "character";
	cidade.name 	= "cidade";  
	cidade.label  	= "cidade"; 

	var estado 		= {};
	estado.type 	= "character";
	estado.name 	= "estado";  
	estado.label  	= "estado"; 

	var cep 		= {};
	cep.type 		= "character";
	cep.name 		= "cep";   
	cep.label  		= "cep"; 

	var telefone 	= {};
	telefone.type 	= "character";
	telefone.name 	= "telefone";  
	telefone.label  	= "telefone"; 

	var email		= {};
	email.type 		= "character";
	email.name 		= "e-mail";  
	email.label  	= "eMail"; 

	var ident 		= {};
	ident.type 		= "integer";
	ident.name 		= "identific"; 
	ident.label  	= "identificador";
	
	var raz 		= {};
	raz.type 		= "character";
	raz.name 		= "nome-emit"; 
	raz.label  		= "razao"; 
	    
    //formador do paremetro value para temp-table
    var tt_emitente 		= {};
    tt_emitente.name 		= "tt-emitente";
    tt_emitente.records 		= [];
    tt_emitente.fields 		= [codigo, nome, cnpj, endereco, bairro, cidade, estado, cep, telefone, email, ident, raz];
    
    //array para receber os parametros input da chamada da função
   
    var tb_preco 	= {};
	tb_preco.dataType = "character";
	tb_preco.name 	= "p-nr-tabpre";
	tb_preco.label 	= "p-nr-tabpre";
	tb_preco.type 	= "input";
	tb_preco.value 	= filtro;
    
	var temp_emitente 	= {};
	temp_emitente.dataType 	= "temptable";
	temp_emitente.name 	= "tt-emitente";
	temp_emitente.type 	= "output";
	temp_emitente.value 	= tt_emitente;
	
	var params = [tb_preco, temp_emitente];
	
	log.info(JSON.stringify(params));
	//conversor dos parametros de input para Json
	return JSON.stringify(params);
	
}