function createDataset(fields, constraints, sortFields){
	log.info("começou teste filtro")
	var newDataset = DatasetBuilder.newDataset();
	newDataset.addColumn("Código");
	newDataset.addColumn("Nome");
	newDataset.addColumn("Status");

	var filtro  =   ""+fields[0];

	try {
		// Utiliza o ServiceManager para obter uma referencia ao servico.
		var serviceProvider = ServiceManager.getService('TOTVS');
		var serviceLocator  = serviceProvider.instantiate('com.totvs.framework.ws.execbo.service.WebServiceExecBO');
		var service         = serviceLocator.getWebServiceExecBOPort();

		// Faz login e recebe o token de autenticacao
		var token = service.userLogin("fluig");

		var json  = montaJson(filtro);

		// Chama a procedure passando os parametros e o token de autenticacao.
		var resp = service.callProcedureWithToken(token, "dzp/dzwf001.p", "ws-busca-itens-tbpreco", json);

		var respObj = JSON.parse(resp);

		var callProcedureWithTokenResponse = JSON.parse(respObj[0].value);
		
		for (var i in callProcedureWithTokenResponse.records){
			newDataset.addRow(new Array(
					callProcedureWithTokenResponse.records[i]["it-codigo"], 
					callProcedureWithTokenResponse.records[i]["desc-item"], 
					callProcedureWithTokenResponse.records[i]["lg-ativo"])
			);
		}
	} catch (e) {
		log.info("ERRO: "+e);
	}

	return newDataset;
}

function montaJson(filtro){
	log.info("montaJson");

	var codigo 		= {};
	codigo.type 	= "character";
	codigo.name 	= "it-codigo";
	codigo.label 	= "itCodigo";

	var nome 		= {};
	nome.type 		= "character";
	nome.name 		= "desc-item"; 
	nome.label 		= "descItem"; 

	var Status 		= {};
	Status.type		= "logical";
	Status.name 	= "lg-ativo";  
	Status.label 	= "lgAtivo";
	
	//formador do paremetro value para temp-table
	var tt_item 	= {};
	tt_item.name 	= "tt-itens-tb-preco";
	tt_item.records = [];
	tt_item.fields 	= [codigo, nome, Status];

	//array para receber os parametros input da chamada da função

	var tab_filtro 			= {};
	tab_filtro.dataType		= "character";
	tab_filtro.name 		= "p-nr-tabpre";
	tab_filtro.label 		= "p-nr-tabpre";
	tab_filtro.type 		= "input";
	tab_filtro.value 		= filtro;

	var tt_item_var 		= {};
	tt_item_var.dataType	= "temptable";
	tt_item_var.name 		= "tt-itens-tb-preco";
	tt_item_var.type 		= "output";
	tt_item_var.value 		= tt_item;
	
	var params = [tab_filtro, tt_item_var];
	
	log.info(JSON.stringify(params));
	//conversor dos parametros de input para Json
	return JSON.stringify(params);
}
