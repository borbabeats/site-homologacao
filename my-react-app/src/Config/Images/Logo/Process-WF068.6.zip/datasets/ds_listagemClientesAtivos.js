function createDataset(fields, constraints, sortFields){
	var newDataset = DatasetBuilder.newDataset();
	newDataset.addColumn("CodEmitente");
	newDataset.addColumn("Nome");
	newDataset.addColumn("CNPJ");
	newDataset.addColumn("Endereço");
	newDataset.addColumn("Bairro");
	newDataset.addColumn("Cidade");
	newDataset.addColumn("Estado");
	newDataset.addColumn("CEP");
	newDataset.addColumn("Telefone");
	newDataset.addColumn("Email");
	newDataset.addColumn("Identificador");
	newDataset.addColumn("NomeAbrev");

	var filtro  =   ""+constraints[0].initialValue;

	// if(filtro == "Deere"){ filtro = "John "+filtro; }
	//var filtro = "Scania";
	// 1 = Cliente
	// 2 = Fornecedor
	// 3 = Todos
	try {
		// Utiliza o ServiceManager para obter uma referencia ao servico.
		var serviceProvider = ServiceManager.getService('TOTVS');
		var serviceLocator  = serviceProvider.instantiate('com.totvs.framework.ws.execbo.service.WebServiceExecBO');
		var service         = serviceLocator.getWebServiceExecBOPort();

		// Faz login e recebe o token de autenticacao
		var token = service.userLogin("fluig");

		var json  = montaJson(filtro);

		// Chama a procedure passando os parametros e o token de autenticacao.
		var resp = service.callProcedureWithToken(token, "dzp/dzwf001.r", "ws-busca-emitente-nome-tbpreco-ativa", json);

		var respObj = JSON.parse(resp);

		var callProcedureWithTokenResponse = JSON.parse(respObj[0].value);
		
		for (var i in callProcedureWithTokenResponse.records){
				newDataset.addRow(new Array(
						callProcedureWithTokenResponse.records[i]["cod-emitente"], 
						callProcedureWithTokenResponse.records[i]["nome-abrev"], 
						callProcedureWithTokenResponse.records[i]["cnpj"], 
						callProcedureWithTokenResponse.records[i]["endereco"], 
						callProcedureWithTokenResponse.records[i]["bairro"], 
						callProcedureWithTokenResponse.records[i]["cidade"], 
						callProcedureWithTokenResponse.records[i]["estado"], 
						callProcedureWithTokenResponse.records[i]["cep"], 
						callProcedureWithTokenResponse.records[i]["telefone"], 
						callProcedureWithTokenResponse.records[i]["e-mail"], 
						callProcedureWithTokenResponse.records[i]["identific"],
						callProcedureWithTokenResponse.records[i]["nome-emit"]
					)
				);
	    }
	} catch (e) {
		log.info("ERRO: "+e);
	}

	return newDataset;
}

function montaJson(filtro){
	log.info("montaJson");

	var codigo 		= new Object();
	codigo.type 	= "integer";
	codigo.name 	= "cod-emitente";
	codigo.label 	= "codigo";

	var nome 		= new Object();
	nome.type 		= "character";
	nome.name 		= "nome-abrev"; 
	nome.label 		= "nome"; 

	var cnpj 		= new Object();
	cnpj.type 		= "character";
	cnpj.name 		= "cnpj";  
	cnpj.label 		= "cnpj";

	var endereco 	= new Object();
	endereco.type 	= "character";
	endereco.name 	= "endereco"; 
	endereco.label  = "endereco";   

	var bairro 		= new Object();
	bairro.type 	= "character";
	bairro.name 	= "bairro";  
	bairro.label  	= "bairro";  

	var cidade 		= new Object();
	cidade.type 	= "character";
	cidade.name 	= "cidade";  
	cidade.label  	= "cidade"; 

	var estado 		= new Object();
	estado.type 	= "character";
	estado.name 	= "estado";  
	estado.label  	= "estado"; 

	var cep 		= new Object();
	cep.type 		= "character";
	cep.name 		= "cep";   
	cep.label  		= "cep"; 

	var telefone 	= new Object();
	telefone.type 	= "character";
	telefone.name 	= "telefone";  
	telefone.label  = "telefone"; 

	var email		= new Object();
	email.type 		= "character";
	email.name 		= "e-mail";  
	email.label  	= "e-mail"; 

	var ident 		= new Object();
	ident.type 		= "integer";
	ident.name 		= "identific"; 
	ident.label  	= "identificador";
	
	var raz 		= new Object();
	raz.type 		= "character";
	raz.name 		= "nome-emit"; 
	raz.label  		= "razao"; 
	    
    //formador do paremetro value para temp-table
    var tt_emitente 		= new Object();
    tt_emitente.name 		= "tt-emitente";
    tt_emitente.records 	= new Array();
    tt_emitente.fields 		= [codigo, nome, cnpj, endereco, bairro, cidade, estado, cep, telefone, email, ident, raz];
    
    //array para receber os parametros input da chamada da função
   
    var tt_emitente_filt 	= new Object();
	tt_emitente_filt.dataType= "character";
	tt_emitente_filt.name 	= "p-nome-abrev";
	tt_emitente_filt.label 	= "p-nome-abrev";
	tt_emitente_filt.type 	= "input";
	tt_emitente_filt.value 	= filtro;
    
	var tt_emitente_var 	= new Object();
	tt_emitente_var.dataType= "temptable";
	tt_emitente_var.name 	= "tt-emitente";
	tt_emitente_var.type 	= "output";
	tt_emitente_var.value 	= tt_emitente;
	
	var params = [tt_emitente_filt, tt_emitente_var];
	
	log.info(JSON.stringify(params));
	//conversor dos parametros de input para Json
	return JSON.stringify(params);
}