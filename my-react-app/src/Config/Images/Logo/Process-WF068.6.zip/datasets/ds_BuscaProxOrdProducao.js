function createDataset(fields, constraints, sortFields){
	log.info("começou teste filtro")
	var newDataset = DatasetBuilder.newDataset();
	newDataset.addColumn("OP");
	newDataset.addColumn("Codigo");
	newDataset.addColumn("QuantProduzida");
	newDataset.addColumn("NomeAbrev");
	newDataset.addColumn("NomeEmit");
	newDataset.addColumn("OPCodigo");
	newDataset.addColumn("OPDescricao");
	newDataset.addColumn("OPPTOControle");
	newDataset.addColumn("DescItem");

	var filtro1  =   ""+fields[0];
	var filtro2  =   ""+fields[1];
	// var filtro1  = "3351406";
	// var filtro2  = "10";
	//testes 3351406 
	try {
		// Utiliza o ServiceManager para obter uma referencia ao servico.
		var serviceProvider = ServiceManager.getService('TOTVS');
		var serviceLocator  = serviceProvider.instantiate('com.totvs.framework.ws.execbo.service.WebServiceExecBO');
		var service         = serviceLocator.getWebServiceExecBOPort();

		// Faz login e recebe o token de autenticacao
		var token = service.userLogin("fluig");

		var json  = montaJson(filtro1, filtro2);

		// Chama a procedure passando os parametros e o token de autenticacao.
		var resp = service.callProcedureWithToken(token, "dzp/dzwf001.p", "ws-busca-proxima-operacao-ord-prod", json);

		var respObj = JSON.parse(resp);

		var callProcedureWithTokenResponse = JSON.parse(respObj[0].value);
		
		for (var i in callProcedureWithTokenResponse.records){
		newDataset.addRow(new Array(
			callProcedureWithTokenResponse.records[i]["nr-ord-produ"], 
			callProcedureWithTokenResponse.records[i]["it-codigo"], 
			callProcedureWithTokenResponse.records[i]["qt-produzida"],
			callProcedureWithTokenResponse.records[i]["nome-abrev"],
			callProcedureWithTokenResponse.records[i]["nome-emit"],
			callProcedureWithTokenResponse.records[i]["op-codigo"],
			callProcedureWithTokenResponse.records[i]["op-descricao"],
			callProcedureWithTokenResponse.records[i]["op-pto-controle"],
			callProcedureWithTokenResponse.records[i]["desc-item"],
			callProcedureWithTokenResponse.records[i]["num-operac-sfc"])
			);
	}
	} catch (e) {
		log.info("ERRO: "+e);
	}

	return newDataset;
}

function montaJson(filtro1 , filtro2){
	log.info("montaJson");

	var op     		 = {};
	op.type 		 = "integer";
	op.name 		 = "nr-ord-produ";
	op.label   	 	 = "OP";

	var itCodigo 	 = {};
	itCodigo.type 	 = "character";
	itCodigo.name 	 = "it-codigo"; 
	itCodigo.label 	 = "itCodigo";

	var qtProduzida  = {};
	qtProduzida.type = "decimal";
	qtProduzida.name = "qt-produzida"; 
	qtProduzida.label= "qtProduzida";
	
	var nomeabrev 	 = {};
	nomeabrev.type   = "character";
	nomeabrev.name 	 = "nome-abrev"; 
	nomeabrev.label  = "nomeabrev";
	
	var nomeEmit 	 = {};
	nomeEmit.type    = "character";
	nomeEmit.name 	 = "nome-emit"; 
	nomeEmit.label 	 = "nomeEmit";

	var opCodigo 	 = {};
	opCodigo.type    = "integer";
	opCodigo.name 	 = "op-codigo"; 
	opCodigo.label 	 = "opCodigo";

	var opDescricao  = {};
	opDescricao.type = "character";
	opDescricao.name = "op-descricao"; 
	opDescricao.label= "opDescricao";

	var prControle 	 = {};
	prControle.type  = "integer";
	prControle.name  = "op-pto-controle"; 
	prControle.label = "prControle";

	var descItem 	 = {};
	descItem.type  	 = "character";
	descItem.name  	 = "desc-item"; 
	descItem.label   = "descItem";

	var numOperacSfc 	 = new Object();
	numOperacSfc.type  = "integer";
	numOperacSfc.name  = "num-operac-sfc"; 
	numOperacSfc.label = "numOperacSfc";
	
	//formador do parametro value para temp-table
	var tTable			= {};
	tTable.name 		= "tt-ord-prod";
	tTable.records 		= [];
	tTable.fields		= [op, itCodigo, qtProduzida, nomeabrev, nomeEmit, opCodigo, opDescricao, prControle, descItem, numOperacSfc];

	//array para receber os parametros input da chamada da função

	var input 		= {};
	input.dataType	= "integer";
	input.name  	= "p-nr-ord-produ";
	input.label 	= "p-nr-ord-produ";
	input.type 	      = "input";
	input.value 	= filtro1;

	var input2 		= {};
	input2.dataType	= "integer";
	input2.name  	= "p-num-operac-sfc-atual";
	input2.label 	= "p-num-operac-sfc-atual";
	input2.type 	= "input";
	input2.value 	= filtro2;

	var output 		= {};
	output.dataType	= "temptable";
	output.name 	= "tt-ord-prod";
	output.type 	= "output";
	output.value 	= tTable;
	
	var params = [input, input2, output];
	
	log.info(JSON.stringify(params));
	//conversor dos parametros de input para Json
	return JSON.stringify(params);
}