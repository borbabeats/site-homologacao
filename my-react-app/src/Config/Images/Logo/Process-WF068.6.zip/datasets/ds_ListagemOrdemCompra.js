function createDataset(fields, constraints, sortFields){
	try {
		log.info("começou teste filtro")
		var newDataset = DatasetBuilder.newDataset();
		newDataset.addColumn("numOrdem"); 	
		newDataset.addColumn("numPedido"); 	
		newDataset.addColumn("nomeAbrev"); 	
		newDataset.addColumn("nomeEmit"); 	
		newDataset.addColumn("itCodigo"); 	
		newDataset.addColumn("Uni"); 		
		newDataset.addColumn("descItem"); 	
		newDataset.addColumn("qtSolic"); 	
		newDataset.addColumn("precoUnit"); 	
		newDataset.addColumn("situacaoOc"); 
		newDataset.addColumn("parcela"); 	
		newDataset.addColumn("Quantidade"); 
		newDataset.addColumn("quantSaldo"); 
		newDataset.addColumn("dataEntrega");
		newDataset.addColumn("dataUltRecbto");
		newDataset.addColumn("situacaoParc");

		var filtro  =   ""+constraints[0].initialValue; 
		// filtro  =   parseInt(filtro)
		// var filtro  =   "48606483"

		// log.info("MATEUS // FILTRO " + filtro);
		

		// Utiliza o ServiceManager para obter uma referencia ao servico.
		var serviceProvider = ServiceManager.getService('TOTVS');
		var serviceLocator  = serviceProvider.instantiate('com.totvs.framework.ws.execbo.service.WebServiceExecBO');
		var service         = serviceLocator.getWebServiceExecBOPort();

		// Faz login e recebe o token de autenticacao
		var token = service.userLogin("fluig");

		var json  = montaJson(filtro);

		// Chama a procedure passando os parametros e o token de autenticacao.
		var resp = service.callProcedureWithToken(token, "dzp/dzwf001.p", "ws-busca-ordem-compra", json);

		var respObj = JSON.parse(resp);

		var callProcedureWithTokenResponse = JSON.parse(respObj[0].value);
		
		for (var i in callProcedureWithTokenResponse.records){
			// log.info("NUMERO ORDEM // VIANA" + callProcedureWithTokenResponse.records[i]["numero-ordem"])
	    		newDataset.addRow([
				callProcedureWithTokenResponse.records[i]["numero-ordem"], 
				callProcedureWithTokenResponse.records[i]["num-pedido"], 
				callProcedureWithTokenResponse.records[i]["nome-abrev"], 
				callProcedureWithTokenResponse.records[i]["nome-emit"], 
				callProcedureWithTokenResponse.records[i]["it-codigo"], 
				callProcedureWithTokenResponse.records[i]["un"], 
				callProcedureWithTokenResponse.records[i]["desc-item"], 
				callProcedureWithTokenResponse.records[i]["qt-solic"], 
				callProcedureWithTokenResponse.records[i]["preco-unit"], 
				callProcedureWithTokenResponse.records[i]["situacao-oc"], 
				callProcedureWithTokenResponse.records[i]["parcela"], 
				callProcedureWithTokenResponse.records[i]["quantidade"], 
				callProcedureWithTokenResponse.records[i]["quant-saldo"], 
				callProcedureWithTokenResponse.records[i]["data-entrega"], 
				callProcedureWithTokenResponse.records[i]["dt-ult-recbto"], 
				callProcedureWithTokenResponse.records[i]["situacao-parc"]
			]
			);
	    }
	} catch (e) {
		log.info("ERRO // "+e);
	}
	// log.info("FIM DA BUSCA // MATEUS : ");
	return newDataset;
}

function montaJson(filtro){
	log.info("montaJson");

	var numOrdem      = {};
	numOrdem.type     = "integer";
	numOrdem.name     = "numero-ordem";
	numOrdem.label    = "numOrdem";

	var numPedido     = {};
	numPedido.type    = "integer";
	numPedido.name    = "num-pedido";
	numPedido.label   = "numPedido";
	
	var nomeAbrev     = {};
	nomeAbrev.type    = "character";
	nomeAbrev.name    = "nome-abrev";
	nomeAbrev.label   = "nomeAbrev";
	
	var nomeEmit      = {};
	nomeEmit.type     = "character";
	nomeEmit.name     = "nome-emit";
	nomeEmit.label    = "nomeEmit";
	
	var itCodigo      = {};
	itCodigo.type     = "character";
	itCodigo.name     = "it-codigo";
	itCodigo.label    = "itCodigo";

	var Uni           = {};
	Uni.type          = "character";
	Uni.name          = "un";
	Uni.label         = "Uni";
	
	var descItem      = {};
	descItem.type     = "character";
	descItem.name     = "desc-item";
	descItem.label    = "descItem";
	
	var qtSolic       = {};
	qtSolic.type      = "decimal";
	qtSolic.name      = "qt-solic";
	qtSolic.label     = "qtSolic";
	
	var precoUnit     = {};
	precoUnit.type    = "decimal";
	precoUnit.name    = "preco-unit";
	precoUnit.label   = "precoUnit";
	
	var situacaoOc    = {};
	situacaoOc.type   = "character";
	situacaoOc.name   = "situacao-oc";
	situacaoOc.label  = "situacaoOc";
	
	var parcela       = {};
	parcela.type      = "integer";
	parcela.name      = "parcela";
	parcela.label     = "parcela";
	
	var quantidade    = {};
	quantidade.type   = "decimal";
	quantidade.name   = "quantidade";
	quantidade.label  = "quantidade";
	
	var quantSaldo    = {};
	quantSaldo.type   = "decimal";
	quantSaldo.name   = "quant-saldo";
	quantSaldo.label  = "quantSaldo";
	
	var dataEntrega   = {};
	dataEntrega.type  = "date";
	dataEntrega.name  = "data-entrega";
	dataEntrega.label = "dataEntrega";
	
	var dtUltRecbto   = {};
	dtUltRecbto.type  = "date";
	dtUltRecbto.name  = "dt-ult-recbto";
	dtUltRecbto.label = "dtUltRecbto";
	
	var situacaoParc   = {};
	situacaoParc.type  = "character";
	situacaoParc.name  = "situacao-parc";
	situacaoParc.label = "situacaoParc";


	
      //formador do parametro value para temp-table
      var tTable			= {};
      tTable.name 		= "tt-ord-prod";
      tTable.records 		= [];
      tTable.fields		= [numOrdem, numPedido, nomeAbrev, nomeEmit, itCodigo, Uni, descItem, qtSolic, precoUnit, situacaoOc, parcela, quantidade, quantSaldo, dataEntrega, dtUltRecbto, situacaoParc];
      
      //array para receber os parametros input da chamada da função
      
      var input 		= {};
      input.dataType	= "integer";
      input.name  	= "p-numero-ordem";
      input.label 	= "p-numero-ordem";
      input.type 	      = "input";
      input.value 	= parseInt(filtro);
    
      var output 		= {};
      output.dataType	= "temptable";
      output.name 	= "tt-ordem-compra";
      output.type 	= "output";
      output.value 	= tTable;
	
	var params = [input, output];
	
	log.info(JSON.stringify(params));
	//conversor dos parametros de input para Json
	return JSON.stringify(params);
}

 






