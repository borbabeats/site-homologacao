function createDataset(fields, constraints, sortFields) {
    var newDataset = DatasetBuilder.newDataset();
    
    var matricula = ''+fields[0]
    
    var dataSource = "/jdbc/AppDS";
    var ic = new javax.naming.InitialContext();
    var ds = ic.lookup(dataSource);
    var created = false;

    var myQuery = "Select !isnull(tb.main_numSolic)as nulo, tb.main_numSolic, tb.zoom_matricula, tb.txt_nomeSolicitante, substring(DATE_FORMAT(p.START_DATE, '%d/%m/%Y'), 1,10) as main_dataAbertura, tb.id from ml001064 as tb inner join proces_workflow as p on p.NUM_PROCES = tb.main_numSolic where zoom_matricula = '"+matricula+"' order by id desc limit 3;";

    try {
        var conn = ds.getConnection();
        var stmt = conn.createStatement();
        var rs = stmt.executeQuery(myQuery);
        var columnCount = rs.getMetaData().getColumnCount();
        while (rs.next()) {
            if (!created) {
                for (var i = 1; i <= columnCount; i++) {
                    newDataset.addColumn(rs.getMetaData().getColumnName(i));
                }
                created = true;
            }
            var Arr = new Array();
            for (var i = 1; i <= columnCount; i++) {
                var obj = rs.getObject(rs.getMetaData().getColumnName(i));
                if (null != obj) {
                    Arr[i - 1] = rs.getObject(rs.getMetaData().getColumnName(i)).toString();
                } else {
                    Arr[i - 1] = "null";
                }
            }
            newDataset.addRow(Arr);
        }
    } catch (e) {
        log.error("ERRO==============> " + e.message);
    } finally {
        if (stmt != null) {
            stmt.close();
        }
        if (conn != null) {
            conn.close();
        }
    }
    
    return newDataset;
}

