function createDataset(fields, constraints, sortFields){
	var newDataset = DatasetBuilder.newDataset();
	newDataset.addColumn("CodEmitente");
	newDataset.addColumn("NomeAbrev");
	newDataset.addColumn("Cnpj");
	newDataset.addColumn("Endereco");
	newDataset.addColumn("Bairro");
	newDataset.addColumn("Cidade");
	newDataset.addColumn("Estado");
	newDataset.addColumn("Cep");
	newDataset.addColumn("Telefone");
	newDataset.addColumn("Email");
	newDataset.addColumn("Identificador");
	newDataset.addColumn("Nome");
	newDataset.addColumn("CodCondPagamento");
	newDataset.addColumn("Descricao");

	var filtro = '';

		if (constraints[0].initialValue != null && constraints[0].initialValue != 300) 
			filtro = "" + constraints[0].initialValue;
		else
			filtro = "" + constraints[1].initialValue;
	//var filtro  = "Bra"; // coloca uma num valido


	try {
		// Utiliza o ServiceManager para obter uma referencia ao servico.
		var serviceProvider = ServiceManager.getService('TOTVS');
		var serviceLocator  = serviceProvider.instantiate('com.totvs.framework.ws.execbo.service.WebServiceExecBO');
		var service         = serviceLocator.getWebServiceExecBOPort();

		// Faz login e recebe o token de autenticacao
		var token = service.userLogin("fluig");

		var json  = montaJson(filtro);

		// Chama a procedure passando os parametros e o token de autenticacao.
		var resp = service.callProcedureWithToken(token, "dzp/dzwf001.p", "ws-busca-emitente-cod-cond-pag", json);

		var respObj = JSON.parse(resp);

		var callProcedureWithTokenResponse = JSON.parse(respObj[0].value);

		for (var i in callProcedureWithTokenResponse.records){
	    	newDataset.addRow(new Array(
			callProcedureWithTokenResponse.records[i]["cod-emitente"],
			callProcedureWithTokenResponse.records[i]["nome-abrev"],
			callProcedureWithTokenResponse.records[i]["cnpj"],
			callProcedureWithTokenResponse.records[i]["endereco"],
			callProcedureWithTokenResponse.records[i]["bairro"],
			callProcedureWithTokenResponse.records[i]["cidade"],
			callProcedureWithTokenResponse.records[i]["estado"],
			callProcedureWithTokenResponse.records[i]["cep"],
			callProcedureWithTokenResponse.records[i]["telefone"],
			callProcedureWithTokenResponse.records[i]["e-mail"],
			callProcedureWithTokenResponse.records[i]["identific"],
			callProcedureWithTokenResponse.records[i]["nome-emit"],
			callProcedureWithTokenResponse.records[i]["cod-cond-pag"],
			callProcedureWithTokenResponse.records[i]["des-cond-pag"])
			);
	    }
	} catch (e) {
		log.info("### ERRO: "+e);
	}

	return newDataset;
}

function montaJson(filtro){
	log.info("montaJson");

	var codEmitente     = new Object();
	codEmitente.type	= "integer";
	codEmitente.name    = "cod-emitente";
	codEmitente.label   = "codEmitente";

	var nomeAbrev   = new Object();
	nomeAbrev.type  = "character";
	nomeAbrev.name	= "nome-abrev";
	nomeAbrev.label	= "nomeAbrev";

	var cnpj	   	= new Object();
	cnpj.type 		= "character";
	cnpj.name 		= "cnpj";
	cnpj.label 		= "cnpj";

	var endereco    = new Object();
	endereco.type   = "character";
	endereco.name   = "endereco";
	endereco.label  = "endereco";

	var bairro 		= new Object();
	bairro.type 	= "character";
	bairro.name 	= "bairro";
	bairro.label 	= "bairro";

	var cidade 		= new Object();
	cidade.type 	= "character";
	cidade.name 	= "cidade";
	cidade.label 	= "cidade";

	var estado 		= new Object();
	estado.type   	= "character";
	estado.name   	= "estado";
	estado.label 	= "estado";

	var cep 		= new Object();
	cep.type   	  	= "character";
	cep.name 	  	= "cep";
	cep.label 	  	= "cep";

	var telefone 	= new Object();
	telefone.type  	= "character";
	telefone.name   = "telefone";
	telefone.label 	= "telefone";

	var email 		= new Object();
	email.type    	= "character";
	email.name 		= "e-mail";
	email.label 	= "e-mail";

	var identific 	= new Object();
	identific.type  = "integer";
	identific.name	= "identific";
	identific.label = "identific";

	var nomeEmit 	= new Object();
	nomeEmit.type  	= "character";
	nomeEmit.name 	= "nome-emit";
	nomeEmit.label 	= "nomeEmit";

	var codCondPagamento 	= new Object();
	codCondPagamento.type   = "integer";
	codCondPagamento.name 	= "cod-cond-pag";
	codCondPagamento.label  = "codCondPagamento";

	var desCondPagamento 	= new Object();
	desCondPagamento.type   = "character";
	desCondPagamento.name 	= "des-cond-pag";
	desCondPagamento.label  = "desCondPagamento";

    //formador do parametro value para temp-table
	var tTable		   = new Object();
    tTable.name    = "tt-emitente-cod-cond-pag";
    tTable.records = new Array();
    tTable.fields	 = [codEmitente, nomeAbrev, cnpj, endereco, bairro, cidade, estado, cep, telefone, email, identific, nomeEmit, codCondPagamento, desCondPagamento];

    //array para receber os parametros input da chamada da função

    var input 		 = new Object();
    input.dataType   = "character";
    input.name  	 = "p-nome-emit";//procedure input
    input.label 	 = "p-nome-emit";
    input.type 	  	 = "input";
    input.value 	 = filtro;

	var output 	  	= new Object();
	output.dataType	= "temptable";
	output.name   	= "tt-emitente-cod-cond-pag";//nome da temp-table
	output.type   	= "output";
	output.value  	= tTable;

	var params = [input, output];

	log.info(JSON.stringify(params));
	//conversor dos parametros de input para Json
	return JSON.stringify(params);
}
