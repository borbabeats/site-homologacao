function createDataset(fields, constraints, sortFields){
	var newDataset = DatasetBuilder.newDataset();
	newDataset.addColumn("Cidade");
	newDataset.addColumn("Estado");
	newDataset.addColumn("Pais");

	var filtro = '';

		if (constraints[0].initialValue != null && constraints[0].initialValue != 300) 
			filtro = "" + constraints[0].initialValue;
		else
			filtro = "" + constraints[1].initialValue;
	//var filtro  = "cal"; // coloca uma num valido


	try {
		// Utiliza o ServiceManager para obter uma referencia ao servico.
		var serviceProvider = ServiceManager.getService('TOTVS');
		var serviceLocator  = serviceProvider.instantiate('com.totvs.framework.ws.execbo.service.WebServiceExecBO');
		var service         = serviceLocator.getWebServiceExecBOPort();

		// Faz login e recebe o token de autenticacao
		var token = service.userLogin("fluig");

		var json  = montaJson(filtro);

		// Chama a procedure passando os parametros e o token de autenticacao.
		var resp = service.callProcedureWithToken(token, "dzp/dzwf001.p", "ws-busca-cidade", json);

		var respObj = JSON.parse(resp);

		var callProcedureWithTokenResponse = JSON.parse(respObj[0].value);

		for (var i in callProcedureWithTokenResponse.records){
			// if(callProcedureWithTokenResponse.records[i]["pais"] == "BRASIL"){
		    		newDataset.addRow(new Array(
		    		callProcedureWithTokenResponse.records[i]["cidade"],
		    		callProcedureWithTokenResponse.records[i]["estado"],
		    		callProcedureWithTokenResponse.records[i]["pais"])
				);
			// }
	    }
	} catch (e) {
		log.info("### ERRO: "+e);
	}

	return newDataset;
}

function montaJson(filtro){
	log.info("montaJson");

	var cidade   = new Object();
	cidade.type  = "character";
	cidade.name	 = "cidade";
	cidade.label = "cidade";

	var estado 	 = new Object();
	estado.type  = "character";
	estado.name  = "estado";
	estado.label = "estado";
	
	var pais 	 = new Object();
	pais.type 	 = "character";
	pais.name  	 = "pais";
	pais.label	 = "pais";
    //formador do parametro value para temp-table
	var tTable		= new Object();
    tTable.name     = "tt-cidade";
    tTable.records  = new Array();
    tTable.fields	= [cidade, estado, pais];

    //array para receber os parametros input da chamada da função

    var input 		 = new Object();
    input.dataType   = "character";
    input.name  	 = "p-cidade";//procedure input
    input.label 	 = "Cidade";
    input.type 	  	 = "input";
    input.value 	 = filtro;

	var output 	  	= new Object();
	output.dataType	= "temptable";
	output.name   	= "tt-cidade";//nome da temp-table
	output.type   	= "output";
	output.value  	= tTable;

	var params = [input, output];

	log.info(JSON.stringify(params));
	//conversor dos parametros de input para Json
	return JSON.stringify(params);
}